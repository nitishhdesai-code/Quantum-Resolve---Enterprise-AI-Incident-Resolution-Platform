# Current App Analysis

The original Quantum Resolve app is a browser-only support assistant built from one HTML file, CSS, JavaScript modules, and JavaScript array files used as databases.

## What It Does

- Global search across three data groups: solutions, KB articles, and Problem IDs.
- Advanced keyword search with stemming, synonyms, acronyms, typo tolerance, phonetic matching, field weights, search modes, thresholds, and result limits.
- Tier prediction from a resolution/tier lookup table.
- Result modals with details, editable keywords, editable links, and export reminders.
- Close-note generation from the best matching historical solution.
- AI-assisted close-note rewriting, cause analysis, chat guidance, and email drafting through a Gemini API call.
- Temporary curation flow where agent answers can be saved into an in-memory curated database and exported.
- Theme switching, toast notifications, and a demo ServiceNow settings modal.

## How The Original Works

- Data is loaded through global variables from files in `database/`.
- The search algorithm runs entirely in the browser:
  - Query text is split into raw keywords.
  - Keywords are expanded with synonyms and acronyms.
  - Fields are scored separately, then multiplied by UI-controlled weights.
  - Results are filtered by score threshold and selected category.
- AI calls are made directly from the browser using a hard-coded API key.
- Edits are stored only in memory until the user exports a replacement JavaScript file.
- The app can work offline for local search because the database files are bundled with the page, but AI and web-grounded answers require internet access.

## Why It Was Used

The app gives support engineers a compact workspace for quickly matching incidents to known resolutions, KBs, Problem IDs, and tier routing data. It reduces repeated troubleshooting effort and helps draft consistent close notes and user communications.

## Main Limitations

- Data is not durable because it lives in JavaScript arrays.
- Browser-side AI key exposure is unsafe.
- Search is custom keyword scoring instead of a proper indexed search engine.
- No true backend API, authentication boundary, database migrations, or index management.
- Offline changes are temporary and require manual export.
- UI is visually rich but static, hard to extend, and tightly coupled to DOM IDs.

