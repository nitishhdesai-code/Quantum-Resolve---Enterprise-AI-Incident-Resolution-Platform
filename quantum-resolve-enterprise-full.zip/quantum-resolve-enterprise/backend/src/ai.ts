import { config } from "./config.js";
import type { AiSettings, SearchDocument } from "./types.js";

type GeminiResult = { text: string; sources: { uri: string; title: string }[] };

function resolveAiSettings(ai?: AiSettings): Required<Pick<AiSettings, "provider" | "model" | "apiKey" | "grounding" | "temperature">> &
  Pick<AiSettings, "endpoint"> | null {
  if (ai?.enabled && ai.apiKey && ai.model && ai.provider) {
    return {
      provider: ai.provider,
      model: ai.model,
      apiKey: ai.apiKey,
      endpoint: ai.endpoint,
      grounding: Boolean(ai.grounding),
      temperature: typeof ai.temperature === "number" ? ai.temperature : 0.2
    };
  }
  if (!config.geminiApiKey) return null;
  return {
    provider: "gemini",
    model: config.geminiModel,
    apiKey: config.geminiApiKey,
    endpoint: undefined,
    grounding: true,
    temperature: 0.2
  };
}

export async function callConfiguredAi(systemPrompt: string, userPrompt: string, useSearch = false, ai?: AiSettings) {
  const selected = resolveAiSettings(ai);
  if (!selected) return null;

  if (selected.provider === "openai") return callOpenAi(systemPrompt, userPrompt, useSearch, selected);
  if (selected.provider === "anthropic") return callAnthropic(systemPrompt, userPrompt, selected);
  if (selected.provider === "mistral") return callMistral(systemPrompt, userPrompt, selected);
  if (selected.provider === "azure-openai" || selected.provider === "custom") {
    return callOpenAiCompatible(systemPrompt, userPrompt, selected);
  }
  return callGemini(systemPrompt, userPrompt, useSearch && selected.grounding, selected);
}

export async function callGemini(systemPrompt: string, userPrompt: string, useSearch = false, ai?: AiSettings) {
  const selected = resolveAiSettings(ai);
  if (!selected) return null;

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${selected.model}:generateContent?key=${selected.apiKey}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: userPrompt }] }],
      systemInstruction: { parts: [{ text: systemPrompt }] },
      ...(useSearch ? { tools: [{ google_search: {} }] } : {})
    })
  });

  if (!response.ok) {
    throw new Error(`AI provider returned ${response.status}`);
  }

  const payload = await response.json();
  const candidate = payload.candidates?.[0];
  const text = candidate?.content?.parts?.[0]?.text;
  if (!text) throw new Error("AI provider returned an empty response.");

  const sources =
    candidate?.groundingMetadata?.groundingAttributions
      ?.map((item: { web?: { uri?: string; title?: string } }) => item.web)
      ?.filter((web: { uri?: string; title?: string }) => web?.uri && web?.title) || [];

  return { text, sources } satisfies GeminiResult;
}

async function callOpenAi(
  systemPrompt: string,
  userPrompt: string,
  useSearch: boolean,
  ai: NonNullable<ReturnType<typeof resolveAiSettings>>
) {
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ai.apiKey}`
    },
    body: JSON.stringify({
      model: ai.model,
      input: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      ...(useSearch && ai.grounding ? { tools: [{ type: "web_search_preview" }] } : {})
    })
  });
  if (!response.ok) throw new Error(`OpenAI returned ${response.status}`);
  const payload = await response.json();
  const text =
    payload.output_text ||
    payload.output
      ?.flatMap((item: { content?: { text?: string }[] }) => item.content || [])
      ?.map((item: { text?: string }) => item.text)
      ?.filter(Boolean)
      ?.join("\n");
  if (!text) throw new Error("OpenAI returned an empty response.");
  return { text, sources: [] } satisfies GeminiResult;
}

async function callAnthropic(
  systemPrompt: string,
  userPrompt: string,
  ai: NonNullable<ReturnType<typeof resolveAiSettings>>
) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ai.apiKey,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: ai.model,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
      max_tokens: 4096,
      temperature: ai.temperature
    })
  });
  if (!response.ok) throw new Error(`Anthropic returned ${response.status}`);
  const payload = await response.json();
  const text = payload.content?.map((item: { text?: string }) => item.text).filter(Boolean).join("\n");
  if (!text) throw new Error("Anthropic returned an empty response.");
  return { text, sources: [] } satisfies GeminiResult;
}

async function callMistral(
  systemPrompt: string,
  userPrompt: string,
  ai: NonNullable<ReturnType<typeof resolveAiSettings>>
) {
  const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ai.apiKey}`
    },
    body: JSON.stringify({
      model: ai.model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: ai.temperature
    })
  });
  if (!response.ok) throw new Error(`Mistral returned ${response.status}`);
  const payload = await response.json();
  const text = payload.choices?.[0]?.message?.content;
  if (!text) throw new Error("Mistral returned an empty response.");
  return { text, sources: [] } satisfies GeminiResult;
}

async function callOpenAiCompatible(
  systemPrompt: string,
  userPrompt: string,
  ai: NonNullable<ReturnType<typeof resolveAiSettings>>
) {
  if (!ai.endpoint) throw new Error("A custom or Azure OpenAI endpoint is required.");
  const response = await fetch(ai.endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ai.apiKey}`,
      "api-key": ai.apiKey
    },
    body: JSON.stringify({
      model: ai.model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: ai.temperature
    })
  });
  if (!response.ok) throw new Error(`AI endpoint returned ${response.status}`);
  const payload = await response.json();
  const text = payload.choices?.[0]?.message?.content || payload.output_text;
  if (!text) throw new Error("AI endpoint returned an empty response.");
  return { text, sources: [] } satisfies GeminiResult;
}

export async function generateAgentAnswer(query: string, contextDocuments: SearchDocument[], ai?: AiSettings, webSearch = true) {
  const context = contextDocuments
    .slice(0, 6)
    .map((doc, index) => `${index + 1}. [${doc.type}] ${doc.title}\n${doc.description}\n${doc.content}`)
    .join("\n\n");
  const hasInternalContext = contextDocuments.length > 0;
  const shouldUseWebSearch = webSearch;

  const aiResult = await callConfiguredAi(
    shouldUseWebSearch
      ? hasInternalContext
        ? "You are an enterprise IT support assistant. Thoroughly analyze verified internal context first. Use web search only to fill gaps or verify missing solution details. Cite external sources and clearly mark external guidance. Do not invent internal facts."
        : "You are an enterprise IT support assistant. No strong internal solution was found. Use web search for general guidance, cite sources, and clearly mark external guidance. Do not invent internal facts."
      : "You are an enterprise IT support assistant. Thoroughly analyze verified internal context first. Do not use web information unless the caller explicitly enabled it because no internal solution exists. Provide clear, actionable steps.",
    `Internal context:\n${context || "No matching internal context."}\n\nUser question: ${query}`,
    shouldUseWebSearch,
    ai
  ).catch(() => null);

  if (aiResult) return aiResult;

  const topSolution = contextDocuments.find((doc) => doc.type === "solution");
  if (!topSolution) {
    return {
      text:
        "I could not find a strong internal match. Capture the exact error, affected application, user steps, timestamp, and screenshots, then route the case to the owning support queue for deeper triage.",
      sources: []
    };
  }

  const payload = topSolution.payload as { issue?: string; cause?: string; resolution?: string };
  return {
    text: `Internal match found: ${payload.issue || topSolution.title}\n\nLikely cause: ${
      payload.cause || "Not documented."
    }\n\nRecommended resolution:\n${payload.resolution || topSolution.description}`,
    sources: []
  };
}

export async function enhanceCloseNotes(issue: string, matchedSolution?: SearchDocument, ai?: AiSettings) {
  if (!matchedSolution) return "No similar past solution was found.";
  const payload = matchedSolution.payload as { issue?: string; cause?: string; resolution?: string };

  const aiResult = await callConfiguredAi(
    "Rewrite support close notes into concise, professional, step-by-step ticket notes. Do not invent facts.",
    `New issue:\n${issue}\n\nMatched internal solution:\nIssue: ${payload.issue}\nCause: ${payload.cause}\nResolution: ${payload.resolution}`,
    false,
    ai
  ).catch(() => null);

  if (aiResult?.text) {
    return `Issue: ${payload.issue || issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution:\n${aiResult.text.trim()}`;
  }

  return `Issue: ${payload.issue || issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution:\n${payload.resolution || "No resolution documented."}`;
}

export async function draftEmail(input: {
  ticket: string;
  userName: string;
  priority: string;
  issue: string;
  matchedSolution?: SearchDocument;
  ai?: AiSettings;
}) {
  const payload = input.matchedSolution?.payload as
    | { issue?: string; cause?: string; resolution?: string }
    | undefined;

  const aiResult = await callConfiguredAi(
    "Draft a concise, professional IT support email. Use only the provided internal solution unless explicitly marked unavailable.",
    `Ticket: ${input.ticket}
Priority: ${input.priority}
User: ${input.userName}
Issue: ${input.issue}
Internal solution: ${payload ? JSON.stringify(payload, null, 2) : "No matching internal solution."}`,
    false,
    input.ai
  ).catch(() => null);

  if (aiResult?.text) return aiResult.text.trim();

  if (!payload) {
    return `Hi ${input.userName || "there"},

Thank you for sharing the details for ticket ${input.ticket || "N/A"}. We are reviewing the issue and will continue investigating with the available logs and screenshots.

As an initial step, please restart the affected application and confirm whether the issue reproduces on a stable network connection.

Regards,
IT Support`;
  }

  return `Hi ${input.userName || "there"},

Thank you for contacting us about ticket ${input.ticket || "N/A"}.

We found a matching internal resolution for this issue:
${payload.resolution}

Likely cause: ${payload.cause || "Not documented."}

Please try the steps above and let us know if the issue continues.

Regards,
IT Support`;
}

export async function parseCurationFromText(text: string, ai?: AiSettings) {
  const aiResult = await callConfiguredAi(
    'Extract an IT support issue, cause, resolution, and keywords. Return only JSON: {"issue":"","cause":"","resolution":"","keywords":[]}',
    text,
    false,
    ai
  ).catch(() => null);

  if (aiResult?.text) {
    const match = aiResult.text.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]) as {
          issue?: string;
          cause?: string;
          resolution?: string;
          keywords?: string[];
        };
      } catch {
        // Fall through to deterministic parser.
      }
    }
  }

  const lines = text
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);

  return {
    issue: lines[0] || "Curated support issue",
    cause: "",
    resolution: lines.slice(1).join("\n") || text,
    keywords: [...new Set(text.toLowerCase().match(/[a-z0-9]{4,}/g) || [])].slice(0, 12)
  };
}
