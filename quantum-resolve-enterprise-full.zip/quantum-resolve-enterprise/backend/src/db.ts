import pg from "pg";
import { config } from "./config.js";

const { Pool } = pg;

export const pool = new Pool({
  connectionString: config.databaseUrl,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 1_500
});

let databaseReady = false;

export function setDatabaseReady(value: boolean) {
  databaseReady = value;
}

export function isDatabaseReady() {
  return databaseReady;
}

export async function checkDatabase() {
  try {
    await pool.query("select 1");
    databaseReady = true;
    return true;
  } catch {
    databaseReady = false;
    return false;
  }
}
