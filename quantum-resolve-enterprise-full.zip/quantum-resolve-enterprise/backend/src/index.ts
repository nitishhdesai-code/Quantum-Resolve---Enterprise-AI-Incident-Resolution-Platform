import compression from "compression";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import morgan from "morgan";
import { z } from "zod";
import { config } from "./config.js";
import { acronymMap, stopWords, synonymMap } from "./data/seed-data.js";
import { checkDatabase, isDatabaseReady } from "./db.js";
import {
  draftEmail,
  enhanceCloseNotes,
  generateAgentAnswer,
  parseCurationFromText
} from "./ai.js";
import { reindexMeilisearch } from "./meilisearch.js";
import { activeSearchProvider, searchEnterpriseCandidates, searchProviderHealth } from "./enterprise-search.js";
import {
  addCuratedSolution,
  getAllDocuments,
  getItem,
  getSnapshot,
  getTiers,
  initializeDatabase,
  updateItemKeywords,
  updateItemLink
} from "./repository.js";
import {
  defaultSearchConfig,
  normalizeConfig,
  performLocalSearch,
  predictTier,
  summarizeCauses
} from "./search-utils.js";
import type { Category, SearchDocument } from "./types.js";

const app = express();

app.use(helmet());
app.use(compression());
app.use(express.json({ limit: "2mb" }));
app.use(
  cors({
    origin: config.frontendOrigin,
    credentials: true
  })
);
app.use(morgan(config.nodeEnv === "production" ? "combined" : "dev"));

const searchSchema = z.object({
  query: z.string().default(""),
  categories: z.array(z.enum(["solution", "kb", "problem"])).default(["solution", "kb", "problem"]),
  config: z.any().optional(),
  tierAccuracy: z.number().min(0).max(1).default(0.5),
  provider: z.enum(["offline", "meilisearch", "opensearch", "elasticsearch", "solr"]).optional()
});

const aiSchema = z
  .object({
    enabled: z.boolean().optional(),
    provider: z.enum(["gemini", "openai", "anthropic", "mistral", "azure-openai", "custom"]).optional(),
    model: z.string().optional(),
    apiKey: z.string().optional(),
    endpoint: z.string().optional(),
    grounding: z.boolean().optional(),
    temperature: z.number().optional()
  })
  .optional();

app.get("/api/health", async (_req, res) => {
  const database = await checkDatabase();
  const search = await searchProviderHealth();
  res.json({
    ok: true,
    services: {
      api: true,
      database,
      ...search,
      ai: Boolean(config.geminiApiKey)
    }
  });
});

app.get("/api/bootstrap", async (_req, res, next) => {
  try {
    const snapshot = await getSnapshot();
    const search = await searchProviderHealth();
    res.json({
      ...snapshot,
      dictionaries: {
        stopWords,
        synonymMap,
        acronymMap
      },
      defaultSearchConfig,
      services: {
        database: isDatabaseReady(),
        ...search,
        ai: Boolean(config.geminiApiKey)
      }
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/search", async (req, res, next) => {
  try {
    const input = searchSchema.parse(req.body);
    const configForSearch = normalizeConfig(input.config);
    let documents = await getAllDocuments();
    const categories = input.categories as Category[];
    const externalCandidates =
      input.provider && input.provider !== "offline"
        ? await searchEnterpriseCandidates(input.query, categories, 120, input.provider)
        : input.provider === "offline"
          ? null
          : await searchEnterpriseCandidates(input.query, categories);

    if (externalCandidates && externalCandidates.length > 0) {
      const candidateIds = new Set(externalCandidates.map((doc) => doc.uid));
      const candidateDocs = documents.filter((doc) => candidateIds.has(doc.uid));
      documents = candidateDocs.length ? candidateDocs : documents;
    }

    const results = performLocalSearch(input.query, documents, categories, configForSearch);
    const tiers = await getTiers();
    const prediction = predictTier(input.query, tiers, configForSearch, input.tierAccuracy);

    res.json({
      query: input.query,
      results,
      prediction,
      engine: externalCandidates ? `${activeSearchProvider(input.provider)}+rerank` : input.provider === "offline" ? "offline-requested" : "postgres-fallback",
      counts: {
        solution: results.solution.length,
        kb: results.kb.length,
        problem: results.problem.length
      }
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/items/:type/:id", async (req, res, next) => {
  try {
    const item = await getItem(req.params.type as Category, req.params.id);
    if (!item) return res.status(404).json({ error: "Item not found" });
    return res.json(item);
  } catch (error) {
    return next(error);
  }
});

app.patch("/api/items/:type/:id/keywords", async (req, res, next) => {
  try {
    const body = z.object({ keywords: z.array(z.string()) }).parse(req.body);
    const item = await updateItemKeywords(req.params.type as Category, req.params.id, normalizeKeywords(body.keywords));
    await safelyReindex();
    res.json(item);
  } catch (error) {
    next(error);
  }
});

app.patch("/api/items/:type/:id/link", async (req, res, next) => {
  try {
    const body = z.object({ link: z.string().url() }).parse(req.body);
    const item = await updateItemLink(req.params.type as Category, req.params.id, body.link);
    await safelyReindex();
    res.json(item);
  } catch (error) {
    next(error);
  }
});

app.post("/api/solutions/curated", async (req, res, next) => {
  try {
    const body = z
      .object({
        issue: z.string().min(2),
        cause: z.string().default(""),
        resolution: z.string().min(2),
        tier1: z.string().default(""),
        tier2: z.string().default(""),
        tier3: z.string().default(""),
        keywords: z.array(z.string()).default([]),
        link: z.string().url().optional().or(z.literal(""))
      })
      .parse(req.body);
    const item = await addCuratedSolution({
      ...body,
      keywords: normalizeKeywords(body.keywords),
      link: body.link || undefined
    });
    await safelyReindex();
    res.status(201).json(item);
  } catch (error) {
    next(error);
  }
});

app.post("/api/curation/parse", async (req, res, next) => {
  try {
    const body = z.object({ text: z.string().min(1), ai: aiSchema }).parse(req.body);
    res.json(await parseCurationFromText(body.text, body.ai));
  } catch (error) {
    next(error);
  }
});

app.post("/api/close-notes", async (req, res, next) => {
  try {
    const body = z.object({ issue: z.string().min(1), enhance: z.boolean().default(false), config: z.any().optional(), ai: aiSchema }).parse(req.body);
    const documents = await getAllDocuments();
    const results = performLocalSearch(body.issue, documents, ["solution"], normalizeConfig(body.config));
    const match = results.solution[0];
    const notes = body.enhance ? await enhanceCloseNotes(body.issue, match, body.ai) : closeNotesFromMatch(body.issue, match);
    res.json({ notes, match });
  } catch (error) {
    next(error);
  }
});

app.post("/api/analyze-causes", async (req, res, next) => {
  try {
    const body = z.object({ documents: z.array(z.any()).default([]), query: z.string().default("") }).parse(req.body);
    let documents = body.documents as SearchDocument[];
    if (!documents.length && body.query) {
      const all = await getAllDocuments();
      documents = performLocalSearch(body.query, all, ["solution"], defaultSearchConfig).solution;
    }
    res.json({ causes: summarizeCauses(documents) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/draft-email", async (req, res, next) => {
  try {
    const body = z
      .object({
        ticket: z.string().default("N/A"),
        userName: z.string().default("Valued User"),
        userEmail: z.string().optional(),
        priority: z.string().default("Medium"),
        issue: z.string().min(1),
          config: z.any().optional(),
          ai: aiSchema
      })
      .parse(req.body);
    const documents = await getAllDocuments();
    const match = performLocalSearch(body.issue, documents, ["solution"], normalizeConfig(body.config)).solution[0];
    const email = await draftEmail({ ...body, matchedSolution: match, ai: body.ai });
    res.json({ email, match });
  } catch (error) {
    next(error);
  }
});

app.post("/api/agent", async (req, res, next) => {
  try {
    const body = z.object({ query: z.string().min(1), config: z.any().optional(), ai: aiSchema, webSearch: z.boolean().default(true) }).parse(req.body);
    const documents = await getAllDocuments();
    const results = performLocalSearch(body.query, documents, ["solution", "kb", "problem"], normalizeConfig(body.config));
    const context = [...results.solution, ...results.kb, ...results.problem].slice(0, 8);
    const answer = await generateAgentAnswer(body.query, context, body.ai, body.webSearch);
    res.json({ ...answer, context });
  } catch (error) {
    next(error);
  }
});

app.post("/api/reindex", async (_req, res, next) => {
  try {
    const ok = await safelyReindex();
    res.json({ ok });
  } catch (error) {
    next(error);
  }
});

app.get("/api/export/:type", async (req, res, next) => {
  try {
    const snapshot = await getSnapshot();
    const type = req.params.type;
    const payload =
      type === "solutions"
        ? snapshot.solutions
        : type === "kb"
          ? snapshot.kbArticles
          : type === "problem"
            ? snapshot.problems
            : type === "curated"
              ? snapshot.curated
              : null;
    if (!payload) return res.status(400).json({ error: "Invalid export type" });
    res.setHeader("Content-Disposition", `attachment; filename="${type}.json"`);
    return res.json(payload);
  } catch (error) {
    return next(error);
  }
});

app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const message = error instanceof Error ? error.message : "Unexpected server error";
  const status = error instanceof z.ZodError ? 400 : 500;
  res.status(status).json({ error: message });
});

async function boot() {
  await initializeDatabase();
  await safelyReindex();
  app.listen(config.port, () => {
    console.log(`Quantum Resolve API listening on http://localhost:${config.port}`);
  });
}

async function safelyReindex() {
  try {
    return await reindexMeilisearch(await getAllDocuments());
  } catch (error) {
    console.warn("Meilisearch reindex skipped:", error instanceof Error ? error.message : error);
    return false;
  }
}

function closeNotesFromMatch(issue: string, match?: SearchDocument) {
  if (!match) return "No similar past solutions found.";
  const payload = match.payload as { issue?: string; cause?: string; resolution?: string };
  return `Issue: ${payload.issue || issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution: ${
    payload.resolution || "No resolution documented."
  }`;
}

function normalizeKeywords(keywords: string[]) {
  return [...new Set(keywords.map((keyword) => keyword.trim().toLowerCase()).filter(Boolean))];
}

void boot();
