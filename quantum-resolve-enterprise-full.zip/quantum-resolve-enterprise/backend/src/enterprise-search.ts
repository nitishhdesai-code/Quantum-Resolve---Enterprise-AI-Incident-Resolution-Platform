import { config } from "./config.js";
import { isMeiliHealthy, searchMeiliCandidates } from "./meilisearch.js";
import type { Category, SearchDocument } from "./types.js";

type Provider = "meilisearch" | "opensearch" | "elasticsearch" | "solr";

const INDEX = "quantum_documents";

export async function searchProviderHealth() {
  const [meilisearch, opensearch, elasticsearch, solr] = await Promise.all([
    isMeiliHealthy(),
    pingJson(config.openSearchHost, config.openSearchApiKey),
    pingJson(config.elasticsearchHost, config.elasticsearchApiKey),
    pingSolr()
  ]);
  return { meilisearch, opensearch, elasticsearch, solr };
}

export async function searchEnterpriseCandidates(query: string, categories: Category[], limit = 120, preferredProvider?: string) {
  const provider = normalizedProvider(preferredProvider);
  if (provider === "meilisearch") return searchMeiliCandidates(query, categories, limit);
  if (provider === "solr") return searchSolr(query, categories, limit);
  if (provider === "opensearch") return searchOpenSearch(config.openSearchHost, config.openSearchApiKey, query, categories, limit);
  return searchOpenSearch(config.elasticsearchHost, config.elasticsearchApiKey, query, categories, limit);
}

export function activeSearchProvider(preferredProvider?: string) {
  return normalizedProvider(preferredProvider);
}

function normalizedProvider(preferredProvider = config.searchEngine): Provider {
  return preferredProvider === "opensearch" ||
    preferredProvider === "elasticsearch" ||
    preferredProvider === "solr"
    ? preferredProvider
    : "meilisearch";
}

async function pingJson(host: string, apiKey?: string) {
  try {
    const response = await fetch(host, { headers: authHeaders(apiKey) });
    return response.ok;
  } catch {
    return false;
  }
}

async function pingSolr() {
  try {
    const response = await fetch(`${config.solrHost}/solr/admin/cores?action=STATUS&wt=json`);
    return response.ok;
  } catch {
    return false;
  }
}

async function searchOpenSearch(
  host: string,
  apiKey: string,
  query: string,
  categories: Category[],
  limit: number
) {
  const response = await fetch(`${host}/${INDEX}/_search`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(apiKey)
    },
    body: JSON.stringify({
      size: limit,
      query: {
        bool: {
          must: [
            {
              multi_match: {
                query,
                fields: ["title^4", "description^2", "content", "keywords^2"],
                fuzziness: "AUTO",
                type: "best_fields"
              }
            }
          ],
          filter: categories.length ? [{ terms: { type: categories } }] : []
        }
      }
    })
  }).catch(() => null);

  if (!response?.ok) return null;
  const payload = (await response.json()) as { hits?: { hits?: { _source?: SearchDocument }[] } };
  return payload.hits?.hits?.map((hit) => hit._source).filter(Boolean) as SearchDocument[] | undefined || null;
}

async function searchSolr(query: string, categories: Category[], limit: number) {
  const params = new URLSearchParams({
    q: query || "*:*",
    defType: "edismax",
    qf: "title^4 description^2 content keywords^2",
    rows: String(limit),
    wt: "json"
  });
  if (categories.length) params.set("fq", `type:(${categories.join(" OR ")})`);
  const response = await fetch(`${config.solrHost}/solr/${INDEX}/select?${params}`).catch(() => null);
  if (!response?.ok) return null;
  const payload = (await response.json()) as { response?: { docs?: SearchDocument[] } };
  return payload.response?.docs || null;
}

function authHeaders(apiKey?: string): Record<string, string> {
  return apiKey ? { Authorization: `ApiKey ${apiKey}` } : {};
}
