import { acronymMap, stopWords, synonymMap } from "./data/seed-data.js";
import type { Category, SearchConfig, SearchDocument, SearchResultGroup, TierRecord } from "./types.js";

export const defaultSearchConfig: SearchConfig = {
  fuzzySensitivity: 60,
  scoreThreshold: 10,
  titleWeight: 3,
  descriptionWeight: 2,
  contentWeight: 1,
  searchMode: "any",
  stemming: true,
  phonetic: false,
  synonyms: true,
  typoTolerance: true,
  acronyms: true,
  resultLimits: {
    solution: { enabled: false, value: 10 },
    kb: { enabled: false, value: 10 },
    problem: { enabled: false, value: 10 }
  }
};

export function normalizeConfig(input?: Partial<SearchConfig>): SearchConfig {
  return {
    ...defaultSearchConfig,
    ...input,
    resultLimits: {
      ...defaultSearchConfig.resultLimits,
      ...(input?.resultLimits || {})
    }
  };
}

export function getRawKeywords(query: string) {
  return query
    .toLowerCase()
    .split(/[\s,.;:()/_-]+/)
    .map((word) => word.trim())
    .filter(Boolean);
}

export function getProcessedKeywords(rawKeywords: string[], config: SearchConfig) {
  let keywords = [...rawKeywords];
  if (config.synonyms) {
    keywords = [...new Set(keywords.flatMap((keyword) => [keyword, ...(synonymMap[keyword] || [])]))];
  }
  if (config.acronyms) {
    keywords = [...new Set(keywords.flatMap((keyword) => [keyword, ...(acronymMap[keyword] || [])]))];
  }

  const criticalAcronyms = new Set(["tc", "nx", "kb", "id"]);
  let finalKeywords = keywords.filter(
    (word) => word.length > 2 && !stopWords.includes(word)
  );

  for (const raw of rawKeywords) {
    if (criticalAcronyms.has(raw) && !finalKeywords.includes(raw)) {
      finalKeywords.push(raw);
    }
  }

  if (config.stemming) {
    finalKeywords = finalKeywords.map(stem);
  }

  return [...new Set(finalKeywords)];
}

export function performLocalSearch(
  query: string,
  documents: SearchDocument[],
  categories: Category[],
  inputConfig?: Partial<SearchConfig>
): SearchResultGroup {
  const config = normalizeConfig(inputConfig);
  const rawKeywords = getRawKeywords(query);
  const processedKeywords = getProcessedKeywords(rawKeywords, config);
  const groups: SearchResultGroup = { solution: [], kb: [], problem: [] };

  if (!query.trim() || processedKeywords.length === 0) return groups;

  for (const document of documents) {
    if (!isSearchableCategory(document.type) || !categories.includes(document.type)) continue;

    const titleScore = calculateAdvancedScore(document.title, processedKeywords, config);
    const descriptionScore = calculateAdvancedScore(document.description, processedKeywords, config);
    const contentScore = calculateAdvancedScore(document.content, processedKeywords, config);

    let totalScore =
      titleScore * config.titleWeight +
      descriptionScore * config.descriptionWeight +
      contentScore * config.contentWeight;

    const fullText = `${document.title} ${document.description} ${document.content}`.toLowerCase();
    const fullTextWords = tokenize(fullText);

    if (config.searchMode === "all") {
      const allFound = rawKeywords.every((raw) => {
        const processed = config.stemming ? stem(raw) : raw;
        return (
          fullText.includes(processed) ||
          (config.typoTolerance &&
            fullTextWords.some(
              (word) => word.length > 2 && levenshtein(word, processed) / Math.max(processed.length, 1) <= typoThreshold(config)
            ))
        );
      });
      if (!allFound) totalScore = 0;
    }

    if (config.searchMode === "exact" && !fullText.includes(query.toLowerCase())) {
      totalScore = 0;
    }

    if (scorePassesThreshold(totalScore, processedKeywords.length, config)) {
      groups[document.type].push({ ...document, score: Number(totalScore.toFixed(3)) });
    }
  }

  for (const key of ["solution", "kb", "problem"] as const) {
    groups[key].sort((a, b) => (b.score || 0) - (a.score || 0));
    const limit = config.resultLimits[key];
    if (limit?.enabled) groups[key] = groups[key].slice(0, limit.value);
  }

  return groups;
}

export function predictTier(query: string, tiers: TierRecord[], configInput?: Partial<SearchConfig>, accuracy = 0.5) {
  const config = normalizeConfig(configInput);
  const keywords = getProcessedKeywords(getRawKeywords(query), config);
  if (keywords.length === 0) return null;

  let best: TierRecord | null = null;
  let highestScore = -1;

  for (const item of tiers) {
    const itemText = `${item.category} ${item.tier1} ${item.tier2} ${item.tier3}`;
    const score = calculateAdvancedScore(itemText, keywords, config);
    if (score > highestScore) {
      highestScore = score;
      best = item;
    }
  }

  const normalized = highestScore / keywords.length;
  return best && normalized >= accuracy ? { ...best, confidence: Number(normalized.toFixed(2)) } : null;
}

export function summarizeCauses(documents: SearchDocument[]) {
  const causes = documents
    .filter((doc) => doc.type === "solution")
    .map((doc) => {
      const payload = doc.payload as { cause?: string };
      return { cause: (payload.cause || "").trim(), score: doc.score || 0 };
    })
    .filter((item) => item.cause);

  const buckets = new Map<string, { cause: string; count: number; bestScore: number }>();
  for (const item of causes) {
    const key = normalizeCause(item.cause);
    if (!key) continue;
    const existing = buckets.get(key);
    if (!existing) {
      buckets.set(key, { cause: item.cause, count: 1, bestScore: item.score });
    } else {
      existing.count += 1;
      existing.bestScore = Math.max(existing.bestScore, item.score);
      if (item.cause.length > existing.cause.length && item.cause.length < 220) existing.cause = item.cause;
    }
  }

  return [...buckets.values()]
    .sort((a, b) => b.count - a.count || b.bestScore - a.bestScore)
    .slice(0, 10)
    .map(({ cause, count }) => ({ cause, count }));
}

function normalizeCause(cause: string) {
  return cause
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\b(the|a|an|and|or|of|to|in|for|with|due|because|caused|by|issue|problem|error)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function calculateAdvancedScore(fieldText: string, keywords: string[], config: SearchConfig) {
  if (!fieldText) return 0;
  const textLower = fieldText.toLowerCase();
  const textWords = tokenize(textLower);
  let fieldScore = 0;

  for (const keyword of keywords) {
    let keywordScore = 0;
    if (matchesKeyword(textLower, textWords, keyword)) {
      keywordScore = keyword.length <= 3 ? 1.2 : 1;
    } else if (
      config.typoTolerance &&
      textWords.some((word) => word.length > 2 && levenshtein(word, keyword) / Math.max(keyword.length, 1) <= typoThreshold(config))
    ) {
      keywordScore = 0.75;
    } else if (config.phonetic && textWords.some((word) => soundex(word) === soundex(keyword))) {
      keywordScore = 0.5;
    }
    fieldScore += keywordScore;
  }

  return fieldScore;
}

function scorePassesThreshold(rawScore: number, keywordCount: number, config: SearchConfig) {
  if (rawScore <= 0) return false;
  const weightedCapacity = Math.max(1, keywordCount * (config.titleWeight + config.descriptionWeight + config.contentWeight));
  const normalized = Math.min(100, (rawScore / weightedCapacity) * 100);
  return normalized >= config.scoreThreshold;
}

function matchesKeyword(text: string, words: string[], keyword: string) {
  if (keyword.length <= 3) return words.includes(keyword);
  return text.includes(keyword);
}

function tokenize(text: string) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .map((word) => word.trim())
    .filter((word) => word.length > 1);
}

function stem(word: string) {
  return word.replace(/(ing|s|ed)$/i, "");
}

function typoThreshold(config: SearchConfig) {
  return 1 - config.fuzzySensitivity / 100;
}

function levenshtein(s1: string, s2: string) {
  const m = s1.length;
  const n = s2.length;
  if (!m) return n;
  if (!n) return m;

  const matrix = Array.from({ length: m + 1 }, (_, i) => [i]);
  for (let j = 1; j <= n; j += 1) matrix[0][j] = j;

  for (let i = 1; i <= m; i += 1) {
    for (let j = 1; j <= n; j += 1) {
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + (s1[i - 1] === s2[j - 1] ? 0 : 1)
      );
    }
  }
  return matrix[m][n];
}

function soundex(value: string) {
  const chars = value.toLowerCase().split("");
  const first = chars.shift() || "";
  const codes: Record<string, string> = {
    a: "",
    e: "",
    i: "",
    o: "",
    u: "",
    b: "1",
    f: "1",
    p: "1",
    v: "1",
    c: "2",
    g: "2",
    j: "2",
    k: "2",
    q: "2",
    s: "2",
    x: "2",
    z: "2",
    d: "3",
    t: "3",
    l: "4",
    m: "5",
    n: "5",
    r: "6"
  };

  const encoded = chars
    .map((char) => codes[char] || "")
    .filter((code, index, array) => (index === 0 ? code !== codes[first] : code !== array[index - 1]))
    .join("");

  return `${first}${encoded}000`.slice(0, 4).toUpperCase();
}

function isSearchableCategory(type: Category): type is "solution" | "kb" | "problem" {
  return type === "solution" || type === "kb" || type === "problem";
}
