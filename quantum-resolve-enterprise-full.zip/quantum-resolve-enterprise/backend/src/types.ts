export type Category = "solution" | "kb" | "problem" | "curated";
export type AiProvider = "gemini" | "openai" | "anthropic" | "mistral" | "azure-openai" | "custom";

export interface AiSettings {
  enabled?: boolean;
  provider?: AiProvider;
  model?: string;
  apiKey?: string;
  endpoint?: string;
  grounding?: boolean;
  temperature?: number;
}

export interface Solution {
  id: string;
  tier: string;
  tier1: string;
  tier2: string;
  tier3: string;
  issue: string;
  cause: string;
  resolution: string;
  keywords: string[];
  link?: string;
}

export interface KbArticle {
  id: string;
  number: string;
  title: string;
  keywords: string[];
  link?: string;
}

export interface ProblemRecord {
  id: string;
  problemId: string;
  title: string;
  keywords: string[];
  application?: string;
  eit?: string;
  deliveryId?: string;
  status?: string;
  eitLink?: string;
  problemLink?: string;
  fdtdLink?: string;
  link?: string;
}

export interface TierRecord {
  category: string;
  tier1: string;
  tier2: string;
  tier3: string;
}

export interface SearchConfig {
  fuzzySensitivity: number;
  scoreThreshold: number;
  titleWeight: number;
  descriptionWeight: number;
  contentWeight: number;
  searchMode: "any" | "all" | "exact";
  stemming: boolean;
  phonetic: boolean;
  synonyms: boolean;
  typoTolerance: boolean;
  acronyms: boolean;
  resultLimits: Record<string, { enabled: boolean; value: number }>;
}

export interface SearchDocument {
  uid: string;
  id: string;
  type: Category;
  title: string;
  description: string;
  content: string;
  keywords: string[];
  payload: Solution | KbArticle | ProblemRecord;
  score?: number;
}

export interface SearchResultGroup {
  solution: SearchDocument[];
  kb: SearchDocument[];
  problem: SearchDocument[];
}
