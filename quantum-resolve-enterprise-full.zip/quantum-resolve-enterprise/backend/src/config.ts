import dotenv from "dotenv";

dotenv.config();

export const config = {
  port: Number(process.env.PORT || 8080),
  nodeEnv: process.env.NODE_ENV || "development",
  databaseUrl:
    process.env.DATABASE_URL ||
    "postgres://quantum:quantum@localhost:5432/quantum_resolve",
  searchEngine: process.env.SEARCH_ENGINE || "meilisearch",
  meiliHost: process.env.MEILI_HOST || "http://localhost:7700",
  meiliMasterKey: process.env.MEILI_MASTER_KEY || "quantum-local-master-key",
  openSearchHost: process.env.OPENSEARCH_HOST || "http://localhost:9200",
  openSearchApiKey: process.env.OPENSEARCH_API_KEY || "",
  elasticsearchHost: process.env.ELASTICSEARCH_HOST || "http://localhost:9200",
  elasticsearchApiKey: process.env.ELASTICSEARCH_API_KEY || "",
  solrHost: process.env.SOLR_HOST || "http://localhost:8983",
  frontendOrigin: process.env.FRONTEND_ORIGIN || "http://localhost:5173",
  geminiApiKey: process.env.GEMINI_API_KEY || "",
  geminiModel: process.env.GEMINI_MODEL || "gemini-2.0-flash"
};
