import { config } from "./config.js";
import { synonymMap } from "./data/seed-data.js";
import type { Category, SearchDocument } from "./types.js";

const INDEX_UID = "quantum_documents";

export async function isMeiliHealthy() {
  try {
    const response = await fetch(`${config.meiliHost}/health`, {
      headers: authHeaders(false)
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function reindexMeilisearch(documents: SearchDocument[]) {
  if (!(await isMeiliHealthy())) return false;

  await request("/indexes", {
    method: "POST",
    body: JSON.stringify({ uid: INDEX_UID, primaryKey: "uid" }),
    ignoreStatus: [400, 409]
  });

  await request(`/indexes/${INDEX_UID}/settings`, {
    method: "PATCH",
    body: JSON.stringify({
      searchableAttributes: ["title", "description", "content", "keywords"],
      displayedAttributes: ["*"],
      filterableAttributes: ["type"],
      sortableAttributes: ["score"],
      typoTolerance: {
        enabled: true,
        minWordSizeForTypos: {
          oneTypo: 4,
          twoTypos: 8
        }
      },
      synonyms: synonymMap
    })
  });

  await request(`/indexes/${INDEX_UID}/documents`, {
    method: "POST",
    body: JSON.stringify(documents)
  });

  return true;
}

export async function searchMeiliCandidates(query: string, categories: Category[], limit = 120) {
  if (!(await isMeiliHealthy())) return null;

  const filters = categories
    .filter((category) => category === "solution" || category === "kb" || category === "problem")
    .map((category) => `type = "${category}"`);

  const response = await request(`/indexes/${INDEX_UID}/search`, {
    method: "POST",
    body: JSON.stringify({
      q: query,
      limit,
      filter: filters.length ? filters.join(" OR ") : undefined,
      attributesToHighlight: ["title", "description", "content"]
    }),
    ignoreStatus: [404]
  });

  if (!response.ok) return null;
  const payload = (await response.json()) as { hits?: SearchDocument[] };
  return payload.hits || [];
}

async function request(
  path: string,
  options: RequestInit & { ignoreStatus?: number[] } = {}
) {
  const response = await fetch(`${config.meiliHost}${path}`, {
    ...options,
    headers: {
      ...authHeaders(true),
      ...(options.headers || {})
    }
  });

  if (!response.ok && !options.ignoreStatus?.includes(response.status)) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Meilisearch ${response.status}: ${detail}`);
  }
  return response;
}

function authHeaders(withContentType: boolean) {
  return {
    ...(withContentType ? { "Content-Type": "application/json" } : {}),
    Authorization: `Bearer ${config.meiliMasterKey}`
  };
}

