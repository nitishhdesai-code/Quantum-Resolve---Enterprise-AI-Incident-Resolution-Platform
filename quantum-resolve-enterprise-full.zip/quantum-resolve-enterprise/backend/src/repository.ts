import { pool, setDatabaseReady, isDatabaseReady } from "./db.js";
import {
  kbArticles as seedKbArticles,
  problems as seedProblems,
  solutions as seedSolutions,
  tiers as seedTiers
} from "./data/seed-data.js";
import type {
  Category,
  KbArticle,
  ProblemRecord,
  SearchDocument,
  Solution,
  TierRecord
} from "./types.js";

const memory = {
  solutions: [...seedSolutions],
  kbArticles: [...seedKbArticles],
  problems: [...seedProblems],
  tiers: [...seedTiers]
};

export async function initializeDatabase() {
  try {
    await pool.query(`
      create table if not exists solutions (
        id text primary key,
        tier text not null default '',
        tier1 text not null default '',
        tier2 text not null default '',
        tier3 text not null default '',
        issue text not null,
        cause text not null default '',
        resolution text not null default '',
        keywords text[] not null default '{}',
        link text
      );

      create table if not exists kb_articles (
        id text primary key,
        number text not null,
        title text not null,
        keywords text[] not null default '{}',
        link text
      );

      create table if not exists problems (
        id text primary key,
        problem_id text not null,
        title text not null,
        keywords text[] not null default '{}',
        application text,
        eit text,
        delivery_id text,
        status text,
        eit_link text,
        problem_link text,
        fdtd_link text,
        link text
      );

      create table if not exists tiers (
        id bigserial primary key,
        category text not null,
        tier1 text not null,
        tier2 text not null,
        tier3 text not null,
        unique (category, tier1, tier2, tier3)
      );
    `);

    for (const item of seedSolutions) {
      await pool.query(
        `insert into solutions
          (id, tier, tier1, tier2, tier3, issue, cause, resolution, keywords, link)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
         on conflict (id) do nothing`,
        [
          item.id,
          item.tier,
          item.tier1,
          item.tier2,
          item.tier3,
          item.issue,
          item.cause,
          item.resolution,
          item.keywords,
          item.link || null
        ]
      );
    }

    for (const item of seedKbArticles) {
      await pool.query(
        `insert into kb_articles (id, number, title, keywords, link)
         values ($1,$2,$3,$4,$5)
         on conflict (id) do nothing`,
        [item.id, item.number, item.title, item.keywords, item.link || null]
      );
    }

    for (const item of seedProblems) {
      await pool.query(
        `insert into problems
          (id, problem_id, title, keywords, application, eit, delivery_id, status, eit_link, problem_link, fdtd_link, link)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
         on conflict (id) do nothing`,
        [
          item.id,
          item.problemId,
          item.title,
          item.keywords,
          item.application || null,
          item.eit || null,
          item.deliveryId || null,
          item.status || null,
          item.eitLink || null,
          item.problemLink || null,
          item.fdtdLink || null,
          item.link || null
        ]
      );
    }

    for (const item of seedTiers) {
      await pool.query(
        `insert into tiers (category, tier1, tier2, tier3)
         values ($1,$2,$3,$4)
         on conflict (category, tier1, tier2, tier3) do nothing`,
        [item.category, item.tier1, item.tier2, item.tier3]
      );
    }

    setDatabaseReady(true);
    return true;
  } catch (error) {
    setDatabaseReady(false);
    console.warn(
      "PostgreSQL is unavailable. API will run with in-memory seed data until the database is available.",
      error instanceof Error ? error.message : error
    );
    return false;
  }
}

export async function getSolutions(): Promise<Solution[]> {
  if (!isDatabaseReady()) return [...memory.solutions];
  const { rows } = await pool.query("select * from solutions order by id");
  return rows.map(rowToSolution);
}

export async function getKbArticles(): Promise<KbArticle[]> {
  if (!isDatabaseReady()) return [...memory.kbArticles];
  const { rows } = await pool.query("select * from kb_articles order by id");
  return rows.map(rowToKbArticle);
}

export async function getProblems(): Promise<ProblemRecord[]> {
  if (!isDatabaseReady()) return [...memory.problems];
  const { rows } = await pool.query("select * from problems order by id");
  return rows.map(rowToProblem);
}

export async function getTiers(): Promise<TierRecord[]> {
  if (!isDatabaseReady()) return [...memory.tiers];
  const { rows } = await pool.query("select category, tier1, tier2, tier3 from tiers order by id");
  return rows;
}

export async function getCuratedSolutions(): Promise<Solution[]> {
  const all = await getSolutions();
  return all.filter((item) => item.id.startsWith("curated_") || item.tier === "Curated");
}

export async function addCuratedSolution(input: Omit<Solution, "id" | "tier"> & { id?: string }) {
  const solution: Solution = {
    id: input.id || `curated_${Date.now()}`,
    tier: "Curated",
    tier1: input.tier1 || "",
    tier2: input.tier2 || "",
    tier3: input.tier3 || "",
    issue: input.issue,
    cause: input.cause || "",
    resolution: input.resolution,
    keywords: input.keywords || [],
    link: input.link
  };

  if (!isDatabaseReady()) {
    memory.solutions.push(solution);
    return solution;
  }

  await pool.query(
    `insert into solutions (id, tier, tier1, tier2, tier3, issue, cause, resolution, keywords, link)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     on conflict (id) do update set
       tier = excluded.tier,
       tier1 = excluded.tier1,
       tier2 = excluded.tier2,
       tier3 = excluded.tier3,
       issue = excluded.issue,
       cause = excluded.cause,
       resolution = excluded.resolution,
       keywords = excluded.keywords,
       link = excluded.link`,
    [
      solution.id,
      solution.tier,
      solution.tier1,
      solution.tier2,
      solution.tier3,
      solution.issue,
      solution.cause,
      solution.resolution,
      solution.keywords,
      solution.link || null
    ]
  );
  return solution;
}

export async function updateItemKeywords(type: Category, id: string, keywords: string[]) {
  if (!isDatabaseReady()) {
    const item = findMemoryItem(type, id);
    if (item) item.keywords = keywords;
    return item;
  }

  const table = tableFor(type);
  await pool.query(`update ${table} set keywords = $1 where id = $2`, [keywords, id]);
  return getItem(type, id);
}

export async function updateItemLink(type: Category, id: string, link: string) {
  if (!isDatabaseReady()) {
    const item = findMemoryItem(type, id);
    if (item) item.link = link;
    return item;
  }

  const table = tableFor(type);
  await pool.query(`update ${table} set link = $1 where id = $2`, [link, id]);
  return getItem(type, id);
}

export async function getItem(type: Category, id: string) {
  if (type === "solution" || type === "curated") {
    return (await getSolutions()).find((item) => item.id === id);
  }
  if (type === "kb") {
    return (await getKbArticles()).find((item) => item.id === id);
  }
  if (type === "problem") {
    return (await getProblems()).find((item) => item.id === id);
  }
  return undefined;
}

export async function getAllDocuments(): Promise<SearchDocument[]> {
  const [solutions, kbArticles, problems] = await Promise.all([
    getSolutions(),
    getKbArticles(),
    getProblems()
  ]);

  return [
    ...solutions.map(solutionToDocument),
    ...kbArticles.map(kbToDocument),
    ...problems.map(problemToDocument)
  ];
}

export async function getSnapshot() {
  const [solutions, kbArticles, problems, tiers, curated] = await Promise.all([
    getSolutions(),
    getKbArticles(),
    getProblems(),
    getTiers(),
    getCuratedSolutions()
  ]);

  return {
    solutions,
    kbArticles,
    problems,
    tiers,
    curated,
    stats: {
      solutions: solutions.length,
      kbArticles: kbArticles.length,
      problems: problems.length
    }
  };
}

function rowToSolution(row: Record<string, unknown>): Solution {
  return {
    id: String(row.id),
    tier: String(row.tier || ""),
    tier1: String(row.tier1 || ""),
    tier2: String(row.tier2 || ""),
    tier3: String(row.tier3 || ""),
    issue: String(row.issue || ""),
    cause: String(row.cause || ""),
    resolution: String(row.resolution || ""),
    keywords: normalizeArray(row.keywords),
    link: row.link ? String(row.link) : undefined
  };
}

function rowToKbArticle(row: Record<string, unknown>): KbArticle {
  return {
    id: String(row.id),
    number: String(row.number || ""),
    title: String(row.title || ""),
    keywords: normalizeArray(row.keywords),
    link: row.link ? String(row.link) : undefined
  };
}

function rowToProblem(row: Record<string, unknown>): ProblemRecord {
  return {
    id: String(row.id),
    problemId: String(row.problem_id || ""),
    title: String(row.title || ""),
    keywords: normalizeArray(row.keywords),
    application: row.application ? String(row.application) : undefined,
    eit: row.eit ? String(row.eit) : undefined,
    deliveryId: row.delivery_id ? String(row.delivery_id) : undefined,
    status: row.status ? String(row.status) : undefined,
    eitLink: row.eit_link ? String(row.eit_link) : undefined,
    problemLink: row.problem_link ? String(row.problem_link) : undefined,
    fdtdLink: row.fdtd_link ? String(row.fdtd_link) : undefined,
    link: row.link ? String(row.link) : undefined
  };
}

function normalizeArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  return [];
}

function solutionToDocument(item: Solution): SearchDocument {
  return {
    uid: `solution:${item.id}`,
    id: item.id,
    type: "solution",
    title: item.issue,
    description: `${item.cause} ${item.resolution}`,
    content: `${item.tier} ${item.tier1} ${item.tier2} ${item.tier3} ${item.keywords.join(" ")}`,
    keywords: item.keywords,
    payload: item
  };
}

function kbToDocument(item: KbArticle): SearchDocument {
  return {
    uid: `kb:${item.id}`,
    id: item.id,
    type: "kb",
    title: `${item.number}: ${item.title}`,
    description: "",
    content: item.keywords.join(" "),
    keywords: item.keywords,
    payload: item
  };
}

function problemToDocument(item: ProblemRecord): SearchDocument {
  return {
    uid: `problem:${item.id}`,
    id: item.id,
    type: "problem",
    title: item.title,
    description: `${item.application || ""} ${item.problemId} ${item.eit || ""} ${item.deliveryId || ""} ${item.status || ""}`,
    content: `${item.keywords.join(" ")} ${item.eitLink || ""} ${item.problemLink || ""} ${item.fdtdLink || ""}`,
    keywords: item.keywords,
    payload: item
  };
}

function tableFor(type: Category) {
  if (type === "kb") return "kb_articles";
  if (type === "problem") return "problems";
  return "solutions";
}

function findMemoryItem(type: Category, id: string): Solution | KbArticle | ProblemRecord | undefined {
  if (type === "kb") return memory.kbArticles.find((item) => item.id === id);
  if (type === "problem") return memory.problems.find((item) => item.id === id);
  return memory.solutions.find((item) => item.id === id);
}

