import type { KbArticle, ProblemRecord, Solution, TierRecord } from "../types.js";

export const stopWords = [
  "a",
  "an",
  "and",
  "the",
  "is",
  "it",
  "in",
  "on",
  "for",
  "with",
  "to",
  "of",
  "how",
  "issue",
  "problem",
  "error",
  "unable",
  "what",
  "why",
  "has",
  "have",
  "are",
  "please",
  "need"
];

export const acronymMap: Record<string, string[]> = {
  tc: ["teamcenter"],
  nx: ["unigraphics", "cad"],
  cad: ["computer aided design"],
  fms: ["file management system", "fms cache"],
  fcc: ["fms client cache"],
  db: ["database"],
  kb: ["knowledge base"],
  eco: ["engineering change order"],
  rac: ["rich client", "teamcenter rich client"]
};

export const synonymMap: Record<string, string[]> = {
  slow: ["sluggish", "lag", "delay", "hang", "freeze", "unresponsive", "slowness"],
  performance: ["speed", "efficiency", "optimization", "throughput", "responsiveness"],
  error: ["issue", "problem", "bug", "fault", "failure", "exception"],
  crash: ["hang", "freeze", "stop", "fail", "abort"],
  bug: ["defect", "glitch", "issue", "error", "problem"],
  fix: ["resolve", "repair", "correct", "solve", "remedy", "address"],
  remove: ["uninstall", "delete", "eliminate", "purge"],
  import: ["load", "upload", "transfer", "bring in"],
  export: ["save", "download", "extract", "output"],
  memory: ["ram", "heap", "allocation", "buffer"],
  network: ["connection", "internet", "connectivity", "link", "lan", "wan"],
  client: ["application", "app", "software", "program", "tool"],
  cache: ["buffer", "temporary", "temp", "staging"],
  login: ["signin", "authentication", "auth", "logon", "access"],
  startup: ["boot", "launch", "initialize", "start"],
  model: ["part", "assembly", "component", "object", "3d"],
  workflow: ["process", "procedure", "flow", "sequence"],
  release: ["publish", "approve", "finalize", "complete"],
  update: ["upgrade", "refresh", "modify"],
  timeout: ["delay", "wait", "hang", "stuck"],
  permission: ["access", "rights", "privilege", "authorization"],
  license: ["permit", "authorization", "key", "token"],
  teamcenter: ["tc", "plm", "pdm"],
  nx: ["unigraphics", "ug", "cad"]
};

export const solutions: Solution[] = [
  {
    id: "sol_001",
    tier: "User Related",
    tier1: "Performance",
    tier2: "Slowness",
    tier3: "Internet",
    issue:
      "Slowness in TC and NX. User is unable to rotate the model and changes take too long to save.",
    cause: "Internet connectivity issue on the user's current network.",
    resolution:
      "Ask the user to test from a mobile hotspot or stable alternate network. If performance improves, advise the user to work with the network team or continue from the stable connection until the primary network is corrected.",
    keywords: [
      "slowness",
      "tc",
      "teamcenter",
      "nx",
      "rotate",
      "model",
      "changes",
      "save",
      "internet",
      "hotspot",
      "mobile"
    ]
  },
  {
    id: "sol_002",
    tier: "System Related",
    tier1: "Performance",
    tier2: "Client Side",
    tier3: "--None--",
    issue:
      "Teamcenter Rich Client (RAC) is very slow during startup and general navigation.",
    cause:
      "Possible network latency between client and server, insufficient RAM, or full/corrupted FMS cache.",
    resolution:
      "1. Check network latency and escalate if latency is high.\n2. Confirm the workstation has at least 16 GB RAM.\n3. Close Teamcenter and clear the FMS/FCC cache from the user profile.\n4. Restart the client and validate navigation speed.",
    keywords: [
      "slow",
      "performance",
      "rich",
      "client",
      "rac",
      "latency",
      "network",
      "ram",
      "cache",
      "fms",
      "fcc",
      "startup",
      "navigation",
      "lag",
      "freeze"
    ]
  },
  {
    id: "sol_003",
    tier: "Admin Related",
    tier1: "User Requirement",
    tier2: "Unrelease of Object",
    tier3: "Remove Non Inventory Status",
    issue: "Remove non-inventory flag from the item.",
    cause: "The user did not have access to remove the non-inventory flag.",
    resolution:
      "Validate the request, confirm the impacted item, remove the non-inventory flag with admin access, and ask the user to verify the item status.",
    keywords: [
      "access",
      "release",
      "unrelease",
      "remove",
      "non inventory",
      "flag",
      "admin",
      "user requirement"
    ]
  }
];

export const kbArticles: KbArticle[] = [
  {
    id: "kb_001",
    number: "KB0011234",
    title:
      "Troubleshooting common performance and slowness issues in Teamcenter Rich Client",
    keywords: [
      "performance",
      "slowness",
      "troubleshooting",
      "rac",
      "rich",
      "client",
      "guide",
      "common"
    ]
  },
  {
    id: "kb_002",
    number: "KB0011235",
    title: "How to clear the FMS Client Cache (FCC) to resolve data loading errors",
    keywords: ["fms", "cache", "clear", "fcc", "data", "loading", "error", "resolve"]
  }
];

export const problems: ProblemRecord[] = [
  {
    id: "prb_001",
    problemId: "PRB0066831",
    keywords: ["data sync", "pdf", "change reference", "eco", "item", "skip"],
    application: "Teamcenter",
    eit: "EIT 17.11",
    deliveryId: "10466",
    status: "Deliverable Implemented",
    title:
      "Data Sync operation skipping the PDF file under Change References of ECO item",
    eitLink:
      "https://team.amat.com/sites/wiki/Pages/EIT/EIT%2017.11%20Teamcenter%20Release%20Notes.aspx",
    problemLink:
      "https://now.com/nav/ui/classic/params/target/problem.do%3Fsysparm_query%3Dnumber%3DPRB0058656"
  },
  {
    id: "prb_002",
    problemId: "PR-015039232",
    keywords: ["import", "015039232", "attachment", "resolve"],
    application: "NX",
    eit: "EIT 16.0",
    deliveryId: "9875",
    status: "Work In Progress",
    title: "Unable to import part file, please resolve, refer attachment.",
    eitLink: "#",
    problemLink: "#"
  }
];

export const tiers: TierRecord[] = [
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "MLO Attribute Related"
  },
  {
    category: "User related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Organization Related"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "DQT",
    tier3: "NX Drafting Tool Related"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Basic Training for Teamcenter"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Object Related"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Designed From Related"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Trade Restricted",
    tier3: "Trade Restricted"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Workflow",
    tier3: "Peer Review Workflow Procedure"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "ECO",
    tier3: "CTR E-Redline Procedure"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "ECO",
    tier3: "How to cancel a Teamcenter ECO?"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "ECO",
    tier3: "Other"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Attach Alias ID / Search Alias ID"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    tier3: "Toggle Precise / Imprecise in Structure Manager"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "AMAT Custom Utilities",
    tier3: "Email notification"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "Request Multisite Delete",
    tier3: "Precise BOM"
  },
  {
    category: "Training related",
    tier1: "AMAT Custom",
    tier2: "ECO Failure",
    tier3: "Unable to update AMAT Part replacement item"
  }
];

