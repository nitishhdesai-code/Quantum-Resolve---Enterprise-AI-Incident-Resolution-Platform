# Offline Database Guide

Quantum Resolve uses a `BootstrapPayload` JSON shape for offline data.

## Current Preview Data Source

The preview at `http://localhost:5180` is a static build from:

```text
frontend/dist
```

Because the API server is not running in this preview, the app loads data in this order:

1. `http://localhost:8080/api/bootstrap` if the backend is available.
2. Browser `localStorage` key `quantum-resolve-bootstrap-v2` if a snapshot was cached earlier.
3. Bundled fallback data from `frontend/src/lib/fallbackData.ts`.

The yellow `Offline Ready` status means the current preview is using local cached/bundled data, not PostgreSQL.

For real 50k-record usage, the application now stores snapshots in IndexedDB and builds a Web Worker search index. This is the enterprise offline path. The `.ts` fallback file should remain only a small emergency/demo dataset.

## Offline JSON Format

The complete offline snapshot has this shape:

```json
{
  "solutions": [],
  "kbArticles": [],
  "problems": [],
  "tiers": [],
  "curated": [],
  "stats": {
    "solutions": 0,
    "kbArticles": 0,
    "problems": 0
  },
  "dictionaries": {
    "stopWords": [],
    "synonymMap": {},
    "acronymMap": {}
  },
  "defaultSearchConfig": {
    "fuzzySensitivity": 60,
    "scoreThreshold": 10,
    "titleWeight": 3,
    "descriptionWeight": 2,
    "contentWeight": 1,
    "searchMode": "any",
    "stemming": true,
    "phonetic": false,
    "synonyms": true,
    "typoTolerance": true,
    "acronyms": true,
    "resultLimits": {
      "solution": { "enabled": false, "value": 10 },
      "kb": { "enabled": false, "value": 10 },
      "problem": { "enabled": false, "value": 10 }
    }
  },
  "services": {
    "database": false,
    "meilisearch": false,
    "ai": false
  }
}
```

## Record Formats

### Solution

```json
{
  "id": "sol_001",
  "tier": "User Related",
  "tier1": "Performance",
  "tier2": "Slowness",
  "tier3": "Internet",
  "issue": "Teamcenter is slow during startup.",
  "cause": "FMS cache is corrupted.",
  "resolution": "Close Teamcenter, clear FCC/FMS cache, restart, and validate.",
  "keywords": ["teamcenter", "slow", "cache", "fms"],
  "link": "https://example.com/reference"
}
```

### KB Article

```json
{
  "id": "kb_001",
  "number": "KB0011234",
  "title": "How to clear FMS Client Cache",
  "keywords": ["fms", "cache", "fcc", "teamcenter"],
  "link": "https://example.com/kb"
}
```

### Problem Record

```json
{
  "id": "prb_001",
  "problemId": "PRB0066831",
  "title": "Data Sync skips PDF under ECO change references",
  "keywords": ["data sync", "pdf", "eco"],
  "application": "Teamcenter",
  "eit": "EIT 17.11",
  "deliveryId": "10466",
  "status": "Deliverable Implemented",
  "eitLink": "https://example.com/eit",
  "problemLink": "https://example.com/problem",
  "fdtdLink": "https://example.com/fdtd"
}
```

### Tier Record

```json
{
  "category": "Training related",
  "tier1": "AMAT Custom",
  "tier2": "Teamcenter",
  "tier3": "Basic Training for Teamcenter"
}
```

## How To Create Offline Data

### Option 1: Import A 50k Offline Database At Runtime

Use this for normal enterprise offline demos and field use.

1. Prepare a `.json` or `.jsonl` file.
2. Validate it:

```bash
node tools/validate-offline-db.mjs path/to/offline-snapshot.json
```

3. Open Quantum Resolve.
4. Click `Import JSON/JSONL`.
5. The app stores the dataset in IndexedDB and builds the search index in a Web Worker.

This is the best approach for 50k records because it avoids rebuilding the UI bundle for every data update.

### Option 2: Bundle Offline Data Into The App

Replace:

```text
frontend/public/offline/knowledge-base.json
```

Do not put 50k records in `frontend/src/lib/fallbackData.ts`. Keep `fallbackData.ts` small.

Then rebuild:

```bash
npm run build
```

The rebuilt `frontend/dist` can run offline and will use that bundled data.

### Option 3: Cache A Backend Snapshot For Offline Use

1. Start PostgreSQL and the backend.
2. Load data into PostgreSQL.
3. Open the app while online.
4. The frontend calls `/api/bootstrap` and stores the full snapshot into browser localStorage.
5. Later, if the backend is unavailable, the app uses the cached snapshot.

Note: current implementation stores the snapshot in IndexedDB, not localStorage, because localStorage is too small for 50k records.

### Option 4: PostgreSQL Source Of Truth

The backend creates these PostgreSQL tables:

```text
solutions
kb_articles
problems
tiers
```

Search data is indexed into Meilisearch when available, but PostgreSQL remains the durable source. If Meilisearch is down, the backend falls back to local scoring over PostgreSQL records.

## JSONL Format For Large Imports

JSONL is recommended when data is exported from ETL jobs because each line is one record:

```jsonl
{"type":"solution","id":"sol_100001","issue":"Teamcenter slow","cause":"FMS cache","resolution":"Clear cache","keywords":["teamcenter","cache"]}
{"type":"kb","id":"kb_100001","number":"KB0010001","title":"Clear FMS Cache","keywords":["fms","cache"]}
{"type":"problem","id":"prb_100001","problemId":"PRB0010001","title":"Data sync skips PDF","keywords":["pdf","eco"]}
{"type":"tier","category":"Training related","tier1":"AMAT Custom","tier2":"Teamcenter","tier3":"Basic Training"}
```

See:

```text
examples/offline-db.example.jsonl
examples/offline-snapshot.example.json
```
