# Teamcenter PLM CAD Demo Database

Synthetic database for testing Quantum Resolve Enterprise.

## Contents

- 100 solutions
- 100 KB articles
- 100 problem IDs
- 100 tier routes

## Files

- teamcenter-plm-demo-database.json: complete combined import snapshot
- teamcenter-plm-demo-database.jsonl: line-by-line import format
- teamcenter-plm-demo-database-parts/solutions.json
- teamcenter-plm-demo-database-parts/kb-articles.json
- teamcenter-plm-demo-database-parts/problems.json
- teamcenter-plm-demo-database-parts/tiers.json
- teamcenter-plm-demo-database-parts/dictionaries.json
- teamcenter-plm-demo-database-parts/search-config.json

## Topics Covered

- Teamcenter Rich Client, Active Workspace, FMS/FCC, Dispatcher, Workflow, BMIDE, Visualization, and Structure Manager
- NX managed mode and Siemens NX CAD
- Solid Edge, Creo, CATIA, AutoCAD Mechanical
- PLM XML export and JT translation
- FlexNet CAD license checkout
- Engineering VPN and corporate internet/network issues
- Software Center CAD/PLM installation and upgrade issues

## How To Use

1. Extract this zip.
2. Open Quantum Resolve Enterprise.
3. Click Import JSON/JSONL.
4. Select teamcenter-plm-demo-database.json or teamcenter-plm-demo-database.jsonl.
5. Search examples: "Teamcenter slow over VPN", "NX managed mode checkout failed", "FMS cache download issue", "Software Center CAD install failed", "JT translation missing".

This is synthetic demo data, not production support history.

