# Quantum Resolve Feature File Map

Use this file when you want to locate and edit one feature without searching through the whole app.

## Main App Shell

- `frontend/src/App.tsx`
  - Main screen layout
  - State management
  - Search button actions
  - Modals
  - Import/export wiring

## Guide Me

- `frontend/src/features/guide.ts`
  - Creates the guided resolution plan
  - Builds steps, references, confidence, route, closure draft
  - Prepares internal context for AI enhancement

- `frontend/src/features/GuideWorkspace.tsx`
  - Renders the Guide Me modal UI
  - Shows steps, AI advisory, references, and closure draft

## Causes

- `frontend/src/features/causes.ts`
  - Normalizes root-cause text
  - Groups repeated causes
  - Returns top distinct causes

## Close Notes Generator

- `frontend/src/features/CloseNotesGenerator.tsx`
  - Renders the close notes input, Generate button, AI-only Enhance button, copy action, and output area

- `frontend/src/lib/offlineSearch.ts`
  - Contains the offline close-notes generator used when AI is unavailable

- `backend/src/ai.ts`
  - Contains the AI rewrite/enhancement path for professional close notes

## Mail Draft / One-Click Resolver

- `frontend/src/features/CommunicationDraftPanel.tsx`
  - Renders ticket, user, priority, issue, Draft, Copy, and Mail controls

- `backend/src/ai.ts`
  - Generates AI-enhanced email drafts when an AI provider is configured

- `backend/src/index.ts`
  - Exposes the `/api/ai/email` endpoint used by the frontend

## AI Model Integration

- `frontend/src/features/AiModelSettings.tsx`
  - Renders provider selection, model selection, custom model ID, endpoint, API key, grounding, creativity, and Gemini key test

- `frontend/src/features/searchConfig.ts`
  - Stores the editable AI model list and provider metadata

- `frontend/src/lib/browserAi.ts`
  - Runs Gemini directly from the browser for local demo fallback

- `backend/src/ai.ts`
  - Server-side AI gateway for Gemini, OpenAI-compatible, Azure OpenAI, Anthropic-compatible, and custom endpoints

## ServiceNow

- `frontend/src/features/ServiceNowConnection.tsx`
  - Renders the ServiceNow settings area
  - Currently a safe placeholder; production credentials should be handled server-side

- `frontend/src/features/SystemSettings.tsx`
  - Renders system settings, service health, ServiceNow panel, refresh, and reindex controls

## Theme

- `frontend/src/features/ThemeToggle.tsx`
  - Renders the dark/light theme button
  - Applies theme to the root document

- `frontend/src/lib/storage.ts`
  - Persists the selected theme

- `frontend/src/index.css`
  - Contains dark/light theme variables and visual styling

## Search And NLP

- `frontend/src/workers/offline-search.worker.ts`
  - Main offline NLP worker
  - BM25-style scoring
  - fuzzy typo matching
  - phonetic matching
  - phrase boost
  - proximity boost
  - tier prediction

- `frontend/src/lib/offlineSearch.ts`
  - Fallback offline search when the worker is not ready
  - Local close notes matching
  - Search document creation

- `frontend/src/lib/searchScoring.ts`
  - Shared normalized score threshold logic
  - Makes score threshold behave consistently across worker and fallback search

- `backend/src/search-utils.ts`
  - Backend search, scoring, tier prediction, and cause grouping

## AI

- `frontend/src/lib/browserAi.ts`
  - Browser Gemini fallback for local demos

- `backend/src/ai.ts`
  - Backend AI provider gateway
  - Ask and Guide AI enhancement
  - Close notes enhancement
  - Email and curation assistance

## Search Providers

- `backend/src/enterprise-search.ts`
  - Meilisearch
  - OpenSearch
  - Elasticsearch
  - Apache Solr

- `backend/src/meilisearch.ts`
  - Meilisearch index health, candidate search, and reindexing

## UI Controls And Constants

- `frontend/src/features/searchConfig.ts`
  - Search categories
  - Default search configuration
  - Search provider cards
  - AI model list

- `frontend/src/features/formControls.tsx`
  - Shared editable controls for sliders, weights, text inputs, and text areas

- `frontend/src/features/StatusPill.tsx`
  - Online/offline status indicator in the header

## Database Files

Editable packaged offline database files:

- `frontend/public/offline/solutions.json`
- `frontend/public/offline/kb-articles.json`
- `frontend/public/offline/problems.json`
- `frontend/public/offline/tiers.json`
- `frontend/public/offline/dictionaries.json`
- `frontend/public/offline/search-config.json`
- `frontend/public/offline/services.json`
- `frontend/public/offline/curated.json`

Backward-compatible combined snapshot:

- `frontend/public/offline/knowledge-base.json`

Example import files:

- `examples/teamcenter-plm-demo-database.json`
- `examples/teamcenter-plm-demo-database.jsonl`
- `examples/teamcenter-plm-demo-database-parts/solutions.json`
- `examples/teamcenter-plm-demo-database-parts/kb-articles.json`
- `examples/teamcenter-plm-demo-database-parts/problems.json`
- `examples/teamcenter-plm-demo-database-parts/tiers.json`

## Database Generator

- `tools/generate-teamcenter-plm-db.mjs`
  - Generates the Teamcenter/PLM/CAD demo database
  - Writes combined JSON, JSONL, separate example files, and packaged offline files
