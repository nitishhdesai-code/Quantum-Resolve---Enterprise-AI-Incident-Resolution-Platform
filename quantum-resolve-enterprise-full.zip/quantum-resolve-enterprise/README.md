# Quantum Resolve Enterprise

Enterprise rebuild of the original Quantum Resolve support assistant.

## Stack

- Frontend: React, TypeScript, Vite, Tailwind CSS, PWA service worker.
- Backend: Node.js, Express, TypeScript.
- Database: PostgreSQL as the source of truth.
- Search: selectable Meilisearch, OpenSearch, Elasticsearch, Apache Solr, or offline worker search, with local re-ranking and PostgreSQL/in-memory fallback.
- Offline: service worker app shell plus cached knowledge snapshot and browser-side BM25/fuzzy worker search.
- AI: optional model gateway for Gemini, OpenAI, Anthropic, Mistral, Azure OpenAI, or custom OpenAI-compatible APIs.

## Search Engine Options

Meilisearch is the best fit for this app because the data is support knowledge, not huge log analytics. It is free/open-source, lightweight, fast, typo tolerant, easy to run locally, and simpler to operate than Elasticsearch or OpenSearch for this scope.

OpenSearch, Elasticsearch, and Apache Solr are also wired as enterprise options. Set `SEARCH_ENGINE` in `backend/.env` to `meilisearch`, `opensearch`, `elasticsearch`, or `solr`, then configure the matching host/API key values.

## Run Locally

1. Start PostgreSQL and Meilisearch:

```bash
docker compose up -d
```

2. Configure the backend:

```bash
cd backend
copy .env.example .env
npm install
npm run dev
```

If Windows blocks the `tsx watch` dev runner, use the compiled API:

```bash
npm run build
node dist/index.js
```

3. Configure the frontend:

```bash
cd ../frontend
copy .env.example .env
npm install
npm run dev
```

4. Open:

```text
http://localhost:5173
```

Backend API runs at `http://localhost:8080`.

## HTML Tool Documentation

Open `docs/quantum-resolve-complete-tool-documentation.html` for the complete user, admin, online/offline, AI, search, services, data-format, and technology guide.

The earlier draft documentation remains at `docs/quantum-resolve-tool-documentation.html`.

## Optional AI

Users can open `AI Models` in the UI, choose a provider/model, paste a session API key, and enable model reasoning for Guide, Ask, close notes, emails, and curation. The backend also supports `GEMINI_API_KEY` as an environment fallback. When no key is configured, all AI-like workflows still return deterministic internal-database fallbacks.

## Preserved Features

- Search across Solutions, KB Articles, and Problem IDs.
- Advanced sensitivity, weights, result limits, search modes, synonyms, acronyms, typo tolerance, stemming, and phonetic options.
- Tier prediction.
- Cause analysis.
- Close notes generation and AI enhancement fallback.
- One-click email resolver.
- Agent chat and KB curation.
- Editable keywords and reference links.
- JSON exports for solutions, KBs, problems, and curated solutions.
- Theme switching and ServiceNow settings placeholder.

## Robustness Notes

- If Meilisearch is down, API search falls back to local scoring over PostgreSQL records.
- If PostgreSQL is down, the API still starts with seed data in memory so the app remains usable for demos.
- If the backend is unreachable, the React PWA searches the cached knowledge snapshot offline.
- Large offline snapshots are stored in IndexedDB, not localStorage.
- Offline search runs in a Web Worker so 50k+ records do not block the UI thread.
- Offline ranking uses token expansion, synonyms, acronyms, fuzzy matching, phonetics, BM25-style scoring, phrase boosts, proximity boosts, and field weighting.
- `.json` and `.jsonl` files can be imported directly from the UI.
- Curated offline records are cached locally and exported from the browser while offline.

## 50k-Record Offline Mode

Use `.json` or `.jsonl`, not TypeScript files, for real enterprise data.

Recommended operational flow:

1. Export your real support data as `offline-snapshot.json` or `offline-db.jsonl`.
2. Validate it:

```bash
node tools/validate-offline-db.mjs examples/offline-snapshot.example.json
node tools/validate-offline-db.mjs examples/offline-db.example.jsonl
```

3. Open the app and click `Import JSON/JSONL`.
4. The app normalizes the records, stores them in IndexedDB, builds a worker search index, and keeps working offline.

For a packaged demo where the app starts with your dataset, replace:

```text
frontend/public/offline/knowledge-base.json
```

with your exported snapshot, then rebuild:

```bash
npm run build
```

Record formats are documented in `OFFLINE_DATABASE_GUIDE.md`.

## Demo Database

This package includes a generated synthetic demo database with 100 solutions, 100 KB articles, and 100 problem records:

```text
examples/demo-100-database.json
examples/demo-100-database.jsonl
```

The same dataset is also packaged into:

```text
frontend/public/offline/knowledge-base.json
```

Regenerate it with:

```bash
npm run generate:demo-db
```

For the Teamcenter/PLM/CAD focused demo database with separate editable database files, run:

```bash
npm run generate:plm-demo-db
```

The app now prefers separate packaged offline files under `frontend/public/offline/`:

```text
solutions.json
kb-articles.json
problems.json
tiers.json
dictionaries.json
search-config.json
services.json
curated.json
```

See `docs/FEATURE_FILE_MAP.md` to locate the Guide Me, NLP/search, AI, provider, and database files.

## Production Hardening Still Recommended

- Add SSO/authentication and role-based access.
- Add database migrations with a tool such as Drizzle, Prisma, or Flyway.
- Add server-side audit logging for edits and curation.
- Add CI to run typecheck, tests, builds, and container scans.
- Place the API behind TLS and configure CORS for the final domain only.
