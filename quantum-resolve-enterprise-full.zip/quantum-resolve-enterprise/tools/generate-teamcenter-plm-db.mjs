import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));

const systems = [
  {
    name: "Teamcenter Rich Client",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Support",
    tier2: "Teamcenter Rich Client",
    component: "RAC client",
    object: "item revision",
    cache: "FCC/FMS and RAC workspace cache",
    installer: "Teamcenter Rich Client package",
    connector: "Teamcenter server session",
    roleGroup: "TC_ENGINEERING_USERS",
    version: "14.x"
  },
  {
    name: "Teamcenter Active Workspace",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Support",
    tier2: "Active Workspace",
    component: "AWC web client",
    object: "change object",
    cache: "browser and AWC preference cache",
    installer: "Active Workspace web client deployment",
    connector: "Teamcenter SOA gateway",
    roleGroup: "TC_AWC_USERS",
    version: "6.x"
  },
  {
    name: "Teamcenter FMS/FCC",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Support",
    tier2: "FMS/FCC",
    component: "file client cache",
    object: "dataset file",
    cache: "FCC cache volume",
    installer: "FMS client configuration",
    connector: "FMS server cache route",
    roleGroup: "TC_DATASET_USERS",
    version: "14.x"
  },
  {
    name: "Teamcenter Dispatcher",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Support",
    tier2: "Dispatcher",
    component: "translation queue",
    object: "PDF/JT translation request",
    cache: "dispatcher staging folder",
    installer: "Dispatcher module package",
    connector: "Dispatcher scheduler",
    roleGroup: "TC_DISPATCHER_OPERATORS",
    version: "14.x"
  },
  {
    name: "Teamcenter Workflow",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Support",
    tier2: "Workflow",
    component: "workflow handler",
    object: "ECR approval task",
    cache: "workflow rule cache",
    installer: "workflow handler deployment",
    connector: "Teamcenter task inbox service",
    roleGroup: "TC_WORKFLOW_APPROVERS",
    version: "14.x"
  },
  {
    name: "Teamcenter BMIDE",
    family: "Teamcenter",
    area: "PLM",
    tier1: "PLM Development",
    tier2: "BMIDE",
    component: "template deployment",
    object: "data model template",
    cache: "BMIDE workspace metadata cache",
    installer: "BMIDE client package",
    connector: "template deployment utility",
    roleGroup: "TC_BMIDE_DEVELOPERS",
    version: "14.x"
  },
  {
    name: "Teamcenter Visualization",
    family: "Teamcenter",
    area: "PLM CAD",
    tier1: "Visualization Support",
    tier2: "Teamcenter Visualization",
    component: "viewer plugin",
    object: "JT visualization file",
    cache: "viewer shader and JT cache",
    installer: "Teamcenter Visualization package",
    connector: "JT file association",
    roleGroup: "TC_VIS_VIEWERS",
    version: "14.x"
  },
  {
    name: "Teamcenter Structure Manager",
    family: "Teamcenter",
    area: "PLM BOM",
    tier1: "PLM Support",
    tier2: "Structure Manager",
    component: "BOM window",
    object: "product structure",
    cache: "BOM window preference cache",
    installer: "Structure Manager module",
    connector: "BOM expansion service",
    roleGroup: "TC_BOM_USERS",
    version: "14.x"
  },
  {
    name: "NX Managed Mode",
    family: "CAD",
    area: "CAD Integration",
    tier1: "CAD Support",
    tier2: "NX Teamcenter Integration",
    component: "managed mode connector",
    object: "NX part revision",
    cache: "NX Teamcenter integration cache",
    installer: "NX managed mode integration package",
    connector: "Teamcenter-NX bridge",
    roleGroup: "NX_TC_DESIGNERS",
    version: "2312"
  },
  {
    name: "Siemens NX CAD",
    family: "CAD",
    area: "CAD",
    tier1: "CAD Support",
    tier2: "NX CAD",
    component: "NX desktop client",
    object: "assembly model",
    cache: "NX user profile cache",
    installer: "NX CAD installation package",
    connector: "license checkout service",
    roleGroup: "NX_DESIGNERS",
    version: "2312"
  },
  {
    name: "Solid Edge",
    family: "CAD",
    area: "CAD",
    tier1: "CAD Support",
    tier2: "Solid Edge",
    component: "Solid Edge client",
    object: "draft file",
    cache: "Solid Edge user preference cache",
    installer: "Solid Edge installation package",
    connector: "Teamcenter Solid Edge connector",
    roleGroup: "SE_DESIGNERS",
    version: "2024"
  },
  {
    name: "Creo Parametric",
    family: "CAD",
    area: "CAD",
    tier1: "CAD Support",
    tier2: "Creo",
    component: "Creo client",
    object: "CAD drawing",
    cache: "Creo working directory cache",
    installer: "Creo Parametric package",
    connector: "Creo Teamcenter gateway",
    roleGroup: "CREO_DESIGNERS",
    version: "10"
  },
  {
    name: "CATIA V5",
    family: "CAD",
    area: "CAD",
    tier1: "CAD Support",
    tier2: "CATIA",
    component: "CATIA V5 client",
    object: "CATPart file",
    cache: "CATSettings cache",
    installer: "CATIA V5 package",
    connector: "Teamcenter CATIA integration",
    roleGroup: "CATIA_DESIGNERS",
    version: "V5-6R2023"
  },
  {
    name: "AutoCAD Mechanical",
    family: "CAD",
    area: "CAD",
    tier1: "CAD Support",
    tier2: "AutoCAD",
    component: "AutoCAD Mechanical client",
    object: "DWG drawing",
    cache: "AutoCAD profile cache",
    installer: "AutoCAD Mechanical package",
    connector: "DWG vault sync",
    roleGroup: "AUTOCAD_USERS",
    version: "2025"
  },
  {
    name: "PLM XML Export",
    family: "PLM Integration",
    area: "PLM Integration",
    tier1: "Integration Support",
    tier2: "PLM XML",
    component: "PLM XML export service",
    object: "BOM export package",
    cache: "export staging cache",
    installer: "PLM XML translator package",
    connector: "BOM export workflow",
    roleGroup: "TC_EXPORT_USERS",
    version: "14.x"
  },
  {
    name: "JT Translator",
    family: "Visualization",
    area: "PLM CAD",
    tier1: "Visualization Support",
    tier2: "JT Translation",
    component: "JT translation adapter",
    object: "JT output file",
    cache: "translator temp cache",
    installer: "JT translator package",
    connector: "Dispatcher translation adapter",
    roleGroup: "TC_JT_TRANSLATION_USERS",
    version: "14.x"
  },
  {
    name: "FlexNet License Server",
    family: "Licensing",
    area: "CAD Licensing",
    tier1: "License Support",
    tier2: "FlexNet",
    component: "license checkout",
    object: "NX/CAD license token",
    cache: "license client vendor cache",
    installer: "license client environment package",
    connector: "FlexNet license daemon",
    roleGroup: "CAD_LICENSE_USERS",
    version: "11.x"
  },
  {
    name: "Engineering VPN",
    family: "Network",
    area: "Network",
    tier1: "Network Support",
    tier2: "VPN",
    component: "VPN tunnel",
    object: "PLM network route",
    cache: "VPN portal cookie cache",
    installer: "VPN client package",
    connector: "SAML VPN authentication profile",
    roleGroup: "VPN_ENGINEERING_USERS",
    version: "6.x"
  },
  {
    name: "Corporate Internet",
    family: "Network",
    area: "Network",
    tier1: "Network Support",
    tier2: "Internet Connectivity",
    component: "network path",
    object: "CAD/PLM session traffic",
    cache: "browser DNS and proxy cache",
    installer: "network profile package",
    connector: "proxy and DNS route",
    roleGroup: "CORP_NETWORK_USERS",
    version: "standard"
  },
  {
    name: "Software Center Install",
    family: "Endpoint",
    area: "Application Install",
    tier1: "Endpoint Support",
    tier2: "Software Center",
    component: "installation deployment",
    object: "CAD/PLM application package",
    cache: "SCCM client cache",
    installer: "Software Center deployment",
    connector: "SCCM distribution point",
    roleGroup: "APP_INSTALL_USERS",
    version: "current branch"
  }
];

const patterns = [
  {
    code: "access",
    tier3: "Access and entitlement",
    issue: (system) =>
      `${system.name} access fails for an engineering user; the user sees access denied, blank object list, or repeated sign-in while opening ${system.object}.`,
    cause: (system) =>
      `The user is not synchronized to ${system.roleGroup}, the SSO session is stale, or the ${system.connector} is rejecting the current entitlement.`,
    resolution: (system) =>
      `Confirm the user account and business role, add or resync ${system.roleGroup}, clear the ${system.cache}, restart ${system.component}, and validate access to ${system.object}. If access still fails, attach the user ID, group membership screenshot, timestamp, and server transaction ID for PLM authorization review.`,
    keywords: (system) => ["access", "denied", "login", "sso", "entitlement", "permission", system.roleGroup]
  },
  {
    code: "performance",
    tier3: "Slowness and internet",
    issue: (system) =>
      `${system.name} is slow, freezes, or times out when the user opens, saves, downloads, or checks in ${system.object}.`,
    cause: (system) =>
      `The ${system.cache} is stale, the network path is unstable, proxy/VPN latency is high, or ${system.connector} is responding slowly.`,
    resolution: (system) =>
      `Check network latency to the PLM/CAD endpoint, compare performance on corporate LAN and mobile hotspot, clear ${system.cache}, restart ${system.component}, and retry the same ${system.object} operation. If slowness continues, collect client logs, VPN/proxy route, ping/traceroute output, exact timestamp, and affected site details.`,
    keywords: (system) => ["slow", "slowness", "timeout", "latency", "internet", "vpn", "proxy", "cache"]
  },
  {
    code: "install",
    tier3: "Install and upgrade",
    issue: (system) =>
      `${system.name} installation or upgrade fails while installing ${system.installer}; user cannot launch the application after install.`,
    cause: (system) =>
      `The local installer cache is incomplete, prerequisites are missing, a previous ${system.version} package remains installed, or the endpoint cannot reach the distribution source.`,
    resolution: (system) =>
      `Verify disk space and admin policy, clear the ${system.cache}, repair or remove the previous ${system.version} client, rerun ${system.installer} from the approved source, then launch ${system.component} and confirm version and license status. Escalate with install logs and Software Center deployment ID if the package fails again.`,
    keywords: (system) => ["install", "upgrade", "software", "center", "package", "deployment", "version", system.version]
  },
  {
    code: "sync",
    tier3: "Data sync and integration",
    issue: (system) =>
      `${system.name} shows stale or missing data; ${system.object} updates do not appear after save, check-in, translation, or refresh.`,
    cause: (system) =>
      `${system.connector} failed, queued jobs are delayed, file staging is incomplete, or the object metadata mapping is out of sync.`,
    resolution: (system) =>
      `Review ${system.connector} job status, verify source object ownership and release state, rerun the sync or translation, clear ${system.cache}, and compare the refreshed ${system.object} with the source record. Escalate with job ID, object UID, dataset name, and server logs if the sync fails again.`,
    keywords: (system) => ["sync", "stale", "missing", "checkin", "checkout", "translation", "refresh", "integration"]
  },
  {
    code: "client-error",
    tier3: "Client crash and save error",
    issue: (system) =>
      `${system.name} throws an unexpected error, crashes, or fails to save while working with ${system.object}.`,
    cause: (system) =>
      `The ${system.component} profile is corrupted, the ${system.cache} contains invalid preferences, or the client is not aligned with the supported ${system.version} configuration.`,
    resolution: (system) =>
      `Capture the exact error text and screenshot, close ${system.component}, rename the local profile/cache folder, confirm the supported ${system.version} package and license are active, reopen ${system.object}, and perform a save/open validation. Escalate with client logs and reproduction steps if the crash repeats.`,
    keywords: (system) => ["crash", "error", "save", "open", "profile", "preference", "corrupt", "logs"]
  }
];

const stopWords = ["a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "of", "on", "or", "the", "to", "with"];
const synonymMap = {
  teamcenter: ["tc", "rac", "awc", "plm"],
  slowness: ["slow", "latency", "timeout", "freeze", "hang"],
  internet: ["network", "vpn", "proxy", "dns", "connectivity"],
  install: ["installation", "upgrade", "package", "deployment", "software center"],
  cad: ["nx", "solid edge", "creo", "catia", "autocad"],
  file: ["dataset", "fms", "fcc", "download", "upload"],
  translation: ["dispatcher", "jt", "pdf", "visualization"],
  access: ["permission", "entitlement", "authorization", "role", "sso"]
};
const acronymMap = {
  tc: ["teamcenter"],
  awc: ["active workspace"],
  rac: ["rich client"],
  fms: ["file management system"],
  fcc: ["file client cache"],
  nx: ["siemens nx", "cad"],
  plm: ["product lifecycle management", "teamcenter"],
  cad: ["computer aided design", "nx", "creo", "catia", "autocad"],
  bom: ["bill of material", "structure manager"],
  jt: ["visualization", "translator"]
};

const statuses = ["Known Error", "Root Cause Identified", "In Progress", "Monitoring", "Deliverable Implemented"];
const solutions = [];
const kbArticles = [];
const problems = [];
const tiers = [];
let sequence = 1;

for (const system of systems) {
  for (const pattern of patterns) {
    const id = String(sequence).padStart(3, "0");
    const issue = pattern.issue(system);
    const cause = pattern.cause(system);
    const resolution = pattern.resolution(system);
    const tier3 = `${pattern.tier3} - ${system.name}`;
    const keywords = unique([
      system.name,
      system.family,
      system.area,
      system.tier2,
      system.component,
      system.object,
      system.cache,
      pattern.code,
      pattern.tier3,
      ...pattern.keywords(system)
    ]);

    solutions.push({
      id: `sol_plm_${id}`,
      tier: system.area,
      tier1: system.tier1,
      tier2: system.tier2,
      tier3,
      issue,
      cause,
      resolution,
      keywords,
      link: `https://demo.quantum-resolve.local/plm/solutions/${id}`
    });

    kbArticles.push({
      id: `kb_plm_${id}`,
      number: `KB-PLM-${id}`,
      title: `${system.name}: ${pattern.tier3} troubleshooting guide`,
      keywords: unique([system.name, system.family, system.area, system.tier2, pattern.code, pattern.tier3, "teamcenter", "plm", "cad", ...keywords.slice(0, 8)]),
      link: `https://demo.quantum-resolve.local/plm/kb/KB-PLM-${id}`
    });

    problems.push({
      id: `prb_plm_${id}`,
      problemId: `PRB-PLM-${id}`,
      title: `${system.name} ${pattern.tier3} recurring support pattern`,
      keywords: unique([system.name, system.family, system.area, system.tier2, pattern.code, pattern.tier3, system.object, "known issue", "demo"]),
      application: system.name,
      eit: `EIT-PLM-2026-${String(((sequence - 1) % 12) + 1).padStart(2, "0")}`,
      deliveryId: `PLM-DLV-${String(9000 + sequence)}`,
      status: statuses[(sequence - 1) % statuses.length],
      eitLink: `https://demo.quantum-resolve.local/plm/eit/${id}`,
      problemLink: `https://demo.quantum-resolve.local/plm/problems/PRB-PLM-${id}`,
      fdtdLink: `https://demo.quantum-resolve.local/plm/fdtd/${id}`
    });

    tiers.push({
      category: system.area,
      tier1: system.tier1,
      tier2: system.tier2,
      tier3
    });

    sequence += 1;
  }
}

const payload = {
  meta: {
    name: "Quantum Resolve Teamcenter PLM CAD Demo Database",
    description: "Synthetic demo database focused on Teamcenter, PLM, CAD, internet/VPN, and application installation issues.",
    generatedAt: new Date().toISOString(),
    dataClassification: "Synthetic demo data",
    recordCounts: {
      solutions: solutions.length,
      kbArticles: kbArticles.length,
      problems: problems.length,
      tiers: tiers.length
    }
  },
  solutions,
  kbArticles,
  problems,
  tiers,
  curated: [],
  stats: {
    solutions: solutions.length,
    kbArticles: kbArticles.length,
    problems: problems.length
  },
  dictionaries: {
    stopWords,
    synonymMap,
    acronymMap
  },
  defaultSearchConfig: {
    fuzzySensitivity: 70,
    scoreThreshold: 7,
    titleWeight: 3,
    descriptionWeight: 2,
    contentWeight: 1,
    searchMode: "any",
    stemming: true,
    phonetic: true,
    synonyms: true,
    typoTolerance: true,
    acronyms: true,
    resultLimits: {
      solution: { enabled: false, value: 10 },
      kb: { enabled: false, value: 10 },
      problem: { enabled: false, value: 10 }
    }
  },
  services: {
    database: false,
    meilisearch: false,
    opensearch: false,
    elasticsearch: false,
    solr: false,
    ai: false
  }
};

const jsonPath = join(root, "examples", "teamcenter-plm-demo-database.json");
const jsonlPath = join(root, "examples", "teamcenter-plm-demo-database.jsonl");
const readmePath = join(root, "examples", "teamcenter-plm-demo-database-readme.md");
const examplePartsPath = join(root, "examples", "teamcenter-plm-demo-database-parts");
const packagedPath = join(root, "frontend", "public", "offline", "knowledge-base.json");
const packagedPartsPath = join(root, "frontend", "public", "offline");

mkdirSync(dirname(jsonPath), { recursive: true });
mkdirSync(dirname(packagedPath), { recursive: true });
mkdirSync(examplePartsPath, { recursive: true });

writeFileSync(jsonPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
writeFileSync(jsonlPath, `${toJsonl(payload)}\n`, "utf8");
writeFileSync(readmePath, `${readme(payload)}\n`, "utf8");
writeFileSync(packagedPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
writeSeparateDatabaseFiles(examplePartsPath, payload);
writeSeparateDatabaseFiles(packagedPartsPath, payload);

console.log(`Generated ${solutions.length} solutions, ${kbArticles.length} KB articles, ${problems.length} problem records, and ${tiers.length} tiers.`);
console.log(`JSON snapshot: ${jsonPath}`);
console.log(`JSONL import:   ${jsonlPath}`);
console.log(`README:         ${readmePath}`);
console.log(`Separate files: ${examplePartsPath}`);
console.log(`Packaged data:  ${packagedPath}`);

function unique(input) {
  return [...new Set(input.flatMap((item) => String(item).split(/\s+/)).map((item) => item.replace(/[^a-z0-9_-]/gi, "").trim().toLowerCase()).filter(Boolean))];
}

function toJsonl(database) {
  const rows = [];
  for (const solution of database.solutions) rows.push({ type: "solution", ...solution });
  for (const kb of database.kbArticles) rows.push({ type: "kb", ...kb });
  for (const problem of database.problems) rows.push({ type: "problem", ...problem });
  for (const tier of database.tiers) rows.push({ type: "tier", ...tier });
  return rows.map((row) => JSON.stringify(row)).join("\n");
}

function writeSeparateDatabaseFiles(targetDir, database) {
  mkdirSync(targetDir, { recursive: true });
  const files = {
    "solutions.json": database.solutions,
    "kb-articles.json": database.kbArticles,
    "problems.json": database.problems,
    "tiers.json": database.tiers,
    "curated.json": database.curated,
    "dictionaries.json": database.dictionaries,
    "search-config.json": database.defaultSearchConfig,
    "services.json": database.services
  };

  for (const [name, value] of Object.entries(files)) {
    writeFileSync(join(targetDir, name), `${JSON.stringify(value, null, 2)}\n`, "utf8");
  }
}

function readme(database) {
  return `# Teamcenter PLM CAD Demo Database

Synthetic database for testing Quantum Resolve Enterprise.

## Contents

- ${database.solutions.length} solutions
- ${database.kbArticles.length} KB articles
- ${database.problems.length} problem IDs
- ${database.tiers.length} tier routes

## Files

- teamcenter-plm-demo-database.json: complete combined import snapshot
- teamcenter-plm-demo-database.jsonl: line-by-line import format
- teamcenter-plm-demo-database-parts/solutions.json
- teamcenter-plm-demo-database-parts/kb-articles.json
- teamcenter-plm-demo-database-parts/problems.json
- teamcenter-plm-demo-database-parts/tiers.json
- teamcenter-plm-demo-database-parts/dictionaries.json
- teamcenter-plm-demo-database-parts/search-config.json

## Topics Covered

- Teamcenter Rich Client, Active Workspace, FMS/FCC, Dispatcher, Workflow, BMIDE, Visualization, and Structure Manager
- NX managed mode and Siemens NX CAD
- Solid Edge, Creo, CATIA, AutoCAD Mechanical
- PLM XML export and JT translation
- FlexNet CAD license checkout
- Engineering VPN and corporate internet/network issues
- Software Center CAD/PLM installation and upgrade issues

## How To Use

1. Extract this zip.
2. Open Quantum Resolve Enterprise.
3. Click Import JSON/JSONL.
4. Select teamcenter-plm-demo-database.json or teamcenter-plm-demo-database.jsonl.
5. Search examples: "Teamcenter slow over VPN", "NX managed mode checkout failed", "FMS cache download issue", "Software Center CAD install failed", "JT translation missing".

This is synthetic demo data, not production support history.
`;
}
