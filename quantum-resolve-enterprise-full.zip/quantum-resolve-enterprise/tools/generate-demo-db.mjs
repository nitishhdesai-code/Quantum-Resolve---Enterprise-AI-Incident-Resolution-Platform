import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(dirname(fileURLToPath(import.meta.url)));

const applications = [
  {
    name: "Teamcenter",
    area: "PLM",
    tier1: "AMAT Custom",
    tier2: "Teamcenter",
    roleGroup: "TC_ENGINEERING_USERS",
    cache: "FCC/FMS cache",
    connector: "BOM export workflow",
    object: "item revision",
    client: "Rich Client",
    version: "14.3"
  },
  {
    name: "Siemens NX",
    area: "CAD",
    tier1: "Engineering Tools",
    tier2: "NX",
    roleGroup: "NX_DESIGNERS",
    cache: "NX user profile cache",
    connector: "Teamcenter managed-mode connector",
    object: "assembly model",
    client: "NX desktop client",
    version: "2312"
  },
  {
    name: "ServiceNow",
    area: "ITSM",
    tier1: "Enterprise Service",
    tier2: "ServiceNow",
    roleGroup: "ITIL_FULFILLERS",
    cache: "browser session cache",
    connector: "assignment rule sync",
    object: "incident record",
    client: "Service Portal",
    version: "Washington"
  },
  {
    name: "SAP ECC",
    area: "ERP",
    tier1: "Business Applications",
    tier2: "SAP",
    roleGroup: "SAP_MM_USERS",
    cache: "SAP GUI local cache",
    connector: "IDoc inbound job",
    object: "purchase order",
    client: "SAP GUI",
    version: "7.70"
  },
  {
    name: "Outlook",
    area: "Messaging",
    tier1: "Microsoft 365",
    tier2: "Exchange Online",
    roleGroup: "M365_STANDARD_USERS",
    cache: "OST profile cache",
    connector: "Exchange Autodiscover",
    object: "mailbox folder",
    client: "Outlook desktop",
    version: "Microsoft 365 Apps"
  },
  {
    name: "Microsoft Teams",
    area: "Collaboration",
    tier1: "Microsoft 365",
    tier2: "Teams",
    roleGroup: "M365_TEAMS_USERS",
    cache: "Teams media cache",
    connector: "Teams policy sync",
    object: "meeting chat",
    client: "Teams desktop",
    version: "new Teams"
  },
  {
    name: "SharePoint Online",
    area: "Content",
    tier1: "Microsoft 365",
    tier2: "SharePoint",
    roleGroup: "SP_SITE_MEMBERS",
    cache: "browser document cache",
    connector: "SharePoint search crawl",
    object: "document library",
    client: "SharePoint web",
    version: "Online"
  },
  {
    name: "OneDrive",
    area: "File Sync",
    tier1: "Microsoft 365",
    tier2: "OneDrive",
    roleGroup: "M365_ONEDRIVE_USERS",
    cache: "OneDrive sync cache",
    connector: "Known Folder Move policy",
    object: "synced folder",
    client: "OneDrive sync client",
    version: "24.x"
  },
  {
    name: "GlobalProtect VPN",
    area: "Network Access",
    tier1: "Network",
    tier2: "VPN",
    roleGroup: "VPN_REMOTE_USERS",
    cache: "VPN portal cookie cache",
    connector: "SAML authentication profile",
    object: "VPN tunnel",
    client: "GlobalProtect client",
    version: "6.2"
  },
  {
    name: "Citrix Workspace",
    area: "Virtual Desktop",
    tier1: "End User Computing",
    tier2: "Citrix",
    roleGroup: "CITRIX_APP_USERS",
    cache: "Workspace app cache",
    connector: "StoreFront enumeration",
    object: "published application",
    client: "Citrix Workspace app",
    version: "2402"
  },
  {
    name: "Power BI",
    area: "Analytics",
    tier1: "Data Platform",
    tier2: "Power BI",
    roleGroup: "PBI_REPORT_VIEWERS",
    cache: "dataset browser cache",
    connector: "scheduled dataset refresh",
    object: "semantic model",
    client: "Power BI Service",
    version: "Service"
  },
  {
    name: "Tableau",
    area: "Analytics",
    tier1: "Data Platform",
    tier2: "Tableau",
    roleGroup: "TABLEAU_ANALYSTS",
    cache: "Tableau workbook cache",
    connector: "extract refresh task",
    object: "published workbook",
    client: "Tableau Desktop",
    version: "2024.1"
  },
  {
    name: "Snowflake",
    area: "Data Warehouse",
    tier1: "Data Platform",
    tier2: "Snowflake",
    roleGroup: "SNOWFLAKE_ANALYSTS",
    cache: "warehouse result cache",
    connector: "ingestion pipe",
    object: "warehouse query",
    client: "Snowsight",
    version: "Enterprise"
  },
  {
    name: "SQL Server",
    area: "Database",
    tier1: "Database",
    tier2: "SQL Server",
    roleGroup: "SQL_READONLY_USERS",
    cache: "query plan cache",
    connector: "SQL Agent job",
    object: "stored procedure",
    client: "SQL Server Management Studio",
    version: "2022"
  },
  {
    name: "Oracle ERP",
    area: "ERP",
    tier1: "Business Applications",
    tier2: "Oracle",
    roleGroup: "ORACLE_FINANCE_USERS",
    cache: "forms client cache",
    connector: "concurrent request",
    object: "invoice batch",
    client: "Oracle Forms",
    version: "R12"
  },
  {
    name: "Jenkins",
    area: "CI/CD",
    tier1: "DevOps",
    tier2: "Jenkins",
    roleGroup: "JENKINS_BUILD_USERS",
    cache: "workspace cache",
    connector: "agent executor connection",
    object: "pipeline job",
    client: "Jenkins web",
    version: "2.440"
  },
  {
    name: "GitLab",
    area: "Source Control",
    tier1: "DevOps",
    tier2: "GitLab",
    roleGroup: "GITLAB_DEVELOPERS",
    cache: "runner cache",
    connector: "CI runner registration",
    object: "merge request",
    client: "GitLab web",
    version: "16.x"
  },
  {
    name: "Kubernetes",
    area: "Container Platform",
    tier1: "Cloud Platform",
    tier2: "Kubernetes",
    roleGroup: "K8S_NAMESPACE_ADMINS",
    cache: "kubectl context cache",
    connector: "cluster API server",
    object: "pod deployment",
    client: "kubectl",
    version: "1.29"
  },
  {
    name: "OpenShift",
    area: "Container Platform",
    tier1: "Cloud Platform",
    tier2: "OpenShift",
    roleGroup: "OCP_PROJECT_ADMINS",
    cache: "console session cache",
    connector: "image stream import",
    object: "deployment config",
    client: "OpenShift Console",
    version: "4.15"
  },
  {
    name: "Docker Registry",
    area: "Container Registry",
    tier1: "Cloud Platform",
    tier2: "Registry",
    roleGroup: "REGISTRY_PUSH_USERS",
    cache: "local Docker credential cache",
    connector: "registry catalog sync",
    object: "container image",
    client: "Docker CLI",
    version: "25.x"
  },
  {
    name: "Apache Kafka",
    area: "Messaging",
    tier1: "Integration Platform",
    tier2: "Kafka",
    roleGroup: "KAFKA_CONSUMER_USERS",
    cache: "consumer offset cache",
    connector: "consumer group coordinator",
    object: "topic partition",
    client: "Kafka client",
    version: "3.6"
  },
  {
    name: "RabbitMQ",
    area: "Messaging",
    tier1: "Integration Platform",
    tier2: "RabbitMQ",
    roleGroup: "RABBITMQ_APP_USERS",
    cache: "client connection cache",
    connector: "queue binding sync",
    object: "message queue",
    client: "RabbitMQ Management UI",
    version: "3.12"
  },
  {
    name: "Redis",
    area: "Cache",
    tier1: "Data Platform",
    tier2: "Redis",
    roleGroup: "REDIS_APP_USERS",
    cache: "application cache keyspace",
    connector: "replica synchronization",
    object: "cache key",
    client: "redis-cli",
    version: "7.x"
  },
  {
    name: "Elasticsearch",
    area: "Search",
    tier1: "Search Platform",
    tier2: "Elasticsearch",
    roleGroup: "ELASTIC_SEARCH_USERS",
    cache: "query cache",
    connector: "index lifecycle policy",
    object: "search index",
    client: "Kibana",
    version: "8.x"
  },
  {
    name: "Jira",
    area: "Work Management",
    tier1: "Enterprise Tools",
    tier2: "Jira",
    roleGroup: "JIRA_PROJECT_USERS",
    cache: "browser issue cache",
    connector: "project permission sync",
    object: "issue board",
    client: "Jira web",
    version: "Cloud"
  }
];

const patterns = [
  {
    code: "access",
    tier3: "Access",
    issue: (app) =>
      `${app.name} user receives access denied or sign-in loop when opening ${app.object} from ${app.client}.`,
    cause: (app) =>
      `User is missing the ${app.roleGroup} entitlement or has a stale SSO session after a recent access change.`,
    resolution: (app) =>
      `Confirm the user identity and business role, add or resync ${app.roleGroup}, clear the ${app.cache}, ask the user to sign out and back in, then validate access to ${app.object}.`,
    keywords: (app) => ["access", "denied", "login", "sso", "entitlement", app.roleGroup.toLowerCase()]
  },
  {
    code: "performance",
    tier3: "Performance",
    issue: (app) =>
      `${app.name} is slow or times out while the user works with ${app.object} in ${app.client}.`,
    cause: (app) =>
      `${app.cache} is stale, the service is under load, or the client is reusing an old ${app.version} configuration.`,
    resolution: (app) =>
      `Check service health, clear the ${app.cache}, restart ${app.client}, verify network latency, and retry the same ${app.object} operation. Escalate with timestamps and logs if latency remains high.`,
    keywords: (app) => ["slow", "timeout", "latency", "performance", "cache", app.version.toLowerCase()]
  },
  {
    code: "sync",
    tier3: "Data Sync",
    issue: (app) =>
      `${app.name} data is not current; ${app.object} updates are missing after the latest refresh cycle.`,
    cause: (app) =>
      `The ${app.connector} failed or completed with warnings, leaving downstream ${app.object} data stale.`,
    resolution: (app) =>
      `Review the ${app.connector} logs, fix the failed input record or permission warning, rerun the sync, and compare the refreshed ${app.object} with the source system.`,
    keywords: (app) => ["sync", "refresh", "stale", "integration", "connector", "missing"]
  },
  {
    code: "client",
    tier3: "Client Error",
    issue: (app) =>
      `${app.client} shows an unexpected error while saving or opening ${app.object} in ${app.name}.`,
    cause: (app) =>
      `The local ${app.client} profile or ${app.version} configuration is corrupted or does not match the current service policy.`,
    resolution: (app) =>
      `Capture the error text, close ${app.client}, reset the local profile and ${app.cache}, confirm the supported ${app.version} package is installed, then reopen ${app.object} and save again.`,
    keywords: (app) => ["client", "error", "save", "open", "profile", "configuration"]
  }
];

const stopWords = ["a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "of", "on", "or", "the", "to", "with"];
const synonymMap = {
  slow: ["slowness", "latency", "delay", "timeout"],
  login: ["signin", "sign-in", "authentication", "sso"],
  sync: ["refresh", "replication", "integration", "update"],
  error: ["failure", "exception", "crash", "fault"],
  access: ["permission", "entitlement", "authorization", "role"],
  cache: ["cached", "profile", "temporary"],
  ticket: ["incident", "case", "request"]
};
const acronymMap = {
  tc: ["teamcenter"],
  nx: ["siemens", "cad"],
  vpn: ["globalprotect", "remote", "access"],
  pbi: ["power", "bi", "analytics"],
  k8s: ["kubernetes"],
  ocp: ["openshift"],
  sql: ["database", "query"],
  kb: ["knowledge", "article"],
  prb: ["problem", "record"]
};

const solutions = [];
const kbArticles = [];
const problems = [];
const tiers = [];
const tierKeys = new Set();
const statuses = ["Root Cause Identified", "Known Error", "In Progress", "Monitoring", "Deliverable Implemented"];

let sequence = 1;
for (const app of applications) {
  for (const pattern of patterns) {
    const id = String(sequence).padStart(3, "0");
    const issue = pattern.issue(app);
    const cause = pattern.cause(app);
    const resolution = pattern.resolution(app);
    const keywords = unique([
      app.name.toLowerCase(),
      app.area.toLowerCase(),
      app.tier2.toLowerCase(),
      app.object.toLowerCase(),
      app.client.toLowerCase(),
      pattern.code,
      pattern.tier3.toLowerCase(),
      ...pattern.keywords(app).map((word) => word.toLowerCase())
    ]);

    solutions.push({
      id: `sol_demo_${id}`,
      tier: app.area,
      tier1: app.tier1,
      tier2: app.tier2,
      tier3: pattern.tier3,
      issue,
      cause,
      resolution,
      keywords,
      link: `https://demo.quantum-resolve.local/solutions/${id}`
    });

    kbArticles.push({
      id: `kb_demo_${id}`,
      number: `KB-DEMO-${id}`,
      title: `${app.name}: ${pattern.tier3} troubleshooting checklist`,
      keywords: unique([app.name.toLowerCase(), app.tier2.toLowerCase(), pattern.code, pattern.tier3.toLowerCase(), "troubleshooting", "demo", ...keywords.slice(0, 6)]),
      link: `https://demo.quantum-resolve.local/kb/KB-DEMO-${id}`
    });

    problems.push({
      id: `prb_demo_${id}`,
      problemId: `PRB-DEMO-${id}`,
      title: `${app.name} ${pattern.tier3} pattern for ${app.object}`,
      keywords: unique([app.name.toLowerCase(), app.area.toLowerCase(), pattern.code, pattern.tier3.toLowerCase(), app.object.toLowerCase(), "known issue"]),
      application: app.name,
      eit: `EIT 2026.${String(((sequence - 1) % 12) + 1).padStart(2, "0")}`,
      deliveryId: `DLV-${String(7000 + sequence)}`,
      status: statuses[(sequence - 1) % statuses.length],
      eitLink: `https://demo.quantum-resolve.local/eit/${id}`,
      problemLink: `https://demo.quantum-resolve.local/problems/PRB-DEMO-${id}`,
      fdtdLink: `https://demo.quantum-resolve.local/fdtd/${id}`
    });

    const tierKey = `${app.area}|${app.tier1}|${app.tier2}|${pattern.tier3}`;
    if (!tierKeys.has(tierKey)) {
      tierKeys.add(tierKey);
      tiers.push({
        category: app.area,
        tier1: app.tier1,
        tier2: app.tier2,
        tier3: pattern.tier3
      });
    }

    sequence += 1;
  }
}

const payload = {
  meta: {
    name: "Quantum Resolve Demo Knowledge Database",
    description: "Synthetic demo dataset with 100 solutions, 100 KB articles, and 100 problem records.",
    generatedAt: new Date().toISOString(),
    recordCounts: {
      solutions: solutions.length,
      kbArticles: kbArticles.length,
      problems: problems.length,
      tiers: tiers.length
    },
    dataClassification: "Synthetic demo data"
  },
  solutions,
  kbArticles,
  problems,
  tiers,
  curated: [],
  stats: {
    solutions: solutions.length,
    kbArticles: kbArticles.length,
    problems: problems.length
  },
  dictionaries: {
    stopWords,
    synonymMap,
    acronymMap
  },
  defaultSearchConfig: {
    fuzzySensitivity: 68,
    scoreThreshold: 8,
    titleWeight: 3,
    descriptionWeight: 2,
    contentWeight: 1,
    searchMode: "any",
    stemming: true,
    phonetic: true,
    synonyms: true,
    typoTolerance: true,
    acronyms: true,
    resultLimits: {
      solution: { enabled: false, value: 10 },
      kb: { enabled: false, value: 10 },
      problem: { enabled: false, value: 10 }
    }
  },
  services: {
    database: false,
    meilisearch: false,
    opensearch: false,
    elasticsearch: false,
    solr: false,
    ai: false
  }
};

const jsonPath = join(root, "examples", "demo-100-database.json");
const jsonlPath = join(root, "examples", "demo-100-database.jsonl");
const packagedPath = join(root, "frontend", "public", "offline", "knowledge-base.json");

mkdirSync(dirname(jsonPath), { recursive: true });
mkdirSync(dirname(packagedPath), { recursive: true });

writeFileSync(jsonPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
writeFileSync(packagedPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
writeFileSync(jsonlPath, `${toJsonl(payload)}\n`, "utf8");

console.log(`Generated ${solutions.length} solutions, ${kbArticles.length} KB articles, and ${problems.length} problem records.`);
console.log(`JSON snapshot: ${jsonPath}`);
console.log(`JSONL import:   ${jsonlPath}`);
console.log(`Packaged data:  ${packagedPath}`);

function unique(input) {
  return [...new Set(input.flatMap((item) => String(item).split(/\s+/)).map((item) => item.trim().toLowerCase()).filter(Boolean))];
}

function toJsonl(database) {
  const rows = [];
  for (const solution of database.solutions) rows.push({ type: "solution", ...solution });
  for (const kb of database.kbArticles) rows.push({ type: "kb", ...kb });
  for (const problem of database.problems) rows.push({ type: "problem", ...problem });
  for (const tier of database.tiers) rows.push({ type: "tier", ...tier });
  return rows.map((row) => JSON.stringify(row)).join("\n");
}
