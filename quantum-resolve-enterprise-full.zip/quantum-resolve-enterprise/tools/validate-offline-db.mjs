import { readFileSync } from "node:fs";

const file = process.argv[2];
if (!file) {
  console.error("Usage: node tools/validate-offline-db.mjs <offline-db.json|offline-db.jsonl>");
  process.exit(1);
}

const text = readFileSync(file, "utf8");
const payload = file.toLowerCase().endsWith(".jsonl")
  ? text.split(/\r?\n/).filter(Boolean).map((line) => JSON.parse(line))
  : JSON.parse(text);

const records = Array.isArray(payload)
  ? splitTypedRecords(payload)
  : {
      solutions: payload.solutions || [],
      kbArticles: payload.kbArticles || [],
      problems: payload.problems || [],
      tiers: payload.tiers || []
    };

const errors = [];
validateList("solutions", records.solutions, ["id", "issue", "resolution"], errors);
validateList("kbArticles", records.kbArticles, ["id", "number", "title"], errors);
validateList("problems", records.problems, ["id", "problemId", "title"], errors);
validateList("tiers", records.tiers, ["category", "tier1", "tier2", "tier3"], errors);

if (errors.length) {
  console.error("Offline database validation failed:");
  for (const error of errors.slice(0, 40)) console.error(`- ${error}`);
  if (errors.length > 40) console.error(`...and ${errors.length - 40} more`);
  process.exit(1);
}

console.log("Offline database validation passed.");
console.log(`Solutions: ${records.solutions.length}`);
console.log(`KB Articles: ${records.kbArticles.length}`);
console.log(`Problems: ${records.problems.length}`);
console.log(`Tiers: ${records.tiers.length}`);

function validateList(name, list, required, errors) {
  if (!Array.isArray(list)) {
    errors.push(`${name} must be an array`);
    return;
  }
  const ids = new Set();
  list.forEach((item, index) => {
    for (const field of required) {
      if (item[field] == null || String(item[field]).trim() === "") {
        errors.push(`${name}[${index}] missing ${field}`);
      }
    }
    if (item.id) {
      if (ids.has(item.id)) errors.push(`${name}[${index}] duplicate id ${item.id}`);
      ids.add(item.id);
    }
    if (item.keywords && !Array.isArray(item.keywords)) {
      errors.push(`${name}[${index}] keywords must be an array`);
    }
  });
}

function splitTypedRecords(input) {
  const output = { solutions: [], kbArticles: [], problems: [], tiers: [] };
  for (const record of input) {
    const type = String(record.type || "").toLowerCase();
    if (type === "solution" || record.issue || record.resolution) output.solutions.push(record);
    else if (type === "kb" || type === "kbarticle" || record.number) output.kbArticles.push(record);
    else if (type === "problem" || record.problemId || record.problem_id) output.problems.push(record);
    else if (type === "tier" || (record.category && record.tier1)) output.tiers.push(record);
  }
  return output;
}
