import type { AiProvider, Category, SearchConfig, SearchProvider, SearchResultGroup } from "../types";

export const categories: Category[] = ["solution", "kb", "problem"];

export const fallbackConfig: SearchConfig = {
  fuzzySensitivity: 60,
  scoreThreshold: 10,
  titleWeight: 3,
  descriptionWeight: 2,
  contentWeight: 1,
  searchMode: "any",
  stemming: true,
  phonetic: false,
  synonyms: true,
  typoTolerance: true,
  acronyms: true,
  resultLimits: {
    solution: { enabled: false, value: 10 },
    kb: { enabled: false, value: 10 },
    problem: { enabled: false, value: 10 }
  }
};

export const emptyResults: SearchResultGroup = { solution: [], kb: [], problem: [] };

export const searchProviders: { id: SearchProvider; name: string; detail: string }[] = [
  { id: "offline", name: "Offline NLP Worker", detail: "IndexedDB + BM25 + fuzzy rerank" },
  { id: "meilisearch", name: "Meilisearch", detail: "Fast typo-tolerant app search" },
  { id: "opensearch", name: "OpenSearch", detail: "Enterprise open-source search cluster" },
  { id: "elasticsearch", name: "Elasticsearch", detail: "Elastic relevance and observability stack" },
  { id: "solr", name: "Apache Solr", detail: "Lucene-powered enterprise search" }
];

export const aiModels: Record<AiProvider, { label: string; value: string; detail: string }[]> = {
  openai: [
    { label: "GPT-5.4", value: "gpt-5.4", detail: "Best general enterprise reasoning" },
    { label: "GPT-5.4 Pro", value: "gpt-5.4-pro", detail: "Hardest cases and deep analysis" },
    { label: "GPT-5.4 Mini", value: "gpt-5.4-mini", detail: "Fast support desk responses" },
    { label: "GPT-5.4 Nano", value: "gpt-5.4-nano", detail: "Low-cost classification" }
  ],
  gemini: [
    { label: "Gemini 2.5 Pro", value: "gemini-2.5-pro", detail: "Long-context reasoning" },
    { label: "Gemini 2.5 Flash", value: "gemini-2.5-flash", detail: "Fast grounded assistance" },
    { label: "Gemini 2.5 Flash-Lite", value: "gemini-2.5-flash-lite", detail: "High-throughput support" }
  ],
  anthropic: [
    { label: "Claude Opus 4.1", value: "claude-opus-4-1-20250805", detail: "Most capable Claude model" },
    { label: "Claude Sonnet 4", value: "claude-sonnet-4-20250514", detail: "Balanced enterprise assistant" },
    { label: "Claude Haiku 3.5", value: "claude-3-5-haiku-20241022", detail: "Fast triage and summaries" }
  ],
  mistral: [
    { label: "Mistral Medium Latest", value: "mistral-medium-latest", detail: "Agentic and coding workflows" },
    { label: "Mistral Large Latest", value: "mistral-large-latest", detail: "Open-weight enterprise reasoning" },
    { label: "Mistral Small Latest", value: "mistral-small-latest", detail: "Efficient local-friendly assistant" }
  ],
  "azure-openai": [
    { label: "Azure Deployment", value: "gpt-5.4", detail: "Use your Azure deployment endpoint" },
    { label: "Azure Mini Deployment", value: "gpt-5.4-mini", detail: "Cost-optimized Azure deployment" }
  ],
  custom: [{ label: "OpenAI-Compatible", value: "custom-chat-model", detail: "Self-hosted or gateway endpoint" }]
};
