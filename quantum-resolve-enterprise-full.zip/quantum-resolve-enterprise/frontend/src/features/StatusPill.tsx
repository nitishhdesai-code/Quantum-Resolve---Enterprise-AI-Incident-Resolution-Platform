import { Wifi, WifiOff } from "lucide-react";

export function StatusPill({
  online,
  services
}: {
  online: boolean;
  services: { database: boolean; meilisearch: boolean; ai: boolean };
}) {
  const healthy = online && services.database;
  return (
    <div className={`chip ${healthy ? "text-grove" : "text-pollen"}`}>
      {healthy ? <Wifi size={16} /> : <WifiOff size={16} />}
      {healthy ? "Online" : "Offline Ready"}
    </div>
  );
}
