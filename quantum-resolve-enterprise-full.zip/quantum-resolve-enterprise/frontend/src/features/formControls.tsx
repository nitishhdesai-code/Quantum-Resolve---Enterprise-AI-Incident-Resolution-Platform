export function Slider({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <label className="label mb-0">{label}</label>
        <span className="font-mono text-xs text-zinc-500">{value}%</span>
      </div>
      <input className="w-full accent-signal" type="range" min={0} max={100} value={value} onChange={(event) => onChange(Number(event.target.value))} />
    </div>
  );
}

export function Weight({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <label className="label mb-0">{label}</label>
        <span className="font-mono text-xs text-zinc-500">{value.toFixed(1)}x</span>
      </div>
      <input className="w-full accent-signal" type="range" min={0.5} max={5} step={0.1} value={value} onChange={(event) => onChange(Number(event.target.value))} />
    </div>
  );
}

export function Input({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input className="field" value={value} onChange={(event) => onChange(event.target.value)} />
    </div>
  );
}

export function TextArea({
  label,
  value,
  onChange,
  rows = 3
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  rows?: number;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <textarea className="field" rows={rows} value={value} onChange={(event) => onChange(event.target.value)} />
    </div>
  );
}
