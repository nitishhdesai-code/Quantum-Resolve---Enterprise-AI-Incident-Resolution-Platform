import { Copy, Mail, Send } from "lucide-react";
import { Input } from "./formControls";

export type CommunicationDraft = {
  ticket: string;
  userName: string;
  userEmail: string;
  priority: string;
  issue: string;
  output: string;
};

export function CommunicationDraftPanel({
  comm,
  setComm,
  draftCommunication,
  copyText
}: {
  comm: CommunicationDraft;
  setComm: (updater: CommunicationDraft | ((current: CommunicationDraft) => CommunicationDraft)) => void;
  draftCommunication: () => void;
  copyText: (text: string) => void;
}) {
  return (
    <div className="panel p-4">
      <div className="mb-4 flex items-center gap-2 text-sm font-bold text-signal">
        <Mail size={18} />
        One-Click Resolver
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Input label="Ticket" value={comm.ticket} onChange={(ticket) => setComm((current) => ({ ...current, ticket }))} />
        <Input label="User" value={comm.userName} onChange={(userName) => setComm((current) => ({ ...current, userName }))} />
        <Input label="Email" value={comm.userEmail} onChange={(userEmail) => setComm((current) => ({ ...current, userEmail }))} />
        <div>
          <label className="label">Priority</label>
          <select
            className="field"
            value={comm.priority}
            onChange={(event) => setComm((current) => ({ ...current, priority: event.target.value }))}
          >
            {["Low", "Medium", "High", "Critical"].map((priority) => (
              <option key={priority}>{priority}</option>
            ))}
          </select>
        </div>
      </div>
      <label className="label mt-3">Issue Description</label>
      <textarea className="field min-h-[100px]" value={comm.issue} onChange={(event) => setComm((current) => ({ ...current, issue: event.target.value }))} />
      <div className="mt-3 flex flex-wrap gap-2">
        <button className="button-primary px-4" onClick={draftCommunication}>
          Draft
        </button>
        <button className="button-muted px-4" onClick={() => copyText(comm.output)} disabled={!comm.output}>
          <Copy className="mr-2 inline" size={16} />
          Copy
        </button>
        <button
          className="button-secondary px-4"
          disabled={!comm.output}
          onClick={() =>
            window.open(`mailto:${comm.userEmail}?subject=${encodeURIComponent(`RE: Ticket ${comm.ticket || "Support Request"}`)}&body=${encodeURIComponent(comm.output)}`)
          }
        >
          <Send className="mr-2 inline" size={16} />
          Mail
        </button>
      </div>
      <label className="label mt-4">Drafted Response</label>
      <textarea className="field min-h-[150px] font-mono text-sm" value={comm.output} onChange={(event) => setComm((current) => ({ ...current, output: event.target.value }))} />
    </div>
  );
}
