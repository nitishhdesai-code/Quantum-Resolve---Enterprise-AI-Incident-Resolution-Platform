import { Copy, Sparkles } from "lucide-react";

export function CloseNotesGenerator({
  closeIssue,
  setCloseIssue,
  closeOutput,
  aiReady,
  generateCloseNotes,
  copyText
}: {
  closeIssue: string;
  setCloseIssue: (value: string) => void;
  closeOutput: string;
  aiReady: boolean;
  generateCloseNotes: (enhance: boolean) => void;
  copyText: (text: string) => void;
}) {
  return (
    <div className="panel p-4">
      <div className="mb-4 flex items-center gap-2 text-sm font-bold text-ember">
        <Sparkles size={18} />
        Close Notes Generator
      </div>
      <label className="label">Issue Description</label>
      <textarea className="field min-h-[120px]" value={closeIssue} onChange={(event) => setCloseIssue(event.target.value)} />
      <div className="mt-3 flex flex-wrap gap-2">
        <button className="button-secondary px-4" onClick={() => generateCloseNotes(false)}>
          Generate
        </button>
        <button
          className="button-primary px-4"
          onClick={() => generateCloseNotes(true)}
          disabled={!aiReady}
          title={aiReady ? "Rewrite notes professionally with AI" : "Configure AI Models to enable enhancement"}
        >
          Enhance
        </button>
        <button className="button-muted px-4" onClick={() => copyText(closeOutput)} disabled={!closeOutput}>
          <Copy className="mr-2 inline" size={16} />
          Copy
        </button>
      </div>
      <div className="mt-2 text-xs leading-5 text-zinc-500">
        Enhance is AI-only because it rewrites the resolution professionally. Use Generate for offline notes.
      </div>
      <label className="label mt-4">Output</label>
      <textarea className="field min-h-[160px] font-mono text-sm" value={closeOutput} onChange={() => undefined} readOnly />
    </div>
  );
}
