import { distinctCauseSummaries } from "./causes";
import type { BootstrapPayload, Category, ProblemRecord, SearchDocument, SearchResultGroup, Solution } from "../types";

export type GuideStep = { title: string; detail: string; evidence?: string; tone: "action" | "verify" | "escalate" };
export type GuideReference = { id: string; title: string; type: Category; link?: string };
export type GuidePlan = {
  issue: string;
  confidence: string;
  route: string;
  summary: string;
  closure: string;
  solutionCandidates: number;
  aiAdvisory?: string;
  sources?: { uri: string; title: string }[];
  steps: GuideStep[];
  references: GuideReference[];
};

export function getDocumentLink(document: SearchDocument) {
  const payload = document.payload as {
    link?: string;
    problemLink?: string;
    eitLink?: string;
    fdtdLink?: string;
  };
  return payload.link || payload.problemLink || payload.eitLink || payload.fdtdLink;
}

export function contextFromDocuments(documents: SearchDocument[], limit = 6) {
  return documents
    .slice(0, limit)
    .map((document, index) => {
      const payload = document.payload as Partial<Solution>;
      return `${index + 1}. [${document.type}] ${document.title}
${document.description}
${document.content}
${payload.cause ? `Cause: ${payload.cause}` : ""}
${payload.resolution ? `Resolution: ${payload.resolution}` : ""}`;
    })
    .join("\n\n");
}

export function createGuidePlan(
  issue: string,
  groups: SearchResultGroup,
  prediction: BootstrapPayload["tiers"][number] | null
) {
  const ordered = [...groups.solution, ...groups.kb, ...groups.problem].sort((a, b) => (b.score || 0) - (a.score || 0));
  const solutionPool = groups.solution.slice(0, 60);
  const causeClusters = distinctCauseSummaries(solutionPool, 10);
  const best = ordered[0];
  const bestSolution = groups.solution[0];
  const bestKb = groups.kb[0];
  const bestProblem = groups.problem[0];
  const solution = bestSolution?.payload as Solution | undefined;
  const problem = bestProblem?.payload as ProblemRecord | undefined;
  const route =
    prediction?.tier3 ||
    solution?.tier3 ||
    prediction?.tier2 ||
    solution?.tier2 ||
    problem?.application ||
    "Owning support queue";
  const confidence = best
    ? (best.score || 0) >= 10
      ? "High internal match"
      : "Moderate internal match"
    : "No verified internal match";

  const references = ordered.slice(0, 5).map((document) => ({
    id: document.uid,
    title: document.title,
    type: document.type,
    link: getDocumentLink(document)
  }));

  const steps: GuideStep[] = [
    {
      title: "Confirm impact and scope",
      detail: `Validate the affected application, user group, environment, exact error text, timestamp, and the action that triggers "${issue}".`,
      evidence: prediction ? `${prediction.tier1} / ${prediction.tier2} / ${prediction.tier3}` : undefined,
      tone: "action"
    },
    {
      title: "Compare against the best internal match",
      detail: best
        ? `Use "${best.title}" as the primary reference. If many matches exist, first compare the top cause clusters and choose the path that matches the user's exact symptom, application, version, and timestamp.`
        : "No strong internal match was found. Treat this as first-contact triage and collect logs before attempting a change.",
      evidence: causeClusters.length
        ? causeClusters.map((item, index) => `${index + 1}. ${item.cause} (${item.count} match${item.count === 1 ? "" : "es"})`).join("\n")
        : best?.description || best?.content,
      tone: "action"
    },
    {
      title: "Apply the recommended resolution",
      detail:
        solution?.resolution ||
        (bestKb ? `Follow the KB article "${bestKb.title}" and capture the exact outcome after each action.` : "") ||
        "Run baseline checks: restart the impacted client/service, validate connectivity, confirm permissions, and compare with a known working user or machine.",
      evidence: solution?.cause ? `Likely cause: ${solution.cause}` : undefined,
      tone: "action"
    },
    {
      title: "Validate recovery",
      detail: "Repeat the original failing action, verify the expected result, check logs for recurring errors, and confirm with the requester before closure.",
      tone: "verify"
    },
    {
      title: "Escalate with context if unresolved",
      detail: problem
        ? `Reference ${problem.problemId || "the linked problem record"}${problem.status ? ` (${problem.status})` : ""} and route to ${route}. Attach logs, screenshots, reproduction steps, and business impact.`
        : `Route to ${route}. Attach the search query, validation outcome, logs, screenshots, reproduction steps, and any workaround attempted.`,
      evidence: bestProblem?.title,
      tone: "escalate"
    }
  ];

  const closure = solution
    ? `Issue: ${solution.issue}\n\nCause: ${solution.cause || "Not documented"}\n\nResolution:\n${solution.resolution}`
    : `Issue: ${issue}\n\nCause: Pending confirmation\n\nResolution:\nValidated symptoms, searched the offline knowledge base, and routed to ${route} with diagnostic evidence.`;

  return {
    issue,
    confidence,
    route,
    summary: best
      ? `Guided path generated from ${ordered.length} matching internal record${ordered.length === 1 ? "" : "s"}; ${solutionPool.length} solution candidate${solutionPool.length === 1 ? "" : "s"} clustered for triage.`
      : "Guided path generated without a verified match.",
    closure,
    solutionCandidates: solutionPool.length,
    steps,
    references
  } satisfies GuidePlan;
}
