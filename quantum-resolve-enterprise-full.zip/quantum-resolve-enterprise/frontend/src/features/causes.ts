import type { SearchDocument, Solution } from "../types";

export function normalizeCauseText(cause: string) {
  return cause
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\b(the|a|an|and|or|of|to|in|for|with|due|because|caused|by|issue|problem|error)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function distinctCauseSummaries(documents: SearchDocument[], limit = 10) {
  const buckets = new Map<string, { cause: string; count: number; bestScore: number }>();
  for (const document of documents.filter((item) => item.type === "solution")) {
    const cause = ((document.payload as Solution).cause || "").trim();
    if (!cause) continue;
    const key = normalizeCauseText(cause);
    if (!key) continue;
    const existing = buckets.get(key);
    if (!existing) {
      buckets.set(key, { cause, count: 1, bestScore: document.score || 0 });
    } else {
      existing.count += 1;
      existing.bestScore = Math.max(existing.bestScore, document.score || 0);
      if (cause.length > existing.cause.length && cause.length < 220) existing.cause = cause;
    }
  }
  return [...buckets.values()]
    .sort((a, b) => b.count - a.count || b.bestScore - a.bestScore)
    .slice(0, limit)
    .map(({ cause, count }) => ({ cause, count }));
}
