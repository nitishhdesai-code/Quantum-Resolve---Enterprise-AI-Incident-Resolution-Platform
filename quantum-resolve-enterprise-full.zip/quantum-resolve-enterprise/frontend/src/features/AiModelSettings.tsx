import { KeyRound, WandSparkles } from "lucide-react";
import { Input, Slider } from "./formControls";
import type { AiProvider, AiSettings } from "../types";

export function AiModelSettings({
  settings,
  setSettings,
  models,
  ready,
  testing,
  testConnection
}: {
  settings: AiSettings;
  setSettings: (settings: AiSettings | ((current: AiSettings) => AiSettings)) => void;
  models: Record<AiProvider, { label: string; value: string; detail: string }[]>;
  ready: boolean;
  testing: boolean;
  testConnection: () => void;
}) {
  const providerModels = models[settings.provider] || [];
  const update = <K extends keyof AiSettings>(key: K, value: AiSettings[K]) =>
    setSettings((current) => ({ ...current, [key]: value }));

  return (
    <div className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
      <div className="space-y-4">
        <div className="border border-line bg-white/[0.04] p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-bold text-signal">
            <WandSparkles size={18} />
            Runtime AI Control
          </div>
          <label className="chip mb-3 cursor-pointer">
            <input type="checkbox" checked={settings.enabled} onChange={(event) => update("enabled", event.target.checked)} />
            Enable model reasoning
          </label>
          <div className="grid gap-3">
            <div>
              <label className="label">Provider</label>
              <select
                className="field"
                value={settings.provider}
                onChange={(event) => {
                  const provider = event.target.value as AiProvider;
                  setSettings((current) => ({
                    ...current,
                    provider,
                    model: models[provider]?.[0]?.value || current.model
                  }));
                }}
              >
                {Object.keys(models).map((provider) => (
                  <option key={provider} value={provider}>
                    {provider}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Model</label>
              <select className="field" value={settings.model} onChange={(event) => update("model", event.target.value)}>
                {providerModels.map((model) => (
                  <option key={model.value} value={model.value}>
                    {model.label}
                  </option>
                ))}
              </select>
            </div>
            <Input label="Custom Model ID" value={settings.model} onChange={(model) => update("model", model)} />
            {(settings.provider === "azure-openai" || settings.provider === "custom") && (
              <Input label="Endpoint" value={settings.endpoint || ""} onChange={(endpoint) => update("endpoint", endpoint)} />
            )}
            <div>
              <label className="label">API Key</label>
              <input
                className="field"
                type="password"
                value={settings.apiKey}
                onChange={(event) =>
                  setSettings((current) => ({
                    ...current,
                    apiKey: event.target.value,
                    enabled: event.target.value.trim() ? true : current.enabled,
                    provider: current.provider || "gemini"
                  }))
                }
                placeholder="Paste API key for this session"
              />
              <div className="mt-2 text-xs leading-5 text-zinc-500">
                The key is kept in browser session storage. In local demo mode, Gemini can run directly from the browser if the backend is not running.
              </div>
            </div>
            <button
              className="button-secondary px-4"
              onClick={testConnection}
              disabled={!settings.apiKey.trim() || testing || settings.provider !== "gemini"}
            >
              <KeyRound className="mr-2 inline" size={15} />
              {testing ? "Testing" : "Test Gemini Key"}
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid gap-3 md:grid-cols-3">
          {providerModels.map((model) => (
            <button
              key={model.value}
              className={`model-card ${settings.model === model.value ? "is-active" : ""}`}
              onClick={() => update("model", model.value)}
            >
              <span className="text-sm font-black text-zinc-100">{model.label}</span>
              <span className="mt-2 block text-xs leading-5 text-zinc-500">{model.detail}</span>
            </button>
          ))}
        </div>
        <div className="border border-line bg-white/[0.04] p-4">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="chip cursor-pointer">
              <input type="checkbox" checked={settings.grounding} onChange={(event) => update("grounding", event.target.checked)} />
              Web grounding where supported
            </label>
            <Slider label="Creativity" value={Math.round(settings.temperature * 100)} onChange={(value) => update("temperature", value / 100)} />
          </div>
          <div className={`mt-4 border p-3 text-sm ${ready ? "border-grove/40 text-grove" : "border-pollen/40 text-pollen"}`}>
            {ready
              ? settings.provider === "gemini"
                ? "AI is ready. The app will use the backend proxy when available, then Gemini browser fallback for this local demo."
                : "AI is ready. Non-Gemini providers require the backend proxy on localhost:8080."
              : "Offline deterministic answers remain active until an API key and model are configured."}
          </div>
        </div>
      </div>
    </div>
  );
}
