import { Moon, Sun } from "lucide-react";

export function applyTheme(theme: "dark" | "light") {
  document.documentElement.dataset.theme = theme;
}

export function ThemeToggle({ theme, setTheme }: { theme: "dark" | "light"; setTheme: (theme: "dark" | "light") => void }) {
  return (
    <button className="icon-button" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title="Theme">
      {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
    </button>
  );
}
