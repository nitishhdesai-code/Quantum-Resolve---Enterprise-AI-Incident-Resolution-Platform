import { Bot, CheckCircle2, ClipboardCheck, Copy, GitBranch, RefreshCw, Sparkles } from "lucide-react";
import type { GuidePlan } from "./guide";

export function GuideWorkspace({
  busy,
  plan,
  copyClosure,
  askFollowUp
}: {
  busy: boolean;
  plan: GuidePlan | null;
  copyClosure: () => void;
  askFollowUp: () => void;
}) {
  if (busy) {
    return (
      <div className="grid min-h-[360px] place-items-center text-center">
        <div>
          <RefreshCw className="mx-auto mb-3 animate-spin text-signal" size={28} />
          <div className="text-sm font-semibold text-zinc-200">Building guided resolution...</div>
        </div>
      </div>
    );
  }

  if (!plan) {
    return <div className="text-sm text-zinc-500">No guide has been generated yet.</div>;
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.3fr_0.7fr]">
      <div className="space-y-4">
        <div className="border border-line bg-white/[0.04] p-4">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <span className="chip text-signal">
              <Bot size={16} />
              {plan.confidence}
            </span>
            <span className="chip">
              <GitBranch size={16} />
              {plan.route}
            </span>
          </div>
          <div className="label">Issue</div>
          <div className="text-base font-semibold text-zinc-100">{plan.issue}</div>
          <div className="mt-2 text-sm text-zinc-400">{plan.summary}</div>
        </div>

        <div className="space-y-3">
          {plan.steps.map((step, index) => (
            <div key={`${step.title}-${index}`} className="grid gap-3 border border-line bg-white/[0.035] p-4 md:grid-cols-[44px_1fr]">
              <div
                className={`grid h-10 w-10 place-items-center border ${
                  step.tone === "verify"
                    ? "border-grove/50 text-grove"
                    : step.tone === "escalate"
                      ? "border-pollen/50 text-pollen"
                      : "border-signal/50 text-signal"
                }`}
              >
                {step.tone === "verify" ? <CheckCircle2 size={20} /> : step.tone === "escalate" ? <GitBranch size={20} /> : <ClipboardCheck size={20} />}
              </div>
              <div>
                <div className="mb-1 flex items-center gap-2">
                  <span className="font-mono text-xs text-zinc-500">{String(index + 1).padStart(2, "0")}</span>
                  <h3 className="text-sm font-bold text-zinc-100">{step.title}</h3>
                </div>
                <p className="whitespace-pre-wrap text-sm leading-6 text-zinc-300">{step.detail}</p>
                {step.evidence && <div className="mt-3 border-l-2 border-signal/50 pl-3 text-xs leading-5 text-zinc-400">{step.evidence}</div>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <aside className="space-y-4">
        {plan.aiAdvisory && (
          <div className="border border-signal/30 bg-signal/10 p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-bold text-signal">
              <Sparkles size={16} />
              AI Playbook Enhancement
            </div>
            <div className="max-h-72 overflow-y-auto whitespace-pre-wrap text-sm leading-6 text-zinc-200">{plan.aiAdvisory}</div>
            {plan.sources?.length ? (
              <div className="mt-3 space-y-1">
                {plan.sources.map((source) => (
                  <a key={source.uri} className="block break-all text-xs text-signal underline" href={source.uri} target="_blank" rel="noreferrer">
                    {source.title}
                  </a>
                ))}
              </div>
            ) : null}
          </div>
        )}
        <div className="border border-line bg-white/[0.04] p-4">
          <div className="label">References</div>
          {plan.references.length ? (
            <div className="space-y-3">
              {plan.references.map((reference) => (
                <div key={reference.id} className="border border-line bg-black/10 p-3">
                  <div className="mb-1 text-xs font-bold uppercase text-zinc-500">{reference.type}</div>
                  {reference.link ? (
                    <a className="text-sm font-semibold text-signal underline" href={reference.link} target="_blank" rel="noreferrer">
                      {reference.title}
                    </a>
                  ) : (
                    <div className="text-sm font-semibold text-zinc-200">{reference.title}</div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm text-zinc-500">No reference record available.</div>
          )}
        </div>

        <div className="border border-line bg-white/[0.04] p-4">
          <div className="label">Closure Draft</div>
          <div className="max-h-56 overflow-y-auto whitespace-pre-wrap text-sm leading-6 text-zinc-300">{plan.closure}</div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <button className="button-secondary px-3" onClick={copyClosure}>
              <Copy className="mr-2 inline" size={15} />
              Copy
            </button>
            <button className="button-primary px-3" onClick={askFollowUp}>
              <Sparkles className="mr-2 inline" size={15} />
              Ask
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}
