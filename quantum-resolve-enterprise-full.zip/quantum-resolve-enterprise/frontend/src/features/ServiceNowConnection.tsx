export function ServiceNowConnection() {
  return (
    <div className="border border-line p-4 md:col-span-2">
      <div className="label">ServiceNow Connection</div>
      <div className="grid gap-3 md:grid-cols-3">
        <input className="field" value="https://amat.service-now.com" disabled />
        <input className="field" placeholder="Username" disabled />
        <input className="field" placeholder="Token" disabled />
      </div>
      <div className="mt-2 text-xs leading-5 text-zinc-500">
        Placeholder for future ServiceNow API integration. Keep credentials server-side in production.
      </div>
    </div>
  );
}
