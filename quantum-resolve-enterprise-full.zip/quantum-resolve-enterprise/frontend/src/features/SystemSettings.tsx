import { Database, RefreshCw } from "lucide-react";
import { ServiceNowConnection } from "./ServiceNowConnection";

type ServiceFlags = {
  database: boolean;
  meilisearch: boolean;
  opensearch?: boolean;
  elasticsearch?: boolean;
  solr?: boolean;
  ai: boolean;
};

export function SystemSettings({
  apiBase,
  services,
  refreshSnapshot,
  reindex
}: {
  apiBase: string;
  services: ServiceFlags;
  refreshSnapshot: () => void;
  reindex: () => void;
}) {
  return (
    <>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="border border-line p-4">
          <div className="label">API Base</div>
          <div className="break-all font-mono text-sm text-zinc-200">{apiBase}</div>
        </div>
        <div className="border border-line p-4">
          <div className="label">Services</div>
          <div className="space-y-2 text-sm">
            <ServiceRow label="PostgreSQL" value={services.database} />
            <ServiceRow label="Meilisearch" value={services.meilisearch} />
            <ServiceRow label="OpenSearch" value={Boolean(services.opensearch)} />
            <ServiceRow label="Elasticsearch" value={Boolean(services.elasticsearch)} />
            <ServiceRow label="Apache Solr" value={Boolean(services.solr)} />
            <ServiceRow label="AI Provider" value={services.ai} />
          </div>
        </div>
        <ServiceNowConnection />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button className="button-secondary px-4" onClick={refreshSnapshot}>
          <RefreshCw className="mr-2 inline" size={16} />
          Refresh Snapshot
        </button>
        <button className="button-primary px-4" onClick={reindex}>
          <Database className="mr-2 inline" size={16} />
          Reindex Search
        </button>
      </div>
    </>
  );
}

function ServiceRow({ label, value }: { label: string; value: boolean }) {
  return (
    <div className="flex items-center justify-between border border-line px-3 py-2">
      <span>{label}</span>
      <span className={value ? "text-grove" : "text-pollen"}>{value ? "Ready" : "Unavailable"}</span>
    </div>
  );
}
