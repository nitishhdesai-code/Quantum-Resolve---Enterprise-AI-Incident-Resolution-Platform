import type { LucideIcon } from "lucide-react";

interface MetricCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  tone: "signal" | "ember" | "pollen" | "grove";
}

const toneMap = {
  signal: "text-signal border-signal/30 bg-signal/10",
  ember: "text-ember border-ember/30 bg-ember/10",
  pollen: "text-pollen border-pollen/30 bg-pollen/10",
  grove: "text-grove border-grove/30 bg-grove/10"
};

export function MetricCard({ icon: Icon, label, value, tone }: MetricCardProps) {
  return (
    <div className="panel flex min-h-[86px] items-center gap-4 p-4">
      <div className={`grid h-10 w-10 place-items-center rounded-lg border ${toneMap[tone]}`}>
        <Icon size={20} />
      </div>
      <div>
        <div className="font-mono text-2xl font-bold tracking-normal text-zinc-50">{value}</div>
        <div className="text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500">{label}</div>
      </div>
    </div>
  );
}

