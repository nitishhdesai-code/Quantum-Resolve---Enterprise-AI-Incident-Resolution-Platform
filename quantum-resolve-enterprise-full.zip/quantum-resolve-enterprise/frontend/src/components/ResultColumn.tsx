import { BookOpen, ExternalLink, Lightbulb, SearchCheck } from "lucide-react";
import type { Category, SearchDocument } from "../types";

const meta = {
  solution: { label: "Solutions", icon: Lightbulb, tone: "text-signal" },
  kb: { label: "KB Articles", icon: BookOpen, tone: "text-ember" },
  problem: { label: "Problem IDs", icon: SearchCheck, tone: "text-grove" }
};

interface ResultColumnProps {
  type: Category;
  results: SearchDocument[];
  onSelect: (document: SearchDocument) => void;
}

export function ResultColumn({ type, results, onSelect }: ResultColumnProps) {
  const Icon = meta[type].icon;
  return (
    <section className="panel min-h-[360px] p-4">
      <div className="mb-4 flex items-center justify-between border-b border-line pb-3">
        <div className={`flex items-center gap-2 text-sm font-bold ${meta[type].tone}`}>
          <Icon size={18} />
          {meta[type].label}
        </div>
        <span className="font-mono text-xs text-zinc-500">{results.length}</span>
      </div>
      <div className="space-y-3">
        {results.length === 0 ? (
          <div className="grid min-h-[220px] place-items-center text-center text-sm text-zinc-500">
            No matches yet.
          </div>
        ) : (
          results.map((item) => (
            <button
              key={item.uid}
              className="result-tile group text-left"
              onClick={() => onSelect(item)}
              title="Open details"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="text-sm font-semibold leading-6 text-zinc-100">{item.title}</div>
                <ExternalLink className="mt-1 shrink-0 text-zinc-600 group-hover:text-signal" size={15} />
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-zinc-500">
                <span className="uppercase tracking-[0.16em]">{item.type}</span>
                <span className="font-mono">{item.score?.toFixed(2) || "0.00"}</span>
              </div>
            </button>
          ))
        )}
      </div>
    </section>
  );
}

