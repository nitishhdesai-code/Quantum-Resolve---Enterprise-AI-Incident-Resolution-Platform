import { buildDocuments } from "../lib/offlineSearch";
import { scorePassesThreshold } from "../lib/searchScoring";
import type {
  BootstrapPayload,
  Category,
  SearchConfig,
  SearchDocument,
  SearchResponse,
  Solution,
  TierRecord
} from "../types";

type LoadMessage = { id: number; type: "load"; payload: BootstrapPayload };
type SearchMessage = {
  id: number;
  type: "search";
  payload: { query: string; categories: Category[]; config: SearchConfig; tierAccuracy: number };
};
type CloseNotesMessage = {
  id: number;
  type: "closeNotes";
  payload: { issue: string; config: SearchConfig };
};
type WorkerMessage = LoadMessage | SearchMessage | CloseNotesMessage;
type WorkerContext = {
  onmessage: ((event: MessageEvent<WorkerMessage>) => void) | null;
  postMessage: (message: unknown) => void;
};

const ctx = self as unknown as WorkerContext;
const docsByUid = new Map<string, SearchDocument>();
const postings = new Map<string, Set<string>>();
const docTokenCounts = new Map<string, Map<string, number>>();
const docLengths = new Map<string, number>();
let documents: SearchDocument[] = [];
let vocabulary: string[] = [];
let avgDocLength = 1;
let bootstrap: BootstrapPayload | null = null;

ctx.onmessage = (event: MessageEvent<WorkerMessage>) => {
  const { id, type, payload } = event.data;
  try {
    if (type === "load") {
      load(payload);
      post(id, type, {
        documents: documents.length,
        vocabulary: vocabulary.length,
        stats: payload.stats
      });
      return;
    }

    if (!bootstrap) throw new Error("Offline search worker has no data loaded.");

    if (type === "search") {
      post(id, type, runSearch(payload.query, payload.categories, payload.config, payload.tierAccuracy));
      return;
    }

    if (type === "closeNotes") {
      const match = runSearch(payload.issue, ["solution"], payload.config, 0.5).results.solution[0];
      post(id, type, closeNotesFromMatch(payload.issue, match));
    }
  } catch (error) {
    ctx.postMessage({
      id,
      type,
      ok: false,
      error: error instanceof Error ? error.message : "Worker error"
    });
  }
};

function load(payload: BootstrapPayload) {
  bootstrap = payload;
  documents = buildDocuments(payload);
  docsByUid.clear();
  postings.clear();
  docTokenCounts.clear();
  docLengths.clear();

  for (const doc of documents) {
    docsByUid.set(doc.uid, doc);
    const allTokens = [
      ...tokenize(`${doc.title} ${doc.title} ${doc.title}`),
      ...tokenize(`${doc.description} ${doc.description}`),
      ...tokenize(doc.content),
      ...doc.keywords.flatMap(tokenize)
    ].flatMap((token) => (stem(token) === token ? [token] : [token, stem(token)]));
    const counts = new Map<string, number>();
    for (const token of allTokens) counts.set(token, (counts.get(token) || 0) + 1);
    docTokenCounts.set(doc.uid, counts);
    docLengths.set(doc.uid, allTokens.length || 1);

    for (const token of new Set(allTokens)) {
      const bucket = postings.get(token) || new Set<string>();
      bucket.add(doc.uid);
      postings.set(token, bucket);
    }
  }

  vocabulary = [...postings.keys()];
  avgDocLength = documents.length
    ? [...docLengths.values()].reduce((sum, length) => sum + length, 0) / documents.length
    : 1;
}

function runSearch(
  query: string,
  categories: Category[],
  config: SearchConfig,
  tierAccuracy: number
): SearchResponse {
  if (!bootstrap) throw new Error("No offline data loaded.");
  const rawKeywords = raw(query);
  const keywords = processed(rawKeywords, config, bootstrap);
  const groups = { solution: [], kb: [], problem: [] } as Record<Category, SearchDocument[]>;

  if (!query.trim() || keywords.length === 0) {
    return emptyResponse(query, groups, "offline-worker");
  }

  const candidateIds = candidateSet(keywords, config);
  const candidateDocs =
    candidateIds.size > 0
      ? [...candidateIds].map((uid) => docsByUid.get(uid)).filter(Boolean) as SearchDocument[]
      : documents;

  for (const doc of candidateDocs) {
    if (!categories.includes(doc.type)) continue;
    const titleScore = scoreField(doc.title, keywords, config);
    const descriptionScore = scoreField(doc.description, keywords, config);
    const contentScore = scoreField(doc.content, keywords, config);
    let total =
      titleScore * config.titleWeight +
      descriptionScore * config.descriptionWeight +
      contentScore * config.contentWeight;
    total += bm25Score(doc.uid, keywords) * 1.6;
    total += phraseBoost(doc, query) * 3;
    total += proximityBoost(doc, keywords);

    const haystack = fullText(doc);
    if (config.searchMode === "all") {
      const allFound = rawKeywords.every((word) => {
        const target = config.stemming ? stem(word) : word;
        const haystackTokens = tokenize(haystack);
        return (
          haystack.includes(target) ||
          (config.typoTolerance &&
            haystackTokens.some((token) => levenshtein(token, target) / Math.max(target.length, 1) <= typoThreshold(config)))
        );
      });
      if (!allFound) total = 0;
    }

    if (config.searchMode === "exact" && !haystack.includes(query.toLowerCase())) {
      total = 0;
    }

    if (scorePassesThreshold(total, keywords.length, config)) {
      groups[doc.type].push({ ...doc, score: Number(total.toFixed(3)) });
    }
  }

  for (const category of Object.keys(groups) as Category[]) {
    groups[category].sort((a, b) => (b.score || 0) - (a.score || 0));
    const limit = config.resultLimits[category];
    groups[category] = groups[category].slice(0, limit?.enabled ? limit.value : 50);
  }

  return {
    query,
    results: groups,
    prediction: predictTier(query, bootstrap.tiers, config, bootstrap, tierAccuracy),
    engine: "offline-worker",
    counts: {
      solution: groups.solution.length,
      kb: groups.kb.length,
      problem: groups.problem.length
    }
  };
}

function candidateSet(keywords: string[], config: SearchConfig) {
  const ids = new Set<string>();
  for (const keyword of keywords) {
    addPostings(keyword, ids);

    if (config.typoTolerance && keyword.length >= 4) {
      let fuzzyHits = 0;
      for (const token of vocabulary) {
        if (Math.abs(token.length - keyword.length) > 2) continue;
        if (levenshtein(token, keyword) / Math.max(keyword.length, 1) <= typoThreshold(config)) {
          addPostings(token, ids);
          fuzzyHits += 1;
          if (fuzzyHits > 80) break;
        }
      }
    }
  }
  return ids;
}

function addPostings(token: string, ids: Set<string>) {
  const bucket = postings.get(token);
  if (!bucket) return;
  for (const id of bucket) ids.add(id);
}

function closeNotesFromMatch(issue: string, match?: SearchDocument) {
  if (!match) return "No similar past solutions found.";
  const payload = match.payload as Solution;
  return `Issue: ${payload.issue || issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution: ${
    payload.resolution || "No resolution documented."
  }`;
}

function emptyResponse(query: string, groups: Record<Category, SearchDocument[]>, engine: string): SearchResponse {
  return {
    query,
    results: groups,
    prediction: null,
    engine,
    counts: {
      solution: 0,
      kb: 0,
      problem: 0
    }
  };
}

function predictTier(
  query: string,
  tiers: TierRecord[],
  config: SearchConfig,
  data: BootstrapPayload,
  accuracy: number
) {
  const keywords = processed(raw(query), config, data);
  if (!keywords.length) return null;
  let best: TierRecord | null = null;
  let bestScore = -1;
  for (const tier of tiers) {
    const current = scoreField(`${tier.category} ${tier.tier1} ${tier.tier2} ${tier.tier3}`, keywords, config);
    if (current > bestScore) {
      bestScore = current;
      best = tier;
    }
  }
  const confidence = bestScore / keywords.length;
  return best && confidence >= accuracy ? { ...best, confidence: Number(confidence.toFixed(2)) } : null;
}

function raw(query: string) {
  return query
    .toLowerCase()
    .split(/[\s,.;:()/_-]+/)
    .map((word) => word.trim())
    .filter(Boolean);
}

function processed(words: string[], config: SearchConfig, data: BootstrapPayload) {
  let expanded = [...words];
  if (config.synonyms) {
    expanded = [...new Set(expanded.flatMap((word) => [word, ...(data.dictionaries.synonymMap[word] || [])]))];
  }
  if (config.acronyms) {
    expanded = [...new Set(expanded.flatMap((word) => [word, ...(data.dictionaries.acronymMap[word] || [])]))];
  }

  const critical = new Set(["tc", "nx", "kb", "id"]);
  let filtered = expanded.filter((word) => word.length > 2 && !data.dictionaries.stopWords.includes(word));
  for (const word of words) if (critical.has(word) && !filtered.includes(word)) filtered.push(word);
  if (config.stemming) filtered = filtered.map(stem);
  return [...new Set(filtered.flatMap(tokenize))];
}

function scoreField(text: string, keywords: string[], config: SearchConfig) {
  const lower = text.toLowerCase();
  const words = tokenize(lower);
  let score = 0;
  for (const keyword of keywords) {
    if (matchesKeyword(lower, words, keyword)) score += keyword.length <= 3 ? 1.2 : 1;
    else if (config.phonetic && words.some((word) => soundex(word) === soundex(keyword))) {
      score += 0.5;
    }
  }
  return score;
}

function matchesKeyword(text: string, words: string[], keyword: string) {
  if (keyword.length <= 3) return words.includes(keyword);
  return text.includes(keyword);
}

function bm25Score(uid: string, keywords: string[]) {
  const counts = docTokenCounts.get(uid);
  const length = docLengths.get(uid) || 1;
  if (!counts) return 0;
  const k1 = 1.35;
  const b = 0.72;
  let score = 0;
  for (const keyword of keywords) {
    const frequency = counts.get(keyword) || 0;
    if (!frequency) continue;
    const docsWithTerm = postings.get(keyword)?.size || 0;
    const idf = Math.log(1 + (documents.length - docsWithTerm + 0.5) / (docsWithTerm + 0.5));
    score += idf * ((frequency * (k1 + 1)) / (frequency + k1 * (1 - b + b * (length / avgDocLength))));
  }
  return score;
}

function phraseBoost(doc: SearchDocument, query: string) {
  const phrase = query.toLowerCase().trim();
  if (phrase.length < 5) return 0;
  const text = fullText(doc);
  if (doc.title.toLowerCase().includes(phrase)) return 2.5;
  if (text.includes(phrase)) return 1.5;
  return 0;
}

function proximityBoost(doc: SearchDocument, keywords: string[]) {
  if (keywords.length < 2) return 0;
  const tokens = tokenize(fullText(doc));
  const positions = keywords
    .map((keyword) => tokens.findIndex((token) => token === keyword || stem(token) === keyword))
    .filter((position) => position >= 0)
    .sort((a, b) => a - b);
  if (positions.length < 2) return 0;
  const span = positions[positions.length - 1] - positions[0] + 1;
  return Math.max(0, keywords.length / Math.max(span, 1));
}

function tokenize(text: string) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .map((word) => word.trim())
    .filter((word) => word.length > 1);
}

function fullText(doc: SearchDocument) {
  return `${doc.title} ${doc.description} ${doc.content}`.toLowerCase();
}

function stem(word: string) {
  return word.replace(/(ing|s|ed)$/i, "");
}

function typoThreshold(config: SearchConfig) {
  return 1 - config.fuzzySensitivity / 100;
}

function levenshtein(a: string, b: string) {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j += 1) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i += 1) {
    for (let j = 1; j <= b.length; j += 1) {
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return matrix[a.length][b.length];
}

function soundex(value: string) {
  const chars = value.toLowerCase().split("");
  const first = chars.shift() || "";
  const codes: Record<string, string> = {
    a: "",
    e: "",
    i: "",
    o: "",
    u: "",
    b: "1",
    f: "1",
    p: "1",
    v: "1",
    c: "2",
    g: "2",
    j: "2",
    k: "2",
    q: "2",
    s: "2",
    x: "2",
    z: "2",
    d: "3",
    t: "3",
    l: "4",
    m: "5",
    n: "5",
    r: "6"
  };
  const encoded = chars
    .map((char) => codes[char] || "")
    .filter((code, index, all) => (index === 0 ? code !== codes[first] : code !== all[index - 1]))
    .join("");
  return `${first}${encoded}000`.slice(0, 4).toUpperCase();
}

function post(id: number, type: string, payload: unknown) {
  ctx.postMessage({ id, type, ok: true, payload });
}
