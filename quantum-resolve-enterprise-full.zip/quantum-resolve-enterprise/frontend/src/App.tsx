import {
  Brain,
  Cpu,
  Database,
  Download,
  KeyRound,
  ListChecks,
  Save,
  Search,
  Settings,
  ShieldCheck,
  Send,
  SlidersHorizontal,
  Sparkles,
  Target,
  Upload
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { MetricCard } from "./components/MetricCard";
import { Modal } from "./components/Modal";
import { ResultColumn } from "./components/ResultColumn";
import { AiModelSettings } from "./features/AiModelSettings";
import { CloseNotesGenerator } from "./features/CloseNotesGenerator";
import { CommunicationDraftPanel, type CommunicationDraft } from "./features/CommunicationDraftPanel";
import { GuideWorkspace } from "./features/GuideWorkspace";
import { StatusPill } from "./features/StatusPill";
import { SystemSettings } from "./features/SystemSettings";
import { ThemeToggle, applyTheme } from "./features/ThemeToggle";
import { distinctCauseSummaries } from "./features/causes";
import { Input, Slider, TextArea, Weight } from "./features/formControls";
import { contextFromDocuments, createGuidePlan, type GuidePlan } from "./features/guide";
import { aiModels, categories, emptyResults, fallbackConfig, searchProviders } from "./features/searchConfig";
import { api } from "./lib/api";
import { callBrowserGemini } from "./lib/browserAi";
import { fallbackBootstrap } from "./lib/fallbackData";
import { fetchPackagedKnowledge, parseKnowledgeFile } from "./lib/importers";
import { localCloseNotes, runOfflineSearch } from "./lib/offlineSearch";
import { closeNotesOfflineWorker, loadOfflineSearch, searchOfflineWorker } from "./lib/searchWorkerClient";
import {
  cacheBootstrap,
  downloadJson,
  readAiSettings,
  readCachedBootstrap,
  readSearchProvider,
  readTheme,
  writeAiSettings,
  writeSearchProvider,
  writeTheme
} from "./lib/storage";
import type {
  AiSettings,
  BootstrapPayload,
  Category,
  KbArticle,
  ProblemRecord,
  SearchConfig,
  SearchDocument,
  SearchResultGroup,
  SearchProvider,
  Solution
} from "./types";

type Toast = { message: string; tone: "info" | "success" | "warning" | "error" };
type ChatMessage = { role: "user" | "agent"; text: string; sources?: { uri: string; title: string }[] };

export default function App() {
  const [theme, setTheme] = useState<"dark" | "light">(() => readTheme());
  const [bootstrap, setBootstrap] = useState<BootstrapPayload | null>(null);
  const [searchConfig, setSearchConfig] = useState<SearchConfig>(fallbackConfig);
  const [searchProvider, setSearchProvider] = useState<SearchProvider>(() => readSearchProvider());
  const [aiSettings, setAiSettings] = useState<AiSettings>(() => readAiSettings());
  const [query, setQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<Category[]>(categories);
  const [tierAccuracy, setTierAccuracy] = useState(0.5);
  const [results, setResults] = useState<SearchResultGroup>(emptyResults);
  const [prediction, setPrediction] = useState<BootstrapPayload["tiers"][number] | null>(null);
  const [engine, setEngine] = useState("idle");
  const [loading, setLoading] = useState(false);
  const [offlineIndex, setOfflineIndex] = useState({ ready: false, busy: false, documents: 0, vocabulary: 0 });
  const [importing, setImporting] = useState(false);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [activeDoc, setActiveDoc] = useState<SearchDocument | null>(null);
  const [keywordDraft, setKeywordDraft] = useState("");
  const [linkDraft, setLinkDraft] = useState("");
  const [toast, setToast] = useState<Toast | null>(null);
  const [online, setOnline] = useState(() => navigator.onLine);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aiSettingsOpen, setAiSettingsOpen] = useState(false);
  const [aiTesting, setAiTesting] = useState(false);
  const [causeAnalysis, setCauseAnalysis] = useState<{ cause: string; count: number }[]>([]);
  const [closeIssue, setCloseIssue] = useState("");
  const [closeOutput, setCloseOutput] = useState("");
  const [comm, setComm] = useState<CommunicationDraft>({
    ticket: "",
    userName: "",
    userEmail: "",
    priority: "Medium",
    issue: "",
    output: ""
  });
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatBusy, setChatBusy] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [guideBusy, setGuideBusy] = useState(false);
  const [guidePlan, setGuidePlan] = useState<GuidePlan | null>(null);
  const [lastAgentText, setLastAgentText] = useState("");
  const [curationOpen, setCurationOpen] = useState(false);
  const [curationForm, setCurationForm] = useState({
    issue: "",
    cause: "",
    resolution: "",
    tier1: "",
    tier2: "",
    tier3: "",
    keywords: ""
  });
  const toastTimer = useRef<number>();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const services = bootstrap?.services || { database: false, meilisearch: false, ai: false };
  const totalResults = results.solution.length + results.kb.length + results.problem.length;
  const loadedRecords =
    (bootstrap?.stats.solutions || 0) + (bootstrap?.stats.kbArticles || 0) + (bootstrap?.stats.problems || 0);
  const aiReady = aiSettings.enabled && Boolean(aiSettings.apiKey.trim()) && Boolean(aiSettings.model.trim());
  const activeAiModel = aiModels[aiSettings.provider]?.find((model) => model.value === aiSettings.model);

  const showToast = useCallback((message: string, tone: Toast["tone"] = "info") => {
    window.clearTimeout(toastTimer.current);
    setToast({ message, tone });
    toastTimer.current = window.setTimeout(() => setToast(null), 3600);
  }, []);

  const activateBootstrap = useCallback(
    async (payload: BootstrapPayload, message?: string, persist = true) => {
      setBootstrap(payload);
      setSearchConfig(payload.defaultSearchConfig || fallbackConfig);
      setOfflineIndex({ ready: false, busy: true, documents: 0, vocabulary: 0 });
      try {
        const indexed = await loadOfflineSearch(payload);
        setOfflineIndex({
          ready: true,
          busy: false,
          documents: indexed.documents,
          vocabulary: indexed.vocabulary
        });
      } catch {
        setOfflineIndex({ ready: false, busy: false, documents: 0, vocabulary: 0 });
      }
      if (persist) await cacheBootstrap(payload);
      if (message) showToast(message, "success");
    },
    [showToast]
  );

  const loadBootstrap = useCallback(async () => {
    try {
      const payload = await api.bootstrap();
      await activateBootstrap(payload, "Knowledge snapshot loaded.");
    } catch (error) {
      const cached = await readCachedBootstrap();
      if (cached) {
        await activateBootstrap(cached, undefined, false);
        showToast("Running from IndexedDB offline cache.", "warning");
      } else {
        try {
          const packaged = await fetchPackagedKnowledge();
          await activateBootstrap(packaged, undefined);
          showToast("Loaded packaged offline database.", "warning");
        } catch {
          await activateBootstrap(fallbackBootstrap, undefined);
          showToast("Running from bundled offline data.", "warning");
        }
      }
    }
  }, [activateBootstrap, showToast]);

  useEffect(() => {
    applyTheme(theme);
    writeTheme(theme);
  }, [theme]);

  useEffect(() => {
    writeSearchProvider(searchProvider);
  }, [searchProvider]);

  useEffect(() => {
    writeAiSettings(aiSettings);
  }, [aiSettings]);

  useEffect(() => {
    void loadBootstrap();
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, [loadBootstrap]);

  useEffect(() => {
    if (!activeDoc) return;
    setKeywordDraft(activeDoc.keywords.join(", "));
    const payload = activeDoc.payload as { link?: string };
    setLinkDraft(payload.link || "");
  }, [activeDoc]);

  const runSearch = useCallback(
    async (
      incomingQuery = query,
      overrides: {
        categories?: Category[];
        config?: SearchConfig;
        provider?: SearchProvider;
        tierAccuracy?: number;
      } = {}
    ) => {
      if (!bootstrap) {
        showToast("Knowledge data is still loading.", "warning");
        return;
      }
      const trimmed = incomingQuery.trim();
      if (!trimmed) {
        setResults(emptyResults);
        setPrediction(null);
        setEngine("idle");
        return;
      }

      const categoriesForSearch = overrides.categories || selectedCategories;
      const configForSearch = overrides.config || searchConfig;
      const providerForSearch = overrides.provider || searchProvider;
      const tierAccuracyForSearch = overrides.tierAccuracy ?? tierAccuracy;

      setLoading(true);
      try {
        if (providerForSearch === "offline") {
          const response = offlineIndex.ready
            ? await searchOfflineWorker(trimmed, categoriesForSearch, configForSearch, tierAccuracyForSearch)
            : runOfflineSearch(bootstrap, trimmed, categoriesForSearch, configForSearch, tierAccuracyForSearch);
          setResults(response.results);
          setPrediction(response.prediction);
          setEngine(offlineIndex.ready ? "offline-worker-bm25" : response.engine);
          return;
        }
        const response = await api.search({
          query: trimmed,
          categories: categoriesForSearch,
          config: configForSearch,
          tierAccuracy: tierAccuracyForSearch,
          provider: providerForSearch
        });
        setResults(response.results);
        setPrediction(response.prediction);
        setEngine(response.engine);
      } catch {
        const response = offlineIndex.ready
          ? await searchOfflineWorker(trimmed, categoriesForSearch, configForSearch, tierAccuracyForSearch)
          : runOfflineSearch(bootstrap, trimmed, categoriesForSearch, configForSearch, tierAccuracyForSearch);
        setResults(response.results);
        setPrediction(response.prediction);
        setEngine(response.engine);
        showToast(offlineIndex.ready ? "Search used worker offline index." : "Search used local offline index.", "warning");
      } finally {
        setLoading(false);
      }
    },
    [bootstrap, offlineIndex.ready, query, searchConfig, searchProvider, selectedCategories, showToast, tierAccuracy]
  );

  useEffect(() => {
    if (query.trim().length < 2) return;
    const timer = window.setTimeout(() => void runSearch(query), 360);
    return () => window.clearTimeout(timer);
  }, [query]);

  const toggleCategory = (category: Category) => {
    const next = selectedCategories.includes(category)
      ? selectedCategories.filter((item) => item !== category)
      : [...selectedCategories, category];
    if (!next.length) return;
    setSelectedCategories(next);
    if (query.trim().length >= 2) void runSearch(query, { categories: next });
  };

  const updateConfig = <K extends keyof SearchConfig>(key: K, value: SearchConfig[K], immediate = true) => {
    const next = { ...searchConfig, [key]: value };
    setSearchConfig(next);
    if (immediate && query.trim().length >= 2) void runSearch(query, { config: next });
  };

  const updateLimit = (category: Category, field: "enabled" | "value", value: boolean | number) => {
    const next = {
      ...searchConfig,
      resultLimits: {
        ...searchConfig.resultLimits,
        [category]: {
          ...searchConfig.resultLimits[category],
          [field]: value
        }
      }
    };
    setSearchConfig(next);
    if (query.trim().length >= 2) void runSearch(query, { config: next });
  };

  const selectSearchProvider = (provider: SearchProvider) => {
    setSearchProvider(provider);
    if (query.trim().length >= 2) void runSearch(query, { provider });
  };

  const runCauseAnalysis = async () => {
    const solutionDocs = results.solution.slice(0, 60);
    if (!solutionDocs.length) {
      showToast("Run a solution search before analyzing causes.", "warning");
      return;
    }
    try {
      const response = await api.analyzeCauses(solutionDocs, query);
      setCauseAnalysis(response.causes);
    } catch {
      setCauseAnalysis(distinctCauseSummaries(solutionDocs, 10));
    }
  };

  const generateCloseNotes = async (enhance: boolean) => {
    if (!bootstrap || !closeIssue.trim()) {
      showToast("Paste an issue description first.", "warning");
      return;
    }
    if (enhance && !aiReady) {
      showToast("Enhance requires an AI model and API key.", "warning");
      setAiSettingsOpen(true);
      return;
    }
    setCloseOutput("Preparing notes...");
    try {
      const response = await api.closeNotes(closeIssue, enhance, searchConfig, aiReady ? aiSettings : undefined);
      setCloseOutput(response.notes);
    } catch {
      if (enhance && aiReady && aiSettings.provider === "gemini") {
        const offlineResponse = offlineIndex.ready
          ? await searchOfflineWorker(closeIssue, ["solution"], searchConfig, 0.5)
          : runOfflineSearch(bootstrap, closeIssue, ["solution"], searchConfig, 0.5);
        const match = offlineResponse.results.solution[0];
        const payload = match?.payload as Solution | undefined;
        try {
          const gemini = await callBrowserGemini(
            aiSettings,
            "Rewrite IT support close notes into concise, professional, step-by-step ticket notes. Do not invent facts.",
            payload
              ? `New issue:\n${closeIssue}\n\nMatched internal solution:\nIssue: ${payload.issue}\nCause: ${payload.cause}\nResolution: ${payload.resolution}`
              : `New issue:\n${closeIssue}\n\nNo internal solution was found. Draft professional close notes that clearly say investigation is pending.`,
            false
          );
          setCloseOutput(
            payload
              ? `Issue: ${payload.issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution:\n${gemini.text.trim()}`
              : gemini.text.trim()
          );
          showToast("Used Gemini browser fallback because backend API is unavailable.", "warning");
          return;
        } catch (error) {
          showToast(error instanceof Error ? error.message : "Gemini request failed.", "error");
          setCloseOutput("");
          return;
        }
      }
      const notes = offlineIndex.ready
        ? await closeNotesOfflineWorker(closeIssue, searchConfig)
        : localCloseNotes(closeIssue, bootstrap, searchConfig);
      setCloseOutput(notes);
      showToast("Generated from offline cache.", "warning");
    }
  };

  const draftCommunication = async () => {
    if (!bootstrap || !comm.issue.trim()) {
      showToast("Issue description is required.", "warning");
      return;
    }
    setComm((current) => ({ ...current, output: "Drafting response..." }));
    try {
      const response = await api.draftEmail({ ...comm, config: searchConfig, ai: aiReady ? aiSettings : undefined });
      setComm((current) => ({ ...current, output: response.email }));
    } catch {
      const offlineResponse = offlineIndex.ready
        ? await searchOfflineWorker(comm.issue, ["solution"], searchConfig, 0.5)
        : runOfflineSearch(bootstrap, comm.issue, ["solution"], searchConfig, 0.5);
      const offline = offlineResponse.results.solution[0];
      const payload = offline?.payload as Solution | undefined;
      setComm((current) => ({
        ...current,
        output: payload
          ? `Hi ${comm.userName || "there"},\n\nThank you for contacting us about ticket ${
              comm.ticket || "N/A"
            }.\n\nRecommended resolution:\n${payload.resolution}\n\nLikely cause: ${
              payload.cause || "Not documented."
            }\n\nRegards,\nIT Support`
          : `Hi ${comm.userName || "there"},\n\nThank you for contacting us. We are reviewing ticket ${
              comm.ticket || "N/A"
            } and will continue investigating with the available details.\n\nRegards,\nIT Support`
      }));
    }
  };

  const copyText = async (text: string) => {
    await navigator.clipboard.writeText(text);
    showToast("Copied to clipboard.", "success");
  };

  const testAiConnection = async () => {
    if (!aiSettings.apiKey.trim()) {
      showToast("Paste your Gemini API key first.", "warning");
      return;
    }
    setAiTesting(true);
    try {
      await callBrowserGemini(
        { ...aiSettings, enabled: true, provider: "gemini" },
        "Reply with exactly: Gemini connection ready.",
        "Test the connection.",
        false
      );
      setAiSettings((current) => ({ ...current, enabled: true, provider: "gemini" }));
      showToast("Gemini key works. AI is enabled.", "success");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Gemini key test failed.", "error");
    } finally {
      setAiTesting(false);
    }
  };

  const sendChat = async (forcedText?: string) => {
    if (!bootstrap) return;
    const text = (forcedText || chatInput).trim();
    if (!text) return;
    setChatOpen(true);
    setChatInput("");
    setChatMessages((current) => [...current, { role: "user", text }]);
    setChatBusy(true);
    try {
      const response = await api.agent(text, searchConfig, aiReady ? aiSettings : undefined);
      setLastAgentText(response.text);
      setChatMessages((current) => [
        ...current,
        { role: "agent", text: response.text, sources: response.sources }
      ]);
    } catch {
      const local = offlineIndex.ready
        ? await searchOfflineWorker(text, categories, searchConfig, 0.5)
        : runOfflineSearch(bootstrap, text, categories, searchConfig, 0.5);
      const contextDocs = [...local.results.solution, ...local.results.kb, ...local.results.problem];
      const top = contextDocs[0];
      if (aiReady && aiSettings.provider === "gemini") {
        try {
          const gemini = await callBrowserGemini(
            aiSettings,
            contextDocs.length
              ? "You are an enterprise IT support assistant. Analyze the internal context first and provide clear actionable steps. Do not invent facts."
              : "You are an enterprise IT support assistant. No internal match was found. Provide safe general guidance and clearly mark it as external/general guidance.",
            `Internal context:\n${contextFromDocuments(contextDocs) || "No internal context found."}\n\nUser question: ${text}`,
            contextDocs.length === 0
          );
          setLastAgentText(gemini.text);
          setChatMessages((current) => [...current, { role: "agent", text: gemini.text, sources: gemini.sources }]);
          showToast("Used Gemini browser fallback because backend API is unavailable.", "warning");
          return;
        } catch (error) {
          showToast(error instanceof Error ? error.message : "Gemini request failed.", "error");
        }
      }
      const answer = top
        ? `Internal match: ${top.title}\n\n${top.description || top.content}\n\nAI backend is unavailable. If you pasted a Gemini key, use AI Models > Test Gemini Key, or start the backend on localhost:8080.`
        : "No strong offline match was found. Capture exact symptoms, timestamps, application version, screenshots, and route the case for specialist review.";
      setLastAgentText(answer);
      setChatMessages((current) => [...current, { role: "agent", text: answer }]);
    } finally {
      setChatBusy(false);
    }
  };

  const openGuide = async () => {
    if (!query.trim()) {
      showToast("Enter an issue in search first.", "warning");
      return;
    }
    if (!bootstrap) {
      showToast("Knowledge data is still loading.", "warning");
      return;
    }

    const issue = query.trim();
    const guideSearchConfig: SearchConfig = {
      ...searchConfig,
      resultLimits: {
        solution: { enabled: true, value: 60 },
        kb: { enabled: true, value: 20 },
        problem: { enabled: true, value: 20 }
      }
    };
    setGuideOpen(true);
    setGuideBusy(true);
    setGuidePlan(null);
    const enhanceWithAi = async (basePlan: GuidePlan) => {
      if (!online || !aiReady) return basePlan;
      const clusterEvidence = basePlan.steps.find((step) => step.title === "Compare against the best internal match")?.evidence;
      const needsWebSearch = basePlan.solutionCandidates === 0;
      const prompt = `Guide me step by step to fix: ${issue}

Return a manager-ready support playbook with:
1. First responder checks
2. User-actionable steps
3. Administrator checks
4. Validation criteria
5. Escalation package

Internal triage summary: ${basePlan.summary}
Route: ${basePlan.route}
Top distinct cause clusters:
${clusterEvidence || "No cause clusters available."}

Rules:
- Thoroughly analyze the internal solution candidates first.
- If internal solutions exist, use them as the primary source and do not use web information unless explicitly needed.
- If no internal solution was found, search the web for a safe general resolution path and clearly mark it as external guidance.
- If 50-60 solutions match, group them by cause and symptom pattern before recommending the fix.
- Do not invent system-specific facts.`;
      try {
        const response = await api.agent(prompt, guideSearchConfig, aiSettings, needsWebSearch);
        return { ...basePlan, aiAdvisory: response.text, sources: response.sources };
      } catch (error) {
        if (aiSettings.provider === "gemini") {
          try {
            const gemini = await callBrowserGemini(
              aiSettings,
              needsWebSearch
                ? "You are an enterprise IT support assistant. No internal solution was found. Use web-grounded general guidance and clearly mark external guidance."
                : "You are an enterprise IT support assistant. Analyze internal solution clusters first and produce a manager-ready support playbook. Do not invent facts.",
              prompt,
              needsWebSearch
            );
            showToast("Used Gemini browser fallback because backend API is unavailable.", "warning");
            return { ...basePlan, aiAdvisory: gemini.text, sources: gemini.sources };
          } catch (geminiError) {
            showToast(geminiError instanceof Error ? geminiError.message : "Gemini request failed.", "error");
          }
        } else if (error instanceof Error) {
          showToast(error.message, "warning");
        }
        return basePlan;
      }
    };

    try {
      if (searchProvider === "offline") {
        const response = offlineIndex.ready
          ? await searchOfflineWorker(issue, categories, guideSearchConfig, tierAccuracy)
          : runOfflineSearch(bootstrap, issue, categories, guideSearchConfig, tierAccuracy);
        setResults(response.results);
        setPrediction(response.prediction);
        setEngine(offlineIndex.ready ? "offline-worker-bm25" : response.engine);
        setGuidePlan(await enhanceWithAi(createGuidePlan(issue, response.results, response.prediction)));
        return;
      }
      const response = await api.search({
        query: issue,
        categories,
        config: guideSearchConfig,
        tierAccuracy,
        provider: searchProvider
      });
      setResults(response.results);
      setPrediction(response.prediction);
      setEngine(response.engine);
      setGuidePlan(await enhanceWithAi(createGuidePlan(issue, response.results, response.prediction)));
    } catch {
      const response = offlineIndex.ready
        ? await searchOfflineWorker(issue, categories, guideSearchConfig, tierAccuracy)
        : runOfflineSearch(bootstrap, issue, categories, guideSearchConfig, tierAccuracy);
      setResults(response.results);
      setPrediction(response.prediction);
      setEngine(response.engine);
      setGuidePlan(await enhanceWithAi(createGuidePlan(issue, response.results, response.prediction)));
      showToast(offlineIndex.ready ? "Guide used worker offline index." : "Guide used local offline index.", "warning");
    } finally {
      setGuideBusy(false);
    }
  };

  const parseForCuration = async () => {
    if (!lastAgentText) {
      showToast("Ask the agent first, then curate the answer.", "warning");
      return;
    }
    setCurationOpen(true);
    try {
      const parsed = await api.parseCuration(lastAgentText, aiReady ? aiSettings : undefined);
      setCurationForm({
        issue: parsed.issue || "",
        cause: parsed.cause || "",
        resolution: parsed.resolution || lastAgentText,
        tier1: "",
        tier2: "",
        tier3: "",
        keywords: (parsed.keywords || []).join(", ")
      });
    } catch {
      const keywords = [...new Set(lastAgentText.toLowerCase().match(/[a-z0-9]{4,}/g) || [])].slice(0, 12);
      setCurationForm({
        issue: lastAgentText.split("\n")[0] || "Curated support issue",
        cause: "",
        resolution: lastAgentText,
        tier1: "",
        tier2: "",
        tier3: "",
        keywords: keywords.join(", ")
      });
    }
  };

  const saveCuration = async () => {
    if (!bootstrap || !curationForm.issue.trim() || !curationForm.resolution.trim()) {
      showToast("Issue and resolution are required.", "warning");
      return;
    }
    const payload = {
      ...curationForm,
      keywords: curationForm.keywords.split(",").map((item) => item.trim()).filter(Boolean)
    };
    try {
      const saved = (await api.addCuratedSolution(payload)) as Solution;
      addLocalSolution(saved);
      showToast("Curated solution saved.", "success");
    } catch {
      const local: Solution = {
        id: `curated_${Date.now()}`,
        tier: "Curated",
        tier1: payload.tier1,
        tier2: payload.tier2,
        tier3: payload.tier3,
        issue: payload.issue,
        cause: payload.cause,
        resolution: payload.resolution,
        keywords: payload.keywords
      };
      addLocalSolution(local);
      showToast("Saved to offline cache.", "warning");
    }
    setCurationOpen(false);
  };

  const importOfflineDatabase = async (file: File) => {
    setImporting(true);
    setResults(emptyResults);
    setPrediction(null);
    setEngine("idle");
    try {
      const payload = await parseKnowledgeFile(file);
      await activateBootstrap(payload, `Imported ${payload.stats.solutions} solutions, ${payload.stats.kbArticles} KBs, ${payload.stats.problems} problems.`);
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Unable to import offline database.", "error");
    } finally {
      setImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const saveKeywords = async () => {
    if (!activeDoc) return;
    const keywords = keywordDraft.split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
    try {
      await api.updateKeywords(activeDoc.type, activeDoc.id, keywords);
      showToast("Keywords saved.", "success");
    } catch {
      showToast("Keywords saved in offline cache.", "warning");
    }
    updateLocalItem(activeDoc.type, activeDoc.id, { keywords });
    setActiveDoc((current) => (current ? { ...current, keywords, payload: { ...current.payload, keywords } } : current));
  };

  const saveLink = async () => {
    if (!activeDoc || !linkDraft.trim()) return;
    try {
      await api.updateLink(activeDoc.type, activeDoc.id, linkDraft.trim());
      showToast("Reference link saved.", "success");
    } catch {
      showToast("Reference link saved in offline cache.", "warning");
    }
    updateLocalItem(activeDoc.type, activeDoc.id, { link: linkDraft.trim() });
    setActiveDoc((current) =>
      current ? { ...current, payload: { ...current.payload, link: linkDraft.trim() } } : current
    );
  };

  const updateLocalItem = (type: Category, id: string, updates: Record<string, unknown>) => {
    setBootstrap((current) => {
      if (!current) return current;
      const next = structuredClone(current) as BootstrapPayload;
      const list =
        type === "solution" ? next.solutions : type === "kb" ? next.kbArticles : next.problems;
      const item = list.find((entry) => entry.id === id);
      if (item) Object.assign(item, updates);
      void cacheBootstrap(next);
      return next;
    });
  };

  const addLocalSolution = (solution: Solution) => {
    setBootstrap((current) => {
      if (!current) return current;
      const next = structuredClone(current) as BootstrapPayload;
      const exists = next.solutions.some((item) => item.id === solution.id);
      if (!exists) {
        next.solutions.unshift(solution);
        next.curated.unshift(solution);
        next.stats.solutions += 1;
      }
      void cacheBootstrap(next);
      void loadOfflineSearch(next).then((indexed) =>
        setOfflineIndex({ ready: true, busy: false, documents: indexed.documents, vocabulary: indexed.vocabulary })
      );
      return next;
    });
  };

  const exportData = (type: "solutions" | "kb" | "problem" | "curated") => {
    if (!bootstrap) return;
    if (online) {
      window.open(api.exportUrl(type), "_blank");
      return;
    }
    const payload =
      type === "solutions"
        ? bootstrap.solutions
        : type === "kb"
          ? bootstrap.kbArticles
          : type === "problem"
            ? bootstrap.problems
            : bootstrap.curated;
    downloadJson(`${type}.json`, payload);
  };

  const reindex = async () => {
    try {
      const response = await api.reindex();
      showToast(response.ok ? "Search index refreshed." : "Meilisearch is not reachable.", response.ok ? "success" : "warning");
      void loadBootstrap();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Reindex failed.", "error");
    }
  };

  const detailPayload = activeDoc?.payload;

  return (
    <div className="app-bg min-h-screen">
      <div className="mx-auto max-w-[1800px] px-4 py-5 sm:px-6 lg:px-8">
        <header className="mb-5 flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 border border-line bg-black/20 px-3 py-2 text-xs font-bold uppercase tracking-[0.2em] text-signal">
              <ShieldCheck size={15} />
              Enterprise Support Console
            </div>
            <h1 className="font-mono text-4xl font-extrabold tracking-normal text-zinc-50 sm:text-5xl">
              Quantum Resolve
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-zinc-400">
              Search, triage, predict, draft, curate, and export from one offline-ready workspace.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusPill online={online} services={services} />
            <button className="icon-button" onClick={() => setSettingsOpen(true)} title="Settings">
              <Settings size={18} />
            </button>
            <ThemeToggle theme={theme} setTheme={setTheme} />
          </div>
        </header>

        <section className="mb-5 grid gap-3 md:grid-cols-3">
          <MetricCard icon={Database} label="Solutions" value={bootstrap?.stats.solutions || 0} tone="signal" />
          <MetricCard icon={Sparkles} label="KB Articles" value={bootstrap?.stats.kbArticles || 0} tone="ember" />
          <MetricCard icon={Target} label="Problem IDs" value={bootstrap?.stats.problems || 0} tone="grove" />
        </section>

        <section className="panel mb-5 flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <div className="text-sm font-bold text-zinc-100">Enterprise Offline Database</div>
            <div className="mt-1 text-xs leading-5 text-zinc-500">
              {loadedRecords.toLocaleString()} loaded records ·{" "}
              {offlineIndex.busy
                ? "building worker index"
                : offlineIndex.ready
                  ? `${offlineIndex.documents.toLocaleString()} worker-indexed docs`
                  : "fallback in-memory search"}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileInputRef}
              className="hidden"
              type="file"
              accept=".json,.jsonl,application/json"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void importOfflineDatabase(file);
              }}
            />
            <button className="button-secondary px-4" onClick={() => fileInputRef.current?.click()} disabled={importing}>
              <Upload className="mr-2 inline" size={16} />
              {importing ? "Importing" : "Import JSON/JSONL"}
            </button>
            <button
              className="button-muted px-4"
              onClick={() => bootstrap && downloadJson("offline-snapshot.json", bootstrap)}
              disabled={!bootstrap}
            >
              <Download className="mr-2 inline" size={16} />
              Snapshot
            </button>
          </div>
        </section>

        <section className="mb-5 grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="panel aurora-panel p-4">
            <div className="mb-4 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-zinc-100">Enterprise Search Fabric</div>
                <div className="mt-1 text-xs text-zinc-500">Choose the search engine pattern for the backend; offline mode keeps working without a server.</div>
              </div>
              <Cpu className="text-signal" size={22} />
            </div>
            <div className="grid gap-2 md:grid-cols-5">
              {searchProviders.map((provider) => (
                <button
                  key={provider.id}
                  className={`search-provider-card ${searchProvider === provider.id ? "is-active" : ""}`}
                  onClick={() => selectSearchProvider(provider.id)}
                  title={provider.detail}
                >
                  <span className="text-xs font-black uppercase tracking-[0.14em]">{provider.name}</span>
                  <span className="mt-2 block text-[11px] leading-4 text-zinc-500">{provider.detail}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="panel aurora-panel p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-bold text-zinc-100">AI Model Gateway</div>
                <div className="mt-1 text-xs text-zinc-500">
                  {aiReady ? `${aiSettings.provider} · ${activeAiModel?.label || aiSettings.model}` : "Session key required for model reasoning"}
                </div>
              </div>
              <button className="button-primary px-4" onClick={() => setAiSettingsOpen(true)}>
                <KeyRound className="mr-2 inline" size={16} />
                AI Models
              </button>
            </div>
            <div className="grid gap-2 sm:grid-cols-3">
              <div className="mini-stat">
                <span>Mode</span>
                <strong>{aiReady ? "AI Ready" : "Offline"}</strong>
              </div>
              <div className="mini-stat">
                <span>Grounding</span>
                <strong>{aiSettings.grounding ? "On" : "Off"}</strong>
              </div>
              <div className="mini-stat">
                <span>Temperature</span>
                <strong>{aiSettings.temperature.toFixed(1)}</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="panel mb-5 p-4">
          <div className="grid gap-3 xl:grid-cols-[1fr_auto_auto_auto_auto]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
              <input
                className="field min-h-[52px] pl-11 text-base"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") void runSearch();
                }}
                placeholder="Search issues, KBs, Problem IDs, symptoms, or tiers"
              />
            </div>
            <button className="button-primary px-5" onClick={() => void runSearch()} disabled={loading}>
              {loading ? "Searching" : "Search"}
            </button>
            <button className="button-secondary px-4" onClick={() => void runCauseAnalysis()} title="Analyze common causes">
              <Brain className="mr-2 inline" size={17} />
              Causes
            </button>
            <button className="button-secondary border-signal/40 bg-signal/10 px-4" onClick={() => void openGuide()} title="Open guided resolution">
              <ListChecks className="mr-2 inline" size={17} />
              Guide
            </button>
            <button
              className="button-secondary px-4"
              onClick={() => {
                setChatOpen(true);
                if (!chatMessages.length) {
                  setChatMessages([{ role: "agent", text: "How can I help with this ticket?" }]);
                }
              }}
              title="Ask conversational assistant"
            >
              <Sparkles className="mr-2 inline" size={17} />
              Ask
            </button>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            {categories.map((category) => (
              <label key={category} className="chip cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedCategories.includes(category)}
                  onChange={() => toggleCategory(category)}
                />
                {category === "solution" ? "Solutions" : category === "kb" ? "KB Articles" : "Problem IDs"}
              </label>
            ))}
            <button className="button-muted ml-auto px-3" onClick={() => setAdvancedOpen((value) => !value)}>
              <SlidersHorizontal className="mr-2 inline" size={17} />
              Controls
            </button>
          </div>
        </section>

        {advancedOpen && (
          <section className="panel mb-5 p-4">
            <div className="grid gap-4 lg:grid-cols-3">
              <Slider label="Typo Tolerance" value={searchConfig.fuzzySensitivity} onChange={(value) => updateConfig("fuzzySensitivity", value)} />
              <Slider label="Score Threshold" value={searchConfig.scoreThreshold} onChange={(value) => updateConfig("scoreThreshold", value)} />
              <Slider label="Tier Accuracy" value={Math.round(tierAccuracy * 100)} onChange={(value) => setTierAccuracy(value / 100)} />
              <Weight label="Title Weight" value={searchConfig.titleWeight} onChange={(value) => updateConfig("titleWeight", value)} />
              <Weight label="Description Weight" value={searchConfig.descriptionWeight} onChange={(value) => updateConfig("descriptionWeight", value)} />
              <Weight label="Content Weight" value={searchConfig.contentWeight} onChange={(value) => updateConfig("contentWeight", value)} />
            </div>
            <div className="mt-5 grid gap-4 lg:grid-cols-3">
              <div>
                <div className="label">Search Mode</div>
                <div className="flex flex-wrap gap-2">
                  {(["any", "all", "exact"] as const).map((mode) => (
                    <label key={mode} className="chip cursor-pointer">
                      <input
                        type="radio"
                        name="mode"
                        checked={searchConfig.searchMode === mode}
                        onChange={() => updateConfig("searchMode", mode)}
                      />
                      {mode}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Intelligence</div>
                <div className="flex flex-wrap gap-2">
                  {([
                    ["stemming", "Stemming"],
                    ["phonetic", "Phonetic"],
                    ["synonyms", "Synonyms"],
                    ["typoTolerance", "Typos"],
                    ["acronyms", "Acronyms"]
                  ] as [keyof SearchConfig, string][]).map(([key, label]) => (
                    <label key={String(key)} className="chip cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(searchConfig[key])}
                        onChange={(event) => updateConfig(key, event.target.checked as never)}
                      />
                      {label}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <div className="label">Result Limits</div>
                <div className="grid gap-2 sm:grid-cols-3">
                  {categories.map((category) => (
                    <label key={category} className="chip">
                      <input
                        type="checkbox"
                        checked={searchConfig.resultLimits[category].enabled}
                        onChange={(event) => updateLimit(category, "enabled", event.target.checked)}
                      />
                      <input
                        className="w-14 bg-transparent font-mono outline-none"
                        type="number"
                        min={1}
                        max={200}
                        value={searchConfig.resultLimits[category].value}
                        onChange={(event) => updateLimit(category, "value", Number(event.target.value))}
                      />
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {(prediction || engine !== "idle") && (
          <section className="panel mb-5 grid gap-3 p-4 md:grid-cols-5">
            <div>
              <div className="label">Engine</div>
              <div className="font-mono text-sm text-signal">{engine}</div>
            </div>
            {(["category", "tier1", "tier2", "tier3"] as const).map((field) => (
              <div key={field}>
                <div className="label">{field === "category" ? "Category" : field.toUpperCase()}</div>
                <div className="text-sm font-semibold text-zinc-100">{prediction?.[field] || "--None--"}</div>
              </div>
            ))}
          </section>
        )}

        {causeAnalysis.length > 0 && (
          <section className="panel mb-5 p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-pollen">
              <Brain size={18} />
              Top Distinct Causes
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              {causeAnalysis.map((item) => (
                <div key={item.cause} className="border border-line bg-white/[0.04] p-3">
                  <div className="mb-2 font-mono text-xs text-zinc-500">{item.count} match{item.count === 1 ? "" : "es"}</div>
                  <p className="text-sm leading-6 text-zinc-200">{item.cause}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        <main className="mb-5 grid gap-4 xl:grid-cols-3">
          <ResultColumn type="solution" results={results.solution} onSelect={setActiveDoc} />
          <ResultColumn type="kb" results={results.kb} onSelect={setActiveDoc} />
          <ResultColumn type="problem" results={results.problem} onSelect={setActiveDoc} />
        </main>

        <section className="mb-5 grid gap-4 xl:grid-cols-2">
          <CloseNotesGenerator
            closeIssue={closeIssue}
            setCloseIssue={setCloseIssue}
            closeOutput={closeOutput}
            aiReady={aiReady}
            generateCloseNotes={(enhance) => void generateCloseNotes(enhance)}
            copyText={(text) => void copyText(text)}
          />
          <CommunicationDraftPanel
            comm={comm}
            setComm={setComm}
            draftCommunication={() => void draftCommunication()}
            copyText={(text) => void copyText(text)}
          />
        </section>

        <section className="panel mb-5 flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <div className="text-sm font-bold text-grove">Data Exporter</div>
            <div className="text-xs text-zinc-500">{totalResults} visible matches in this session</div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="button-muted px-3" onClick={() => exportData("solutions")}>
              <Download className="mr-2 inline" size={16} />
              Solutions
            </button>
            <button className="button-muted px-3" onClick={() => exportData("kb")}>
              <Download className="mr-2 inline" size={16} />
              KB
            </button>
            <button className="button-muted px-3" onClick={() => exportData("problem")}>
              <Download className="mr-2 inline" size={16} />
              Problems
            </button>
            <button className="button-muted px-3" onClick={() => exportData("curated")}>
              <Download className="mr-2 inline" size={16} />
              Curated
            </button>
          </div>
        </section>
      </div>

      <Modal open={Boolean(activeDoc)} title="Knowledge Details" onClose={() => setActiveDoc(null)} wide>
        {activeDoc && detailPayload && (
          <Details
            document={activeDoc}
            payload={detailPayload}
            keywordDraft={keywordDraft}
            setKeywordDraft={setKeywordDraft}
            linkDraft={linkDraft}
            setLinkDraft={setLinkDraft}
            saveKeywords={saveKeywords}
            saveLink={saveLink}
          />
        )}
      </Modal>

      <Modal open={guideOpen} title="Guided Resolution" onClose={() => setGuideOpen(false)} wide>
        <GuideWorkspace
          busy={guideBusy}
          plan={guidePlan}
          copyClosure={() => guidePlan && void copyText(guidePlan.closure)}
          askFollowUp={() => {
            if (!guidePlan) return;
            setChatOpen(true);
            setChatInput(`Question about guided resolution for: ${guidePlan.issue}\n\n`);
          }}
        />
      </Modal>

      <Modal open={chatOpen} title="Ask Assistant" onClose={() => setChatOpen(false)} wide>
        <div className="flex max-h-[68vh] min-h-[420px] flex-col">
          <div className="flex-1 space-y-3 overflow-y-auto pr-1">
            {chatMessages.map((message, index) => (
              <div key={`${message.role}-${index}`} className={`max-w-[88%] border border-line p-3 ${message.role === "user" ? "ml-auto bg-signal/10" : "bg-white/[0.04]"}`}>
                <div className="whitespace-pre-wrap text-sm leading-6 text-zinc-100">{message.text}</div>
                {message.sources?.length ? (
                  <div className="mt-3 space-y-1">
                    {message.sources.map((source) => (
                      <a key={source.uri} className="block text-xs text-signal underline" href={source.uri} target="_blank" rel="noreferrer">
                        {source.title}
                      </a>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}
            {chatBusy && <div className="text-sm text-zinc-500">Thinking...</div>}
          </div>
          <div className="mt-4 flex gap-2">
            <textarea
              className="field min-h-[52px] flex-1"
              value={chatInput}
              onChange={(event) => setChatInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void sendChat();
                }
              }}
            />
            <button className="button-primary px-4" onClick={() => void sendChat()} disabled={chatBusy}>
              <Send size={18} />
            </button>
          </div>
          <button className="button-secondary mt-3 px-4" onClick={() => void parseForCuration()} disabled={!lastAgentText}>
            <Save className="mr-2 inline" size={16} />
            Curate to KB
          </button>
        </div>
      </Modal>

      <Modal open={curationOpen} title="Curate New Knowledge" onClose={() => setCurationOpen(false)}>
        <div className="space-y-3">
          <Input label="Issue" value={curationForm.issue} onChange={(issue) => setCurationForm((current) => ({ ...current, issue }))} />
          <TextArea label="Cause" value={curationForm.cause} onChange={(cause) => setCurationForm((current) => ({ ...current, cause }))} />
          <TextArea label="Resolution" value={curationForm.resolution} onChange={(resolution) => setCurationForm((current) => ({ ...current, resolution }))} rows={7} />
          <div className="grid gap-3 md:grid-cols-3">
            <Input label="Tier 1" value={curationForm.tier1} onChange={(tier1) => setCurationForm((current) => ({ ...current, tier1 }))} />
            <Input label="Tier 2" value={curationForm.tier2} onChange={(tier2) => setCurationForm((current) => ({ ...current, tier2 }))} />
            <Input label="Tier 3" value={curationForm.tier3} onChange={(tier3) => setCurationForm((current) => ({ ...current, tier3 }))} />
          </div>
          <Input label="Keywords" value={curationForm.keywords} onChange={(keywords) => setCurationForm((current) => ({ ...current, keywords }))} />
          <button className="button-primary w-full px-4" onClick={() => void saveCuration()}>
            Save Solution
          </button>
        </div>
      </Modal>

      <Modal open={aiSettingsOpen} title="AI Model Gateway" onClose={() => setAiSettingsOpen(false)} wide>
        <AiModelSettings
          settings={aiSettings}
          setSettings={setAiSettings}
          models={aiModels}
          ready={aiReady}
          testing={aiTesting}
          testConnection={() => void testAiConnection()}
        />
      </Modal>

      <Modal open={settingsOpen} title="System Settings" onClose={() => setSettingsOpen(false)}>
        <SystemSettings
          apiBase={api.baseUrl}
          services={services}
          refreshSnapshot={() => void loadBootstrap()}
          reindex={() => void reindex()}
        />
      </Modal>

      {toast && <div className={`toast border-${toast.tone}`}>{toast.message}</div>}
    </div>
  );
}

function Details({
  document,
  payload,
  keywordDraft,
  setKeywordDraft,
  linkDraft,
  setLinkDraft,
  saveKeywords,
  saveLink
}: {
  document: SearchDocument;
  payload: Solution | KbArticle | ProblemRecord;
  keywordDraft: string;
  setKeywordDraft: (value: string) => void;
  linkDraft: string;
  setLinkDraft: (value: string) => void;
  saveKeywords: () => void;
  saveLink: () => void;
}) {
  return (
    <div className="space-y-4">
      {document.type === "solution" && (
        <>
          <TierGrid payload={payload as Solution} />
          <ReadBlock title="Issue" text={(payload as Solution).issue} />
          <ReadBlock title="Cause" text={(payload as Solution).cause} />
          <ReadBlock title="Resolution" text={(payload as Solution).resolution} />
        </>
      )}
      {document.type === "kb" && (
        <>
          <ReadBlock title="Number" text={(payload as KbArticle).number} />
          <ReadBlock title="Title" text={(payload as KbArticle).title} />
        </>
      )}
      {document.type === "problem" && (
        <>
          <TierTags payload={payload as ProblemRecord} />
          <ReadBlock title="Title" text={(payload as ProblemRecord).title} />
          <LinkBlock title="EIT Release Notes" href={(payload as ProblemRecord).eitLink} />
          <LinkBlock title="Problem Ticket" href={(payload as ProblemRecord).problemLink} />
          <LinkBlock title="FD-TD" href={(payload as ProblemRecord).fdtdLink} />
        </>
      )}
      <div className="grid gap-3 md:grid-cols-[1fr_auto]">
        <div>
          <label className="label">Reference Link</label>
          <input className="field" value={linkDraft} onChange={(event) => setLinkDraft(event.target.value)} placeholder="https://..." />
        </div>
        <button className="button-secondary self-end px-4" onClick={saveLink}>
          Save Link
        </button>
      </div>
      <div className="grid gap-3 md:grid-cols-[1fr_auto]">
        <div>
          <label className="label">Keywords</label>
          <textarea className="field min-h-[92px]" value={keywordDraft} onChange={(event) => setKeywordDraft(event.target.value)} />
        </div>
        <button className="button-primary self-end px-4" onClick={saveKeywords}>
          Save Keywords
        </button>
      </div>
    </div>
  );
}

function TierGrid({ payload }: { payload: Solution }) {
  return (
    <div className="grid gap-3 md:grid-cols-4">
      {[
        ["Tier", payload.tier],
        ["Tier 1", payload.tier1],
        ["Tier 2", payload.tier2],
        ["Tier 3", payload.tier3]
      ].map(([label, value]) => (
        <div key={label} className="border border-line bg-white/[0.04] p-3">
          <div className="label">{label}</div>
          <div className="text-sm font-semibold text-zinc-100">{value || "N/A"}</div>
        </div>
      ))}
    </div>
  );
}

function TierTags({ payload }: { payload: ProblemRecord }) {
  return (
    <div className="flex flex-wrap gap-2">
      {[payload.application, payload.problemId, payload.eit, payload.deliveryId, payload.status].filter(Boolean).map((item) => (
        <span key={item} className="chip">
          {item}
        </span>
      ))}
    </div>
  );
}

function ReadBlock({ title, text }: { title: string; text?: string }) {
  return (
    <div>
      <div className="label">{title}</div>
      <div className="whitespace-pre-wrap border border-line bg-white/[0.04] p-3 text-sm leading-6 text-zinc-200">
        {text || "Not available"}
      </div>
    </div>
  );
}

function LinkBlock({ title, href }: { title: string; href?: string }) {
  return (
    <div>
      <div className="label">{title}</div>
      {href && href !== "#" ? (
        <a className="break-all text-sm text-signal underline" href={href} target="_blank" rel="noreferrer">
          {href}
        </a>
      ) : (
        <div className="text-sm text-zinc-500">Not available</div>
      )}
    </div>
  );
}
