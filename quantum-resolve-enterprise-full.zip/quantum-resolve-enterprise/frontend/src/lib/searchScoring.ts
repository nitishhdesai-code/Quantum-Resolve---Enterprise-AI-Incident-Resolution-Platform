import type { SearchConfig } from "../types";

export function normalizedScore(rawScore: number, keywordCount: number, config: SearchConfig) {
  const weightedFieldCapacity = Math.max(1, keywordCount * (config.titleWeight + config.descriptionWeight + config.contentWeight));
  return Math.min(100, (rawScore / weightedFieldCapacity) * 100);
}

export function scorePassesThreshold(rawScore: number, keywordCount: number, config: SearchConfig) {
  if (rawScore <= 0) return false;
  return normalizedScore(rawScore, keywordCount, config) >= config.scoreThreshold;
}
