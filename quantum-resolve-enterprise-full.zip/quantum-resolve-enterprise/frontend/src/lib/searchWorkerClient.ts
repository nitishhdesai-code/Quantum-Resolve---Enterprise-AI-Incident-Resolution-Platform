import type { BootstrapPayload, Category, SearchConfig, SearchResponse } from "../types";

type PendingRequest = {
  resolve: (value: unknown) => void;
  reject: (reason?: unknown) => void;
};

let worker: Worker | null = null;
let nextId = 1;
const pending = new Map<number, PendingRequest>();

export function loadOfflineSearch(payload: BootstrapPayload) {
  return request<{ documents: number; vocabulary: number; stats: BootstrapPayload["stats"] }>("load", payload);
}

export function searchOfflineWorker(
  query: string,
  categories: Category[],
  config: SearchConfig,
  tierAccuracy: number
) {
  return request<SearchResponse>("search", { query, categories, config, tierAccuracy });
}

export function closeNotesOfflineWorker(issue: string, config: SearchConfig) {
  return request<string>("closeNotes", { issue, config });
}

function getWorker() {
  if (worker) return worker;
  worker = new Worker(new URL("../workers/offline-search.worker.ts", import.meta.url), {
    type: "module"
  });
  worker.onmessage = (event: MessageEvent<{ id: number; ok: boolean; payload?: unknown; error?: string }>) => {
    const requestState = pending.get(event.data.id);
    if (!requestState) return;
    pending.delete(event.data.id);
    if (event.data.ok) requestState.resolve(event.data.payload);
    else requestState.reject(new Error(event.data.error || "Offline worker failed"));
  };
  worker.onerror = (event) => {
    for (const [, requestState] of pending) {
      requestState.reject(new Error(event.message || "Offline worker crashed"));
    }
    pending.clear();
    worker?.terminate();
    worker = null;
  };
  return worker;
}

function request<T>(type: string, payload: unknown) {
  const id = nextId;
  nextId += 1;

  return new Promise<T>((resolve, reject) => {
    pending.set(id, { resolve: resolve as (value: unknown) => void, reject });
    getWorker().postMessage({ id, type, payload });
  });
}

