import type { AiSettings, BootstrapPayload, Category, SearchConfig, SearchDocument, SearchProvider, SearchResponse } from "../types";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {})
    }
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `Request failed with ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export const api = {
  baseUrl: API_BASE,
  bootstrap: () => request<BootstrapPayload>("/api/bootstrap"),
  health: () =>
    request<{
      ok: boolean;
      services: { api: boolean; database: boolean; meilisearch: boolean; opensearch?: boolean; elasticsearch?: boolean; solr?: boolean; ai: boolean };
    }>("/api/health"),
  search: (body: {
    query: string;
    categories: Category[];
    config: SearchConfig;
    tierAccuracy: number;
    provider?: SearchProvider;
  }) =>
    request<SearchResponse>("/api/search", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  updateKeywords: (type: Category, id: string, keywords: string[]) =>
    request(`/api/items/${type}/${id}/keywords`, {
      method: "PATCH",
      body: JSON.stringify({ keywords })
    }),
  updateLink: (type: Category, id: string, link: string) =>
    request(`/api/items/${type}/${id}/link`, {
      method: "PATCH",
      body: JSON.stringify({ link })
    }),
  addCuratedSolution: (body: {
    issue: string;
    cause: string;
    resolution: string;
    tier1: string;
    tier2: string;
    tier3: string;
    keywords: string[];
    link?: string;
  }) =>
    request("/api/solutions/curated", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  parseCuration: (text: string, ai?: AiSettings) =>
    request<{ issue?: string; cause?: string; resolution?: string; keywords?: string[] }>("/api/curation/parse", {
      method: "POST",
      body: JSON.stringify({ text, ai })
    }),
  closeNotes: (issue: string, enhance: boolean, config: SearchConfig, ai?: AiSettings) =>
    request<{ notes: string; match?: SearchDocument }>("/api/close-notes", {
      method: "POST",
      body: JSON.stringify({ issue, enhance, config, ai })
    }),
  analyzeCauses: (documents: SearchDocument[], query: string) =>
    request<{ causes: { cause: string; count: number }[] }>("/api/analyze-causes", {
      method: "POST",
      body: JSON.stringify({ documents, query })
    }),
  draftEmail: (body: {
    ticket: string;
    userName: string;
    userEmail: string;
    priority: string;
    issue: string;
    config: SearchConfig;
    ai?: AiSettings;
  }) =>
    request<{ email: string; match?: SearchDocument }>("/api/draft-email", {
      method: "POST",
      body: JSON.stringify(body)
    }),
  agent: (query: string, config: SearchConfig, ai?: AiSettings, webSearch = true) =>
    request<{ text: string; sources: { uri: string; title: string }[]; context: SearchDocument[] }>("/api/agent", {
      method: "POST",
      body: JSON.stringify({ query, config, ai, webSearch })
    }),
  reindex: () =>
    request<{ ok: boolean }>("/api/reindex", {
      method: "POST"
    }),
  exportUrl: (type: "solutions" | "kb" | "problem" | "curated") => `${API_BASE}/api/export/${type}`
};
