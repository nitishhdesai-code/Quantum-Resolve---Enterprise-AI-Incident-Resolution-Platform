import type { BootstrapPayload } from "../types";

export const fallbackBootstrap: BootstrapPayload = {
  solutions: [
    {
      id: "sol_001",
      tier: "User Related",
      tier1: "Performance",
      tier2: "Slowness",
      tier3: "Internet",
      issue: "Slowness in TC and NX. User is unable to rotate the model and changes take too long to save.",
      cause: "Internet connectivity issue on the user's current network.",
      resolution:
        "Ask the user to test from a mobile hotspot or stable alternate network. If performance improves, advise the user to work with the network team or continue from the stable connection until the primary network is corrected.",
      keywords: ["slowness", "tc", "teamcenter", "nx", "rotate", "model", "changes", "save", "internet", "hotspot", "mobile"]
    },
    {
      id: "sol_002",
      tier: "System Related",
      tier1: "Performance",
      tier2: "Client Side",
      tier3: "--None--",
      issue: "Teamcenter Rich Client (RAC) is very slow during startup and general navigation.",
      cause: "Possible network latency between client and server, insufficient RAM, or full/corrupted FMS cache.",
      resolution:
        "1. Check network latency and escalate if latency is high.\n2. Confirm the workstation has at least 16 GB RAM.\n3. Close Teamcenter and clear the FMS/FCC cache from the user profile.\n4. Restart the client and validate navigation speed.",
      keywords: ["slow", "performance", "rich", "client", "rac", "latency", "network", "ram", "cache", "fms", "fcc", "startup", "navigation", "lag", "freeze"]
    },
    {
      id: "sol_003",
      tier: "Admin Related",
      tier1: "User Requirement",
      tier2: "Unrelease of Object",
      tier3: "Remove Non Inventory Status",
      issue: "Remove non-inventory flag from the item.",
      cause: "The user did not have access to remove the non-inventory flag.",
      resolution:
        "Validate the request, confirm the impacted item, remove the non-inventory flag with admin access, and ask the user to verify the item status.",
      keywords: ["access", "release", "unrelease", "remove", "non inventory", "flag", "admin", "user requirement"]
    }
  ],
  kbArticles: [
    {
      id: "kb_001",
      number: "KB0011234",
      title: "Troubleshooting common performance and slowness issues in Teamcenter Rich Client",
      keywords: ["performance", "slowness", "troubleshooting", "rac", "rich", "client", "guide", "common"]
    },
    {
      id: "kb_002",
      number: "KB0011235",
      title: "How to clear the FMS Client Cache (FCC) to resolve data loading errors",
      keywords: ["fms", "cache", "clear", "fcc", "data", "loading", "error", "resolve"]
    }
  ],
  problems: [
    {
      id: "prb_001",
      problemId: "PRB0066831",
      keywords: ["data sync", "pdf", "change reference", "eco", "item", "skip"],
      application: "Teamcenter",
      eit: "EIT 17.11",
      deliveryId: "10466",
      status: "Deliverable Implemented",
      title: "Data Sync operation skipping the PDF file under Change References of ECO item",
      eitLink: "https://team.amat.com/sites/wiki/Pages/EIT/EIT%2017.11%20Teamcenter%20Release%20Notes.aspx",
      problemLink: "https://now.com/nav/ui/classic/params/target/problem.do%3Fsysparm_query%3Dnumber%3DPRB0058656"
    },
    {
      id: "prb_002",
      problemId: "PR-015039232",
      keywords: ["import", "015039232", "attachment", "resolve"],
      application: "NX",
      eit: "EIT 16.0",
      deliveryId: "9875",
      status: "Work In Progress",
      title: "Unable to import part file, please resolve, refer attachment.",
      eitLink: "#",
      problemLink: "#"
    }
  ],
  tiers: [
    { category: "Training related", tier1: "AMAT Custom", tier2: "Teamcenter", tier3: "MLO Attribute Related" },
    { category: "User related", tier1: "AMAT Custom", tier2: "Teamcenter", tier3: "Organization Related" },
    { category: "Training related", tier1: "AMAT Custom", tier2: "DQT", tier3: "NX Drafting Tool Related" },
    { category: "Training related", tier1: "AMAT Custom", tier2: "Teamcenter", tier3: "Basic Training for Teamcenter" },
    { category: "Training related", tier1: "AMAT Custom", tier2: "ECO", tier3: "How to cancel a Teamcenter ECO?" },
    { category: "Training related", tier1: "AMAT Custom", tier2: "Workflow", tier3: "Peer Review Workflow Procedure" }
  ],
  curated: [],
  stats: { solutions: 3, kbArticles: 2, problems: 2 },
  dictionaries: {
    stopWords: ["a", "an", "and", "the", "is", "it", "in", "on", "for", "with", "to", "of", "how", "issue", "problem", "error", "unable", "please"],
    synonymMap: {
      slow: ["sluggish", "lag", "delay", "hang", "freeze", "unresponsive", "slowness"],
      performance: ["speed", "efficiency", "optimization", "throughput", "responsiveness"],
      error: ["issue", "problem", "bug", "fault", "failure", "exception"],
      fix: ["resolve", "repair", "correct", "solve", "remedy", "address"],
      remove: ["uninstall", "delete", "eliminate", "purge"],
      network: ["connection", "internet", "connectivity", "link"],
      cache: ["buffer", "temporary", "temp", "staging"],
      teamcenter: ["tc", "plm", "pdm"],
      nx: ["unigraphics", "ug", "cad"]
    },
    acronymMap: {
      tc: ["teamcenter"],
      nx: ["unigraphics", "cad"],
      fms: ["file management system", "fms cache"],
      fcc: ["fms client cache"],
      kb: ["knowledge base"],
      eco: ["engineering change order"],
      rac: ["rich client", "teamcenter rich client"]
    }
  },
  defaultSearchConfig: {
    fuzzySensitivity: 60,
    scoreThreshold: 10,
    titleWeight: 3,
    descriptionWeight: 2,
    contentWeight: 1,
    searchMode: "any",
    stemming: true,
    phonetic: false,
    synonyms: true,
    typoTolerance: true,
    acronyms: true,
    resultLimits: {
      solution: { enabled: false, value: 10 },
      kb: { enabled: false, value: 10 },
      problem: { enabled: false, value: 10 }
    }
  },
  services: {
    database: false,
    meilisearch: false,
    ai: false
  }
};

