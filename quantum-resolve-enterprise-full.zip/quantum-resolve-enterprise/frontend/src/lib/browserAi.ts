import type { AiSettings } from "../types";

type AiResult = { text: string; sources: { uri: string; title: string }[] };

export async function callBrowserGemini(
  settings: AiSettings,
  systemPrompt: string,
  userPrompt: string,
  useSearch = false
): Promise<AiResult> {
  if (settings.provider !== "gemini") {
    throw new Error("Browser fallback currently supports Google Gemini keys only.");
  }
  const key = settings.apiKey.trim();
  const model = settings.model.trim() || "gemini-2.5-flash";
  if (!key) throw new Error("Gemini API key is missing.");

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: userPrompt }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
          temperature: settings.temperature ?? 0.2
        },
        ...(useSearch && settings.grounding ? { tools: [{ google_search: {} }] } : {})
      })
    }
  );

  if (!response.ok) {
    const detail = await response.json().catch(() => null);
    const message = detail?.error?.message || `Gemini returned ${response.status}`;
    throw new Error(message);
  }

  const payload = await response.json();
  const candidate = payload.candidates?.[0];
  const text = candidate?.content?.parts?.map((part: { text?: string }) => part.text).filter(Boolean).join("\n");
  if (!text) {
    const blockReason = payload.promptFeedback?.blockReason || candidate?.finishReason;
    throw new Error(blockReason ? `Gemini returned no text: ${blockReason}` : "Gemini returned an empty response.");
  }

  const chunks = candidate?.groundingMetadata?.groundingChunks || [];
  const attributions = candidate?.groundingMetadata?.groundingAttributions || [];
  const sources = [
    ...chunks.map((item: { web?: { uri?: string; title?: string } }) => item.web),
    ...attributions.map((item: { web?: { uri?: string; title?: string } }) => item.web)
  ]
    .filter((web: { uri?: string; title?: string } | undefined) => web?.uri)
    .map((web: { uri?: string; title?: string }) => ({ uri: web.uri || "", title: web.title || web.uri || "Source" }))
    .filter((source, index, all) => all.findIndex((item) => item.uri === source.uri) === index);

  return { text, sources };
}

