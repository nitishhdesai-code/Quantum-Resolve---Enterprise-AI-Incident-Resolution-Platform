import type { AiSettings, BootstrapPayload, SearchProvider } from "../types";

const BOOTSTRAP_KEY = "quantum-resolve-bootstrap-v2";
const BOOTSTRAP_META_KEY = "quantum-resolve-bootstrap-meta-v2";
const THEME_KEY = "quantum-resolve-theme-v2";
const AI_SETTINGS_KEY = "quantum-resolve-ai-settings-v1";
const AI_SESSION_KEY = "quantum-resolve-ai-session-key-v1";
const SEARCH_PROVIDER_KEY = "quantum-resolve-search-provider-v1";
const DB_NAME = "quantum-resolve-offline";
const DB_VERSION = 1;
const STORE_NAME = "snapshots";

export async function cacheBootstrap(payload: BootstrapPayload) {
  const cachedAt = new Date().toISOString();
  const db = await openOfflineDb();
  await putValue(db, "bootstrap", payload);
  localStorage.setItem(
    BOOTSTRAP_META_KEY,
    JSON.stringify({
      cachedAt,
      stats: payload.stats,
      source: payload.services.database ? "api" : "offline"
    })
  );
}

export async function readCachedBootstrap(): Promise<BootstrapPayload | null> {
  try {
    const db = await openOfflineDb();
    const payload = await getValue<BootstrapPayload>(db, "bootstrap");
    if (payload) return payload;
  } catch {
    // Fall through to legacy localStorage cache.
  }

  const raw = localStorage.getItem(BOOTSTRAP_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw).payload as BootstrapPayload;
  } catch {
    return null;
  }
}

export function writeTheme(theme: "dark" | "light") {
  localStorage.setItem(THEME_KEY, theme);
}

export function readTheme(): "dark" | "light" {
  return localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark";
}

export function writeSearchProvider(provider: SearchProvider) {
  localStorage.setItem(SEARCH_PROVIDER_KEY, provider);
}

export function readSearchProvider(): SearchProvider {
  const value = localStorage.getItem(SEARCH_PROVIDER_KEY);
  return value === "meilisearch" || value === "opensearch" || value === "elasticsearch" || value === "solr"
    ? value
    : "offline";
}

export function writeAiSettings(settings: AiSettings) {
  const { apiKey, ...safeSettings } = settings;
  localStorage.setItem(AI_SETTINGS_KEY, JSON.stringify(safeSettings));
  if (apiKey) sessionStorage.setItem(AI_SESSION_KEY, apiKey);
  else sessionStorage.removeItem(AI_SESSION_KEY);
}

export function readAiSettings(): AiSettings {
  const fallback: AiSettings = {
    enabled: false,
    provider: "gemini",
    model: "gemini-2.5-flash",
    apiKey: "",
    endpoint: "",
    grounding: true,
    temperature: 0.2
  };
  const raw = localStorage.getItem(AI_SETTINGS_KEY);
  if (!raw) return { ...fallback, apiKey: sessionStorage.getItem(AI_SESSION_KEY) || "" };
  try {
    return {
      ...fallback,
      ...JSON.parse(raw),
      apiKey: sessionStorage.getItem(AI_SESSION_KEY) || ""
    };
  } catch {
    return { ...fallback, apiKey: sessionStorage.getItem(AI_SESSION_KEY) || "" };
  }
}

export function downloadJson(filename: string, payload: unknown) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function readBootstrapMeta(): { cachedAt?: string; source?: string; stats?: BootstrapPayload["stats"] } | null {
  const raw = localStorage.getItem(BOOTSTRAP_META_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function openOfflineDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function putValue(db: IDBDatabase, key: string, value: unknown) {
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

function getValue<T>(db: IDBDatabase, key: string) {
  return new Promise<T | null>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).get(key);
    request.onsuccess = () => resolve((request.result as T | undefined) || null);
    request.onerror = () => reject(request.error);
  });
}
