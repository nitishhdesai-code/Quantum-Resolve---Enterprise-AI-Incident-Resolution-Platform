import type {
  BootstrapPayload,
  Category,
  KbArticle,
  ProblemRecord,
  SearchConfig,
  SearchDocument,
  SearchResponse,
  Solution,
  TierRecord
} from "../types";
import { scorePassesThreshold } from "./searchScoring";

export function runOfflineSearch(
  bootstrap: BootstrapPayload,
  query: string,
  categories: Category[],
  config: SearchConfig,
  tierAccuracy: number
): SearchResponse {
  const documents = buildDocuments(bootstrap);
  const results = performSearch(query, documents, categories, config, bootstrap);
  return {
    query,
    results,
    prediction: predictTier(query, bootstrap.tiers, config, bootstrap, tierAccuracy),
    engine: "offline-cache",
    counts: {
      solution: results.solution.length,
      kb: results.kb.length,
      problem: results.problem.length
    }
  };
}

export function buildDocuments(bootstrap: BootstrapPayload): SearchDocument[] {
  return [
    ...bootstrap.solutions.map(solutionToDocument),
    ...bootstrap.kbArticles.map(kbToDocument),
    ...bootstrap.problems.map(problemToDocument)
  ];
}

function performSearch(
  query: string,
  documents: SearchDocument[],
  categories: Category[],
  config: SearchConfig,
  bootstrap: BootstrapPayload
) {
  const groups = { solution: [], kb: [], problem: [] } as Record<Category, SearchDocument[]>;
  const rawKeywords = raw(query);
  const keywords = processed(rawKeywords, config, bootstrap);
  if (!query.trim() || keywords.length === 0) return groups;

  for (const document of documents) {
    if (!categories.includes(document.type)) continue;
    const titleScore = scoreField(document.title, keywords, config);
    const descriptionScore = scoreField(document.description, keywords, config);
    const contentScore = scoreField(document.content, keywords, config);
    let total =
      titleScore * config.titleWeight +
      descriptionScore * config.descriptionWeight +
      contentScore * config.contentWeight;

    const fullText = `${document.title} ${document.description} ${document.content}`.toLowerCase();
    const words = fullText.split(/\s+/);

    if (config.searchMode === "all") {
      const allFound = rawKeywords.every((word) => {
        const target = config.stemming ? stem(word) : word;
        return (
          fullText.includes(target) ||
          (config.typoTolerance &&
            words.some((candidate) => levenshtein(candidate, target) / Math.max(target.length, 1) <= typoThreshold(config)))
        );
      });
      if (!allFound) total = 0;
    }

    if (config.searchMode === "exact" && !fullText.includes(query.toLowerCase())) {
      total = 0;
    }

    if (scorePassesThreshold(total, keywords.length, config)) {
      groups[document.type].push({ ...document, score: Number(total.toFixed(3)) });
    }
  }

  (Object.keys(groups) as Category[]).forEach((category) => {
    groups[category].sort((a, b) => (b.score || 0) - (a.score || 0));
    const limit = config.resultLimits[category];
    if (limit?.enabled) groups[category] = groups[category].slice(0, limit.value);
  });

  return groups;
}

function predictTier(
  query: string,
  tiers: TierRecord[],
  config: SearchConfig,
  bootstrap: BootstrapPayload,
  accuracy: number
) {
  const keywords = processed(raw(query), config, bootstrap);
  if (!keywords.length) return null;
  let best: TierRecord | null = null;
  let bestScore = -1;
  for (const tier of tiers) {
    const current = scoreField(`${tier.category} ${tier.tier1} ${tier.tier2} ${tier.tier3}`, keywords, config);
    if (current > bestScore) {
      bestScore = current;
      best = tier;
    }
  }
  const confidence = bestScore / keywords.length;
  return best && confidence >= accuracy ? { ...best, confidence: Number(confidence.toFixed(2)) } : null;
}

export function summarizeOfflineCauses(documents: SearchDocument[]) {
  const map = new Map<string, { cause: string; count: number; bestScore: number }>();
  for (const document of documents.filter((item) => item.type === "solution")) {
    const cause = ((document.payload as Solution).cause || "").trim();
    if (!cause) continue;
    const key = normalizeCause(cause);
    if (!key) continue;
    const existing = map.get(key);
    if (!existing) {
      map.set(key, { cause, count: 1, bestScore: document.score || 0 });
    } else {
      existing.count += 1;
      existing.bestScore = Math.max(existing.bestScore, document.score || 0);
      if (cause.length > existing.cause.length && cause.length < 220) existing.cause = cause;
    }
  }
  return [...map.values()]
    .sort((a, b) => b.count - a.count || b.bestScore - a.bestScore)
    .slice(0, 10)
    .map(({ cause, count }) => ({ cause, count }));
}

function normalizeCause(cause: string) {
  return cause
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\b(the|a|an|and|or|of|to|in|for|with|due|because|caused|by|issue|problem|error)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function localCloseNotes(issue: string, bootstrap: BootstrapPayload, config: SearchConfig) {
  const result = runOfflineSearch(bootstrap, issue, ["solution"], config, 0.5).results.solution[0];
  if (!result) return "No similar past solutions found.";
  const payload = result.payload as Solution;
  return `Issue: ${payload.issue}\n\nCause: ${payload.cause || "Not documented"}\n\nResolution: ${payload.resolution || "No resolution documented."}`;
}

function raw(query: string) {
  return query
    .toLowerCase()
    .split(/[\s,.;:()/_-]+/)
    .map((word) => word.trim())
    .filter(Boolean);
}

function processed(words: string[], config: SearchConfig, bootstrap: BootstrapPayload) {
  let expanded = [...words];
  if (config.synonyms) {
    expanded = [...new Set(expanded.flatMap((word) => [word, ...(bootstrap.dictionaries.synonymMap[word] || [])]))];
  }
  if (config.acronyms) {
    expanded = [...new Set(expanded.flatMap((word) => [word, ...(bootstrap.dictionaries.acronymMap[word] || [])]))];
  }

  const critical = new Set(["tc", "nx", "kb", "id"]);
  let filtered = expanded.filter((word) => word.length > 2 && !bootstrap.dictionaries.stopWords.includes(word));
  for (const word of words) if (critical.has(word) && !filtered.includes(word)) filtered.push(word);
  if (config.stemming) filtered = filtered.map(stem);
  return [...new Set(filtered)];
}

function scoreField(text: string, keywords: string[], config: SearchConfig) {
  const lower = text.toLowerCase();
  const words = tokenize(lower);
  let score = 0;
  for (const keyword of keywords) {
    if (matchesKeyword(lower, words, keyword)) score += keyword.length <= 3 ? 1.2 : 1;
    else if (
      config.typoTolerance &&
      words.some((word) => word.length > 2 && levenshtein(word, keyword) / Math.max(keyword.length, 1) <= typoThreshold(config))
    ) {
      score += 0.75;
    } else if (config.phonetic && words.some((word) => soundex(word) === soundex(keyword))) {
      score += 0.5;
    }
  }
  return score;
}

function matchesKeyword(text: string, words: string[], keyword: string) {
  if (keyword.length <= 3) return words.includes(keyword);
  return text.includes(keyword);
}

function solutionToDocument(item: Solution): SearchDocument {
  return {
    uid: `solution:${item.id}`,
    id: item.id,
    type: "solution",
    title: item.issue,
    description: `${item.cause} ${item.resolution}`,
    content: `${item.tier} ${item.tier1} ${item.tier2} ${item.tier3} ${item.keywords.join(" ")}`,
    keywords: item.keywords,
    payload: item
  };
}

function kbToDocument(item: KbArticle): SearchDocument {
  return {
    uid: `kb:${item.id}`,
    id: item.id,
    type: "kb",
    title: `${item.number}: ${item.title}`,
    description: "",
    content: item.keywords.join(" "),
    keywords: item.keywords,
    payload: item
  };
}

function problemToDocument(item: ProblemRecord): SearchDocument {
  return {
    uid: `problem:${item.id}`,
    id: item.id,
    type: "problem",
    title: item.title,
    description: `${item.application || ""} ${item.problemId} ${item.eit || ""} ${item.deliveryId || ""} ${item.status || ""}`,
    content: `${item.keywords.join(" ")} ${item.eitLink || ""} ${item.problemLink || ""} ${item.fdtdLink || ""}`,
    keywords: item.keywords,
    payload: item
  };
}

function stem(word: string) {
  return word.replace(/(ing|s|ed)$/i, "");
}

function tokenize(text: string) {
  return text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .map((word) => word.trim())
    .filter((word) => word.length > 1);
}

function typoThreshold(config: SearchConfig) {
  return 1 - config.fuzzySensitivity / 100;
}

function levenshtein(a: string, b: string) {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j += 1) matrix[0][j] = j;
  for (let i = 1; i <= a.length; i += 1) {
    for (let j = 1; j <= b.length; j += 1) {
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return matrix[a.length][b.length];
}

function soundex(value: string) {
  const chars = value.toLowerCase().split("");
  const first = chars.shift() || "";
  const codes: Record<string, string> = {
    a: "",
    e: "",
    i: "",
    o: "",
    u: "",
    b: "1",
    f: "1",
    p: "1",
    v: "1",
    c: "2",
    g: "2",
    j: "2",
    k: "2",
    q: "2",
    s: "2",
    x: "2",
    z: "2",
    d: "3",
    t: "3",
    l: "4",
    m: "5",
    n: "5",
    r: "6"
  };
  const encoded = chars
    .map((char) => codes[char] || "")
    .filter((code, index, all) => (index === 0 ? code !== codes[first] : code !== all[index - 1]))
    .join("");
  return `${first}${encoded}000`.slice(0, 4).toUpperCase();
}
