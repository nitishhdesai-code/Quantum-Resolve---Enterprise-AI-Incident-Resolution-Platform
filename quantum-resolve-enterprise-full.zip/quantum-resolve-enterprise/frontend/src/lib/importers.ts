import { fallbackBootstrap } from "./fallbackData";
import type { BootstrapPayload, KbArticle, ProblemRecord, Solution, TierRecord } from "../types";

type LooseRecord = Record<string, unknown>;
type KnowledgeInput = {
  solutions?: unknown[];
  kbArticles?: unknown[];
  problems?: unknown[];
  tiers?: unknown[];
  curated?: unknown[];
  dictionaries?: Partial<BootstrapPayload["dictionaries"]>;
  defaultSearchConfig?: BootstrapPayload["defaultSearchConfig"];
  services?: Partial<BootstrapPayload["services"]>;
};

export async function parseKnowledgeFile(file: File) {
  const text = await file.text();
  const extension = file.name.toLowerCase().split(".").pop();
  return normalizeKnowledgePayload(extension === "jsonl" ? parseJsonl(text) : JSON.parse(text));
}

export async function fetchPackagedKnowledge(path = "/offline/knowledge-base.json") {
  if (path === "/offline/knowledge-base.json") {
    try {
      return await fetchSeparatePackagedKnowledge();
    } catch {
      // Fall back to the legacy combined snapshot below.
    }
  }

  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) throw new Error(`Offline database not found at ${path}`);
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();
  if (contentType.includes("text/html") || text.trim().startsWith("<!doctype")) {
    throw new Error(`Offline database path returned HTML instead of data: ${path}`);
  }
  return normalizeKnowledgePayload(path.endsWith(".jsonl") ? parseJsonl(text) : JSON.parse(text));
}

async function fetchSeparatePackagedKnowledge(base = "/offline") {
  const [solutions, kbArticles, problems, tiers, dictionaries, defaultSearchConfig, services, curated] = await Promise.all([
    fetchJson(`${base}/solutions.json`),
    fetchJson(`${base}/kb-articles.json`),
    fetchJson(`${base}/problems.json`),
    fetchJson(`${base}/tiers.json`),
    fetchOptionalJson(`${base}/dictionaries.json`),
    fetchOptionalJson(`${base}/search-config.json`),
    fetchOptionalJson(`${base}/services.json`),
    fetchOptionalJson(`${base}/curated.json`)
  ]);

  return normalizeKnowledgePayload({
    solutions,
    kbArticles,
    problems,
    tiers,
    dictionaries,
    defaultSearchConfig,
    services,
    curated
  });
}

async function fetchJson(path: string) {
  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) throw new Error(`Offline database part not found at ${path}`);
  return response.json();
}

async function fetchOptionalJson(path: string) {
  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) return undefined;
  return response.json();
}

export function normalizeKnowledgePayload(input: unknown): BootstrapPayload {
  const raw: KnowledgeInput = Array.isArray(input)
    ? splitTypedRecords(input as LooseRecord[])
    : (input as KnowledgeInput);
  const solutions = normalizeSolutions(raw.solutions || []);
  const kbArticles = normalizeKbArticles(raw.kbArticles || []);
  const problems = normalizeProblems(raw.problems || []);
  const tiers = normalizeTiers(raw.tiers || []);

  return {
    solutions,
    kbArticles,
    problems,
    tiers,
    curated: normalizeSolutions(raw.curated || []),
    stats: {
      solutions: solutions.length,
      kbArticles: kbArticles.length,
      problems: problems.length
    },
    dictionaries: {
      stopWords: raw.dictionaries?.stopWords || fallbackBootstrap.dictionaries.stopWords,
      synonymMap: raw.dictionaries?.synonymMap || fallbackBootstrap.dictionaries.synonymMap,
      acronymMap: raw.dictionaries?.acronymMap || fallbackBootstrap.dictionaries.acronymMap
    },
    defaultSearchConfig: raw.defaultSearchConfig || fallbackBootstrap.defaultSearchConfig,
    services: {
      database: false,
      meilisearch: false,
      ai: false,
      ...(raw.services || {})
    }
  };
}

function parseJsonl(text: string) {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => JSON.parse(line)) as LooseRecord[];
}

function splitTypedRecords(records: LooseRecord[]): KnowledgeInput {
  const solutions: LooseRecord[] = [];
  const kbArticles: LooseRecord[] = [];
  const problems: LooseRecord[] = [];
  const tiers: LooseRecord[] = [];

  for (const record of records) {
    const type = String(record.type || "").toLowerCase();
    if (type === "solution" || record.issue || record.resolution) solutions.push(record);
    else if (type === "kb" || type === "kbarticle" || record.number) kbArticles.push(record);
    else if (type === "problem" || record.problemId || record.problem_id) problems.push(record);
    else if (type === "tier" || (record.category && record.tier1)) tiers.push(record);
  }

  return { solutions, kbArticles, problems, tiers };
}

function normalizeSolutions(records: unknown[]): Solution[] {
  return records.map((record, index) => {
    const item = record as LooseRecord;
    return {
      id: stringValue(item.id, `sol_${index + 1}`),
      tier: stringValue(item.tier),
      tier1: stringValue(item.tier1),
      tier2: stringValue(item.tier2),
      tier3: stringValue(item.tier3),
      issue: stringValue(item.issue || item.title || item.summary, "Untitled solution"),
      cause: stringValue(item.cause),
      resolution: stringValue(item.resolution || item.fix || item.closeNotes),
      keywords: arrayValue(item.keywords || item.tags),
      link: optionalString(item.link || item.url)
    };
  });
}

function normalizeKbArticles(records: unknown[]): KbArticle[] {
  return records.map((record, index) => {
    const item = record as LooseRecord;
    return {
      id: stringValue(item.id, `kb_${index + 1}`),
      number: stringValue(item.number || item.kbNumber, `KB${String(index + 1).padStart(7, "0")}`),
      title: stringValue(item.title || item.issue, "Untitled KB article"),
      keywords: arrayValue(item.keywords || item.tags),
      link: optionalString(item.link || item.url)
    };
  });
}

function normalizeProblems(records: unknown[]): ProblemRecord[] {
  return records.map((record, index) => {
    const item = record as LooseRecord;
    return {
      id: stringValue(item.id, `prb_${index + 1}`),
      problemId: stringValue(item.problemId || item.problem_id || item.number, `PRB${String(index + 1).padStart(7, "0")}`),
      title: stringValue(item.title || item.issue, "Untitled problem"),
      keywords: arrayValue(item.keywords || item.tags),
      application: optionalString(item.application),
      eit: optionalString(item.eit),
      deliveryId: optionalString(item.deliveryId || item.delivery_id),
      status: optionalString(item.status),
      eitLink: optionalString(item.eitLink || item.eit_link),
      problemLink: optionalString(item.problemLink || item.problem_link),
      fdtdLink: optionalString(item.fdtdLink || item.fdtd_link),
      link: optionalString(item.link || item.url)
    };
  });
}

function normalizeTiers(records: unknown[]): TierRecord[] {
  return records.map((record) => {
    const item = record as LooseRecord;
    return {
      category: stringValue(item.category),
      tier1: stringValue(item.tier1),
      tier2: stringValue(item.tier2),
      tier3: stringValue(item.tier3)
    };
  });
}

function stringValue(value: unknown, fallback = "") {
  return value == null ? fallback : String(value);
}

function optionalString(value: unknown) {
  return value == null || value === "" ? undefined : String(value);
}

function arrayValue(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((item) => String(item).trim().toLowerCase()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
  return [];
}
