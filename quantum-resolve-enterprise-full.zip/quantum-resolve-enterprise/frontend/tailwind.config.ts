import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"]
      },
      colors: {
        ink: "#080809",
        panel: "#111113",
        line: "rgba(255,255,255,0.10)",
        signal: "#35d6c9",
        ember: "#ff735c",
        pollen: "#f5c542",
        grove: "#72e06a"
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(255,255,255,0.08), 0 24px 80px rgba(0,0,0,0.45)"
      }
    }
  },
  plugins: []
} satisfies Config;

